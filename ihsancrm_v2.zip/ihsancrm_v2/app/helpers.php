<?php 

use Illuminate\Support\Facades\DB;

if (! function_exists('checkMail')) {
    function checkMail($mail)
    {
       return $mail;
    }
}
if (! function_exists('getUser')) {
    function getUser($id)
    {
       $data=DB::table('users')->where('id',$id)->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('getBot')) {
    function getBot($id)
    {
       $data=DB::table('bots')->where('uid',$id)->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('getBotByID')) {
    function getBotByID($id)
    {
       $data=DB::table('bots')->where('id',$id)->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('getBotByRandomID')) {
    function getBotByRandomID($id)
    {
       $data=DB::table('bots')->where('rid',$id)->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('cBots')) {
    function cBots()
    {
       return DB::table('bots')->where('user_id',Auth::user()->id)->count(); 
       
    }
}
if (! function_exists('userBots')) {
    function userBots()
    {
       return DB::table('bots')->where('user_id',Auth::user()->id)->get()->toArray(); 
       
    }
}
if (! function_exists('getWhereNot')) {
    function getWhereNot($tb,$fld,$value)
    {
       $data=DB::table($tb)->where($fld,"!=",$value)->orderbyDesc('created_at')->get()->toArray(); 
        return $data;
    }
}
if (! function_exists('getWhere')) {
    function getWhere($tb,$fld,$value)
    {
       $data=DB::table($tb)->where($fld,$value)->orderbyDesc('created_at')->get()->toArray(); 
        return $data;
    }
}
if (! function_exists('getAll')) {
    function getAll($table)
    {
       $data=DB::table($table)->orderbyDesc('created_at')->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('insert_data')) {
    function insert_data($table,$data)
    {
       $data=DB::table($table)->insert($data); 
        return $data;  
    }
}
if (! function_exists('getAllOrderby')) {
    function getAllOrderby($id)
    {
       $data=DB::table($id)->orderbyDesc('created_at')->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('countWhere')) {
    function countWhere($tb,$fld,$id)
    {
       $data=DB::table($tb)->where($fld,$id)->count();
        return $data;  
    }
}
if (! function_exists('countOnly')) {
    function countOnly($tb)
    {
       $data=DB::table($tb)->count(); 
        return $data;  
    }
}
if (! function_exists('getTotalBalance')) {
    function getTotalBalance($id)
    {
      /* $orders=DB::table('orders')->where('partner_id',$id)->where('status',1)->sum('amount');
        $payment_requests=DB::table('payment_requests')->where('partner_id',$id)->where('request_sts',1)->sum('amount'); 
        $rData=$orders-$payment_requests;      
        return $rData; */
        $payment_requests=DB::table('users')->where('id',$id)->get(); 
        return $payment_requests[0]->amount; 


    }
}
if (! function_exists('getTotalOrders')) {
    function getTotalOrders($date1,$date2)
    {
       $orders=DB::table('orders')->where('partner_id',Auth::user()->id)->where('status',1)->whereBetween('created_at',array($date1, $date2))->count();
             
        return $orders;  
    }
}
if (! function_exists('getCodeDetails')) {
    function getCodeDetails($code)
    {
       switch ($code) {
             case '400':
                return "Something went wrong Bad Request";
                 break;
            case '401':
                return "Your Access Token is Expired Try to Refresh it";
                 break;
            case '401':
                return "Your Request item not found ";
                 break;
             case '403':
                return "You Don't Have Permission for the request";
                 break;
             
             default:
                 return "Something went wrong";
                 break;
         }  
    }
}

if (! function_exists('getByLImit')) {
    function getByLImit($tb,$limit=10)
    {
       $data=DB::table($tb)->orderbyDesc('created_at')->limit($limit)->get()->toArray(); 
        return $data;
    }
}
 ?>

<?php 
if (! function_exists('getTimeFormat')) {
    function getTimeFormat($format,$date)
    {   
        return date($format,strtotime($date));
    }
}

if (! function_exists('getPlans')) {
    function getPlans()
    {
       $data=DB::table('plans')->get()->toArray(); 
        return $data;  
    }
}
if (! function_exists('getPlan')) {
    function getPlan($id,$type)
    {
        if ($type=="n") {
            $data=DB::table('plans')->where('name',"=",$id)->get()->toArray(); 
            return $data;  
        }elseif ($type=="id") {
            $data=DB::table('plans')->where('id',"=",$id)->get()->toArray(); 
        }
       
    }
}
if (! function_exists('getRandomname')) {
    function getRandomname()
    {
        $currentTimestamp = microtime(true) * 1000; 
        $randomString = substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 10); 
        $randomStringWithTime = $currentTimestamp.$randomString;
        $removed_dots = str_replace('.', '', $randomStringWithTime);
        return $removed_dots;
    }
}
if (! function_exists('isValidPhoneNumber')) {
 function isValidPhoneNumber($number) {
    $number = preg_replace('/[^0-9]/', '', $number);
    $pattern = '/^(\+?)([0-9]{8,15})$/';

    return preg_match($pattern, $number) === 1;
}
}
if (! function_exists('isValidPhoneNumber')) {
 function restartSession($brid) {
    $response = Http::post(env('xxWHATS_APIxx').'/api/sessions/stop',['logout'=>true,'name'=>$brid]);
   
        $postData=[
    
            "name"=>$brid,
            "config"=> [
              "proxy"=> null,
              "webhooks"=> [
                [
                  "url"=>"https://httpbin.org/post",
                  "events"=>[
                    "message"
                  ],
                  "hmac"=> null,
                  "retries"=>null,
                  "customHeaders"=> null
                ]
              ]
              ]
                ];
        $response = Http::post(env('xxWHATS_APIxx').'/api/sessions/start', $postData);
        if($response->failed() AND $response->status()!=201):
            return restartSession($brid);
        else:
            return redirect('/WhatsappAi/screen/'.$brid.'/qrcode'); 

        endif;

   
}
}
if (! function_exists('checkSessions')) {
function checkSessions($nameOF) {
    $heade=['content-type'=>'application/json'];
    $response = Http::withHeaders($heade)->get(env('xxWHATS_APIxx').'/api/sessions?all=true');
    if($response->failed() AND $response->status()!=201):
        notify()->error("Something went wrong Try Later",$response->status());
        return redirect('/WhatsupAi'); 
    else:
        foreach(json_decode($response) as $val):
           if($val->name==$nameOF):
            return $val->status;
            break;
           endif;
        endforeach;
    endif;
}
}
if (! function_exists('getCurrentSatus')) {
function getCurrentSatus($brid) {
    $dataset=DB::table('bots')->where('rid','=',$brid)->get();
    return $dataset[0]->what_status;

}
}
 ?>