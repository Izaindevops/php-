<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Http;

class SmsSheetModal extends Component
{
 
    public $botKey;
    public function render()
    {
        return view('livewire.sms-sheet-modal');
    }
   
}
