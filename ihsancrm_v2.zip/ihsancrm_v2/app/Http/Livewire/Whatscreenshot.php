<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client;
use Validator;
class Whatscreenshot extends Component
{  public $brid;
    public $imageData;
    public $codeResponse;
    public $codeMessage;

    public function screenDiv()
    {
        if(getCurrentSatus($this->brid)=="STARTING" OR getCurrentSatus($this->brid)=="SCAN_QR_CODE"){
            try {
            $response = Http::withHeaders([
                'x-api-key' => 'api_adminn@2291',
            ])->get('https://whatsapp.ihsancrm.com/api/screenshot?session='.$this->brid);
                if($response->failed() AND $response->status()!=200):

                    $this->codeResponse=strval($response);
                    $this->codeMessage=strval($response->status());
                    //return restartSession($this->brid);
                    // return redirect('WhatsappAi');

                else:
                    $this->codeResponse=strval($response->status());
                    $this->codeMessage=strval($response->status());
                    $this->imageData  = base64_encode($response);


                endif;
            } catch (\Exception $e) {
                notify()->error($e->getMessage(), "Oops");
                $this->codeResponse=404;
                $this->codeMessage="Something went wrong";
    
            }
            }elseif(getCurrentSatus($this->brid)=="WORKING"){

            }else{
                $this->codeResponse="Your Session has not created yet or Close Please Try it Again";
                $this->codeMessage="Sorry ! ";
            }
    }
    public function render()
    {
        return view('livewire.whatscreenshot');
    }
    public function mount()
    {
        $this->codeMessage=config('services.xxxx.xxWHATS_APIxx');
        $this->codeResponse=config('services.xxxx.xxWHATS_APIxx');
        $response = Http::withHeaders([
            'x-api-key' => 'api_adminn@2291',
        ])->get('https://whatsapp.ihsancrm.com/api/screenshot?session='.$this->brid);
            if($response->failed() AND $response->status()!=200):
                $this->codeResponse=strval($response);
                $this->codeMessage=strval($response->status());
                //return restartSession($this->brid);

                else:
                    DB::table('bots')->where('rid','=',$this->brid)->update(['is_whats_linked'=>1]);
                    $this->codeMessage=strval($response->status());
                    $this->imageData  = base64_encode($response);
                endif;

    }

}
