<?php

namespace App\Http\Livewire;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class AllSMS extends Component
{
    public $selectedUserId; // Public property to hold the selected user ID
    public $messagesAll; 
    public function mount()
    {
        $this->selectedUserId = null;
        $this->messagesAll = [];
       
    }
    public function render()
    {
        return view('livewire.AllSMS');
    }
    public function getAllSMS(){
        
        $this->selectedUserId=$id;
       $this->messagesAll=DB::table('ai_sms')->where('id',1)->get()->toArray();
       dd($this->messagesAll);
    }
    
}
