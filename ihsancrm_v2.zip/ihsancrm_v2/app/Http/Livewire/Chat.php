<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\botchat;
use Illuminate\Support\Facades\DB;

use Auth;
class Chat extends Component
{
    public $messages = [];
    public $welComeMessage;
     public $uid;

    protected $listeners = ['messageReceived' => 'appendMessage'];

    public function mount()
    {
        $this->messages = botchat::latest()->get();
    }

    public function render()
    {
        return view('livewire.chat', [
            'messages' => $this->messages,
        ]);
    }

    public function sendMessage()
    {
        if (!empty($this->newMessage)) {
            $message = botchat::create([
            'send_id' => Auth::user()->id,
            'bot_id' => 1,
            'receive_id' => 1,            
            'is_bot' => 0,
            'sender_email' => null,
            'sender_name' => null,
            'message' => $this->newMessage,
        ]);
           // reveiveMessage($this->newMessage);
            $this->emit('messageReceived', $message->toArray());
            $this->newMessage = '';
        }
    }

    public function appendMessage($message)
    {
        array_push($this->messages, $message);
    }

    public function reveiveMessage($key){
            $uid='$2y$10$uQjCAHGfJmQLLTz1HH2U6ODTTWxTTdGXW6vJQClt55rOqYFMHvi';
            $response = Http::asForm()->post('https://13e5-139-135-53-85.ngrok-free.app/query', [
             'uid' => $uid,
            'query' => $key,
             ]);
            if($response->failed()):
                
            else:
                $this->newMessage=$response['response'];
                     if (!empty($this->newMessage)) {
                        $message = botchat::create([
                        'send_id' => Auth::user()->id,
                        'bot_id' => 1,
                        'receive_id' => 1,            
                        'is_bot' => 0,
                        'sender_email' => null,
                        'sender_name' => null,
                        'message' => $this->newMessage,
                    ]);
                        $this->emit('messageReceived', $message->toArray());
                        $this->newMessage = '';
                    }
            endif;

    }

}


  