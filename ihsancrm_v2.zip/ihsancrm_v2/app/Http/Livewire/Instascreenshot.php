<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client;
use Validator;

class Instascreenshot extends Component
{
     public $brid;
    public $imageData;
    public $codeResponse;
    public $codeMessage;

    public function render()
    {
        return view('livewire.instascreenshot');
    }

    public function screenDiv()
    {

            $response = Http::withHeaders([
                'Authorization' => 'za-cWiJDJMlz7TFJh1l42z7MC0VM9ZaTBwdCZaTDFKl13BlbkFJ',
            ])->get('https://iggcp.ihsancrm.com//api/insta/screenshot?session='.$this->brid);
                if($response->failed() AND $response->status()!=200):

                    $this->codeResponse=strval($response);
                    $this->codeMessage=strval($response->status());
                     DB::table('bots')->where('rid','=',$this->brid)->update(['is_insta_linked'=>0]);
                    //return restartSession($this->brid);
                    // return redirect('WhatsupAi');

                else:

                      if (@$response->json()['error']) {
                         DB::table('bots')->where('rid','=',$this->brid)->update(['is_insta_linked'=>0]);
                          $this->codeMessage='404';
                    }else{
                         DB::table('bots')->where('rid','=',$this->brid)->update(['is_insta_linked'=>1]);
                          $this->codeMessage=strval($response->status());
                         $this->imageData  = $response->body();

                    }

                endif;

    }

    public function mount()
    {
        $this->codeMessage=config('services.xxxx.xxBOTTRAINERxx');
        $this->codeResponse=config('services.xxxx.xxBOTTRAINERxx');

        $response = Http::withHeaders([
            'Authorization' => 'za-cWiJDJMlz7TFJh1l42z7MC0VM9ZaTBwdCZaTDFKl13BlbkFJ',
        ])->get('https://iggcp.ihsancrm.com/api/insta/screenshot?session='.$this->brid);

            if($response->failed() AND $response->status()!=200):
                $this->codeResponse=strval($response);
                $this->codeMessage=strval($response->status());
                 DB::table('bots')->where('rid','=',$this->brid)->update(['is_insta_linked'=>0]);
                //return restartSession($this->brid);


                else:
                    if (@$response->json()['error']) {
                         DB::table('bots')->where('rid','=',$this->brid)->update(['is_insta_linked'=>0]);
                         $this->codeMessage='404';
                    }else{
                         DB::table('bots')->where('rid','=',$this->brid)->update(['is_insta_linked'=>1]);
                          $this->codeMessage=strval($response->status());
                         $this->imageData  = $response->body();

                    }



                endif;


    }
}
