<?php

namespace App\Http\Livewire;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class ChatbotLists extends Component
{
    public $uid;
    public $selectedUserIds;
    public $messagesAll; 
    public $messagesName; 
    public $messagesBot; 
    public $messagesIMG;
   
    public function mount()
    {
    
        $this->selectedUserIds = null;
        $this->messagesAll = [];
        $this->messagesName=null; 
        $this->messagesBot=null;
        $this->messagesIMG=null;
     
    }
    public function render()
    {
        return view('livewire.chatbot-lists');
    }
    public function getAllBotChats($id){
       
        $this->selectedUserIds=$id;
       
       $dataOFsms=DB::table('botchats')->where('sender_email',$id)->get();
       
       $this->messagesAll=$dataOFsms;
       $this->messagesName=getBotByID($dataOFsms[0]->bot_id)[0]->bot_name; 
       $this->messagesBot=$dataOFsms[0]->sender_name;
       $this->messagesIMG=getBotByID($dataOFsms[0]->bot_id)[0]->bot_logo;
     
    }
}
