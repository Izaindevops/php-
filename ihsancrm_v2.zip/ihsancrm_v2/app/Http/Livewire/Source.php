<?php

namespace App\Http\Livewire;
use App\Models\Bot;
use Livewire\Component;

class Source extends Component
{

    public $uid;
    public $listOfFiles=[];
    protected $listeners = ['messageReceived' => 'appendMessage'];
    public function mount($uid)
    {

         /*  protected $oldData=getWhere('bots','uid',$uid);
            $this->oldData-=$this->oldData[0];
            if ($this->oldData->source_file!=null):
                $listOfFiles=json_decode($oldData[0]->source_file);
            else:
                $listOfFiles=null;
            endif;*/
         $botData = Bot::where('uid', $uid)->first();
         if ($botData AND $botData->source_file!=null) {
            $this->listOfFiles[]=$botData->source_file;
         }else {
            $this->listOfFiles[]=null;
         }
        
    }
    public function render()
    {
        return view('livewire.source',['listOfFiles'=>$this->listOfFiles]);
    }

      public function appendMessage($message)
    {
        array_push($this->messages, $message);
    }
}
