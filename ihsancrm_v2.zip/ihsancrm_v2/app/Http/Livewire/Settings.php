<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Settings extends Component
{
     public function mount()
    {
          $tabFromUrl = $this->getTabFromUrl();
        $this->activeTab = $tabFromUrl ?: 'account';
    }
 public function changeTab($tab)
    {
        $this->activeTab = $tab;
        $this->emit('changeTab', $tab, $this->getUrl($tab));
    }
    public function render()
    {
        return view('livewire.settings');
    }
     private function getTabFromUrl()
    {
        $url = request()->url();
        $segments = explode('/', $url);
        $tab = end($segments);

        // Check if the tab exists and return it, or return null
        if (in_array($tab, ['account', 'security', 'billing'])) {
            return $tab;
        } else {
            return null;
        }
    }

     private function getUrl($tab)
    {
        // Define the URLs for each tab
        if ($tab === 'account') {
            return url('settings/account');
        } elseif ($tab === 'security') {
            return url('settings/security');
        } elseif ($tab === 'billing') {
            return url('settings/billing');
        }
    }
}
