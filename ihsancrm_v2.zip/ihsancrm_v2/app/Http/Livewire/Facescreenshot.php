<?php

namespace App\Http\Livewire;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Livewire\Component;

class Facescreenshot extends Component
{
    public $brid;
    public $imageData;
    public $codeResponse;
    public $codeMessage;
    public function render()
    {
        return view('livewire.facescreenshot');
    }
    public function screenDiv()
    {

        $response = Http::withHeaders([
            'Authorization' => 'za-lz7MC0VJDJMlz7cWi42dCZaTDFKTFJh1l13BlbkFJM9ZaTBw',
        ])->get('https://facebook.ihsancrm.com/api/face/screenshot?session=' . $this->brid);
        if ($response->failed() and $response->status() != 200):

            $this->codeResponse = strval($response);
            $this->codeMessage = strval($response->status());
            DB::table('bots')->where('rid', '=', $this->brid)->update(['is_face_linked' => 0]);
        else:

            if (@$response->json()['error']) {
                DB::table('bots')->where('rid', '=', $this->brid)->update(['is_face_linked' => 0]);
                $this->codeMessage = '404';
            } else {
                DB::table('bots')->where('rid', '=', $this->brid)->update(['is_face_linked' => 1]);
                $this->codeMessage = strval($response->status());
                $this->imageData = $response->body();

            }

        endif;

    }
    public function mount()
    {
        $this->codeMessage = config('services.xxxx.xxBOTTRAINERxx');
        $this->codeResponse = config('services.xxxx.xxBOTTRAINERxx');

        $response = Http::withHeaders([
            'Authorization' => 'za-lz7MC0VJDJMlz7cWi42dCZaTDFKTFJh1l13BlbkFJM9ZaTBw',
        ])->get('https://facebook.ihsancrm.com/api/face/screenshot?session=' . $this->brid);

        if ($response->failed() and $response->status() != 200):
            $this->codeResponse = strval($response);
            $this->codeMessage = strval($response->status());
            DB::table('bots')->where('rid', '=', $this->brid)->update(['is_face_linked' => 0]);
            //return restartSession($this->brid);

        else:
            if (@$response->json()['error']) {
                DB::table('bots')->where('rid', '=', $this->brid)->update(['is_face_linked' => 0]);
                $this->codeMessage = '404';
            } else {
                DB::table('bots')->where('rid', '=', $this->brid)->update(['is_face_linked' => 1]);
                $this->codeMessage = strval($response->status());
                $this->imageData = $response->body();

            }

        endif;

    }
}
