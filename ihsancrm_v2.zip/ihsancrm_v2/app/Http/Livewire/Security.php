<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Security extends Component
{
    public function render()
    {
        return view('livewire.security');
    }
}
