<?php
namespace App\Http\Livewire;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class Smslists extends Component
{
    public $selectedUserId;
    public $messagesAll; 
    public $messagesName; 
    public $messagesBot; 
    public $messagesIMG;
   
    public function mount()
    {
        $this->selectedUserId = null;
        $this->messagesAll = [];
        $this->messagesName=null; 
        $this->messagesBot=null;
        $this->messagesIMG=null;
     
    }
    public function render()
    {
        return view('livewire.smslists');
    }
    public function getAllSMS($id){
        $this->selectedUserId=$id;
       $dataOFsms=DB::table('ai_sms')->where('from_person',$id)->get();
       $this->messagesAll=$dataOFsms;

       $this->messagesName=getBotByID($dataOFsms[0]->bot_id)[0]->bot_name; 
       $this->messagesBot=$dataOFsms[0]->from_person;
       $this->messagesIMG=getBotByID($dataOFsms[0]->bot_id)[0]->bot_logo;
     
    }
    
}
