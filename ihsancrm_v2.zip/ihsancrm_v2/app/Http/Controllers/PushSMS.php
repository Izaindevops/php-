<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
    use GuzzleHttp\Exception\GuzzleException;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\Facades\Http;
    use Validator;
    use Auth;
class PushSMS extends Controller
{
    public function send($value='')
    {

$deviceId = 'YOUR_DEVICE_ID';

// Message content
$message = [
    'type' => 'note',
    'title' => 'SMS',
    'body' => 'Hello, this is a test SMS from Pushbullet API in PHP.'
];

// Create a Guzzle HTTP client instance
$client = new \GuzzleHttp\Client();

// Send the SMS using the Pushbullet API
$response = $client->request('POST', 'https://api.pushbullet.com/v2/pushes', [
    'headers' => [
        'Authorization' => 'Bearer o.LiIKQtCUxTg7JTEZP54axnp5xwOgy2xC' ,
        'Content-Type' => 'application/json',
    ],
    'json' => [
        'device_iden' => $deviceId,
        'type' => $message['type'],
        'title' => $message['title'],
        'body' => $message['body'],
    ],
]);

// Check the response status code
if ($response->getStatusCode() === 200) {
    echo 'SMS sent successfully!';
} else {
    echo 'Failed to send SMS. HTTP Status Code: ' . $response->getStatusCode();
}

    }
    public function getAllChats($value='')
    {
        $header=[
        'Access-Token' => 'o.LiIKQtCUxTg7JTEZP54axnp5xwOgy2xC' ,
       
    ];
          $response = Http::withHeaders($header)->get('https://api.pushbullet.com/v2/chats');
            if($response->failed()):
                return $response->body();
                notify()->error("Something Went Wrong.",$response->status()) ;
                return redirect()->back();
            else:
 return $response->body();
            endif;
    }
}
