<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Support;


class PanelController extends Controller
{
    public function webAi() {
        return view('panel/web/index');
    }
    public function webAiEmbedding($uid) {
        return view('panel/web/embedding',['uid'=>$uid]);
    }
    public function botList() {
        return view('panel/bot_list');
    }
    public function billingHistory() {
        return view('panel/payment_history');
    }
    public function supportList() {

        $supportData=Support::where('user_id',auth()->user()->id)->latest()->get();
        return view('panel.support-system', ['type' => 'list','supportData'=>$supportData]);
    }
    public function supportCreate() {
        return view('panel.support-system', ['type' => 'create']);
    }
}
