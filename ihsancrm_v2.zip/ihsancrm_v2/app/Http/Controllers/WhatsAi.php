<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class WhatsAi extends Controller
{
    private $botUid = 'shehroz786';
    public function show()
    {
        return view('panel.whatsappAi', ['screenshot' => null]);
    }
    public function startSession(Request $request)
    {

        $postData = [

            "name" => $request->bot,
            "config" => [
                "proxy" => null,
                "webhooks" => [
                    [
                        "url" => "https://webhook.ihsancrm.com/api/ihsanai/whatsai/webhook",
                        "events" => [
                            "message",
                        ],
                        "hmac" => null,
                        "retries" => null,
                        "customHeaders" => null,
                    ],
                ],
            ],
        ];
        try {
        $response = Http::withHeaders([
            'x-api-key' => 'api_adminn@2291',
        ])->post('https://whatsapp.ihsancrm.com/api/sessions/start', $postData);
        if ($response->failed() and $response->status() != 201):
            notify()->error("Something went wrong Try Later", $response->status());
            return redirect()->back();
        else:
            DB::table('bots')->where('rid', '=', $request->bot)->update(['is_whats_linked' => 1, 'what_number' => $request->phone, 'what_status' => 'STARTING']);
            sleep(10);

            return redirect('/WhatsappAi/screen/' . $request->bot . '/qrcode')->with('brid', $request->bot);

        endif;
        } catch (\Exception $e) {
      
            notify()->error("Something went wrong Try Later", "Oops");
            return redirect()->back();

        }
    }
    // public function startScreenshot() {

    //             $response = Http::get(env('xxWHATS_APIxx').'/api/screenshot?session=testApi');
    //         if($response->failed() AND $response->status()!=200):
    //           notify()->error("Something went wrong Try Later",$response->status()) ;
    //           return redirect()->back();

    //         else:
    //             $imageData = base64_encode($response);
    //             return view('image', ['screenshot'=>$imageData]);
    //         endif;
    // }
    public function closeSession($key)
    {
        DB::table('bots')->where('rid', '=', $key)->update(['is_whats_linked' => 0, 'what_number' => null, 'what_status' => 'CLOSED']);
        $response = Http::withHeaders([
            'x-api-key' => 'api_adminn@2291',
        ])->post('https://whatsapp.ihsancrm.com/api/sessions/stop', ['logout' => true, 'name' => $key]);
        if ($response->failed()):
            notify()->error("Something went wrong Try Later", $response->status());
            return redirect()->back();
        else:
            notify()->success("Session Has been Logout", $response->status());
            return redirect()->back();
        endif;
    }

}
