<?php

namespace App\Http\Controllers;

use App\Models\SurveyQuestion;
use App\Models\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;

use Validator;

class SMSController extends Controller
{
    public function smsAiCHeck($value = '')
    {
        $query = DB::table('bots')->where('user_id', auth()->user()->id)->where('is_sms_linked', 1);
        $queryCount = $query->count();
        return view('panel/sms/smsai', ['randomID' => false]);
    }
    public function config(Request $request)
    {
        try {
            $randID = getRandomname();

            $response = Http::withHeaders([
                'Authorization' => config('services.xxxx.xxSMSKEYxx'),
            ])->asForm()->post(config('services.xxxx.xxSMSAIxx') . '/sessions/start', [
                'name' => $request->bot,
                'uid' => $request->bot,
                'app_token' => $randID,

            ]);

            if ($response->failed()):
                if ($response->status() == 404) {
                    DB::table('bots')->where('uid', $request->bot)->update(['is_sms_linked' => 0]);
                }
                if ($response->status() == 400) {
                    DB::table('bots')->where('uid', $request->bot)->update(['is_sms_linked' => 0]);
                    notify()->success("Try Again to Link with Bot", "Oops");
                    return redirect('/SMS/stop/' . $request->bot);
                }
                notify()->error("Session Id OR Bot Id is Missing", "Sorry");
                return redirect()->back();
            else:

                $bots = DB::table('bots')->where('uid', $request->bot)->update(['smsAiToken' => $randID, 'is_sms_linked' => 1]);
                if ($bots) {
                    notify()->success("Bot Has Been linked with SMS Ai", "Great");
                    return redirect()->back();
                } else {
                    notify()->error("There some wrong at server side please try later", "Sorry");
                    return redirect()->back();
                }

            endif;
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            notify()->error("There some wrong at server side please try later" . $e->getMessage(), "Sorry");
            return redirect()->back();

        }

    }
    public function tracking($key)
    {
        return view('panel/sms/tracking', ['key' => false, 'botID' => $key]);

    }
    public function chats($key, $receiverUser)
    {
        $instachats = DB::table('ai_sms')->join('bots', 'ai_sms.bot_id', '=', 'bots.smsAiToken')->where('ai_sms.bot_id', $key)->where('ai_sms.from_person', $receiverUser)->get();

        //$ai_sms = DB::table('ai_sms')->where('rid',$key)->where('status',1)->orderBy('created_at','DESC')->get();
        return view('panel/sms/tracking', ['ai_sms' => $instachats, 'key' => true]);

    }
    public function send($key)
    {
       
        $survey_questions = DB::table('survey_questions')->where('bot_id', getBotByRandomID($key)[0]->uid);
        if ($survey_questions->count() > 0) {
            $survey_quest = $survey_questions->get();
            return view('panel/sms/sms_settings', ['messages_data' => false, 'key' => $survey_quest, 'botID' => $key, 'end_message' => $survey_quest[0]->end_message]);
        } else {
            return view('panel/sms/sms_settings', ['messages_data' => false, 'key' => false, 'botID' => $key, 'end_message' => '']);
        }

    }
    public function stopSession($key)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => config('services.xxxx.xxSMSKEYxx'),
            ])->asForm()->post(config('services.xxxx.xxSMSAIxx') . '/sessions/stop', [
                'name' => $key,
            ]);

            if ($response->failed()):

                DB::table('bots')->where('uid', $key)->update(['is_sms_linked' => 0]);
                DB::table('ai_sms')->where('bot_id', getBot($key)[0]->smsAiToken)->delete();

                notify()->success("Bot Has Been unlinked ", "Great");
                return redirect()->back();
            else:

                $bots = DB::table('bots')->where('uid', $key)->update(['is_sms_linked' => 0]);
                DB::table('ai_sms')->where('bot_id', getBot($key)[0]->smsAiToken)->delete();
                if ($bots) {
                    notify()->success("Bot Has Been unlinked ", "Great");
                    return redirect()->back();
                } else {
                    notify()->error("There some wrong at server side please try later", "Sorry");
                    return redirect()->back();
                }

            endif;
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            notify()->error("There some wrong at server side please try later", "Sorry");
            return redirect()->back();

        }
        return view('panel/sms/sms_settings', ['key' => false, 'botID' => $key]);

    }

    public function sendSMS(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'message' => 'min:3|max:155',
        ]);
        $returnMessage = '';
        if ($validator->fails()) {
            notify()->error("Message Length should be between 3 to 155.", "Oops");
            return redirect()->back();
        } else {
            try {
                $reqphoneNumbers = [];
                $reject_phoneNumbers = [];
                if ($request->grabNumbers != "") {
                    $totalNumbers = json_decode($request->grabNumbers,true);
                    // $totalNumbers= array_values($reqphoneNumbers);
                } else {
                    $totalNumbers = explode(",", $request->phoneNumbers);
                }

                foreach ($totalNumbers as $key => $value) {
                    if (isValidPhoneNumber($value)):
                        $reqphoneNumbers[$key] = str_replace('+', '', $value);
                    else:
                        $reject_phoneNumbers[] = $value;
                    endif;

                }
                if(count($reqphoneNumbers)==0){
                    notify()->error("Please enter valid phone numbers", "Oops");
                    return redirect()->back();   
                }

              
                $survey_questionCheck = DB::table('survey_questions')->where('bot_id', getBotByRandomID($request->botKey)[0]->uid);
                $survey_questionArray = [];
                if ($survey_questionCheck->count() > 0) {
                    $end_Message = '';
                    $survey_questionArray[] = $request->message;
                    $survey_questions = $survey_questionCheck->get();
                    foreach ($survey_questions as $key => $value) {
                        $survey_questionArray[++$key] = $value->question;
                        $end_Message = $value->end_message;
                    }

                    foreach ($reqphoneNumbers as $key => $value) {

                        $pendingsms = DB::table('ai_sms')->insert(
                            [
                                'status' => 'pending',
                                'user_id' => Auth::user()->id,
                                'bot_id' => getBotByRandomID($request->botKey)[0]->smsAiToken,
                                'is_bot' => 1,
                                'body' => $request->message, 'from_person' => $value, 'to_person' => $value]);

                    }

                    $response = Http::withHeaders([
                        'Authorization' => config('services.xxxx.xxSMSKEYxx'),
                    ])->post(config('services.xxxx.xxSMSAIxx') . '/start/survey', [
                        'name' => getBotByRandomID($request->botKey)[0]->uid,
                        "numbers" => $reqphoneNumbers,
                        "questions" => $survey_questionArray,
                        'end_Message' => $end_Message,
                    ]);

                    if ($response->failed()):
                        if ($response->status() == 404) {
                            DB::table('bots')->where('uid', getBotByRandomID($request->botKey)[0]->uid)->update(['is_sms_linked' => 0]);
                        }
                        notify()->error("Bot is not linked with SMS Ai", "Oops");
                        return redirect()->back();
                    else:

                        notify()->success("Message has been Sent", "Great");
                        return redirect()->back();

                    endif;
                } else {

                    notify()->error("There is no survey message to send", "Oops");
                    return redirect()->back();
                }
                

            } catch (\Exception $e) {
                Log::info($e->getMessage());
                notify()->error($e->getMessage(), "Sorry");
                return redirect()->back();

            }
        }
    }

    public function survaySettings(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'question' => 'required',
        ]);
        $returnMessage = '';
        if ($validator->fails()) {
            notify()->error("Message Length should be between 3 to 155.", "Great");
            return redirect()->back();
        } else {
            $survey_questions = DB::table('survey_questions')->where('bot_id', getBotByRandomID($request->botKey)[0]->uid)->delete();
            foreach ($request->question as $key => $value) {

                // code...
                if (!empty($value)):
                    SurveyQuestion::create([
                        'user_id' => Auth::user()->id,
                        'bot_id' => getBotByRandomID($request->botKey)[0]->uid,
                        'question' => $value,
                        'end_message' => $request->end_message,
                        'status' => 1,

                    ]);

                endif;
            }
            notify()->success("Question List has been Saved.", "Great");
            return redirect()->back();

        }
    }
    public function submitByFile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'sheet_file' => 'required|file|mimes:csv',
            'column_name' => 'required',
        ]);

        if ($validator->fails()) {
            notify()->error("Column name and Sheet file is required", "Great");
            return redirect()->back();
        } else {
            try {
                $file = $request->file('sheet_file');
                $columnName = $request->input('column_name');
                // Get the file content...
                $fileContent = fopen($file->getPathname(), 'r');
                // Prepare the multipart form-data..
                $multipart = [
                    [
                        'name'     => 'sheet_file',
                        'contents' => $fileContent,
                        'filename' => $file->getClientOriginalName(),
                    ],
                    [
                        'name'     => 'column_name',
                        'contents' => $columnName,
                    ],
                ];
        
                // Send the request to the external API..
                $response = Http::withHeaders( [
                    'Authorization' => config('services.xxxx.xxSMSKEYxx'),
                ])->attach(
                    'sheet_file', 
                    $file->get(), 
                    $file->getClientOriginalName()
                )->post(config('services.xxxx.xxSMSAI_READxx').'/sheet', [
                    'column_name' => $columnName,
                ]);
        
                // Close the file content resource..
                fclose($fileContent);
        
                // Check the response status
                if ($response->successful()) {
                    $dataArray = json_decode($response, true);
                     if (count($dataArray) > 0) {
                       session()->flash('dataArray', $response);
                        notify()->success(count($dataArray) . " Numbers Grabed from Sheet", "Great");
                        $file = public_path('temp_files/'.$request->botKey.'.txt');
                        File::put($file, $response);
                        return redirect()->back()->with('dataArray', true);
                     } else {
                            notify()->error('Data not Found', "Sorry");
                        }
                } else {
                    return response()->json(['message' => 'Failed to upload file', 'error' => $response->body()], $response->status());
                }
    
            } catch (\Exception $e) {
                Log::info("CSV File Upload : " . $e->getMessage());
                notify()->error("There some wrong at server side please try later" . $e->getMessage(), "Sorry");
                return redirect()->back();

            }
        }

    }
    public function submitByLink(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'sheet_id' => 'required',
            'column_name' => 'required',
        ]);

        if ($validator->fails()) {
            notify()->error("Column name and Sheet id is required", "Great");
            return redirect()->back();
        } else {
            try {
                $response = Http::withHeaders([
                    'Authorization' => config('services.xxxx.xxSMSKEYxx'),
                ])->asForm()->post(config('services.xxxx.xxSMSAI_READxx') . '/sheet', [
                    'column_name' => $request->column_name,
                    'sheet_id' => $request->sheet_id,
                ]);

                if ($response->successful()) {
                    $dataArray = json_decode($response, true);
                    if (count($dataArray) > 0) {
                       // session()->flash('dataArray', $response);
                        notify()->success(count($dataArray) . " Numbers Grabed from Sheet", "Great");
                        $file = public_path('temp_files/'.$request->botKey.'.txt');
                        File::put($file, $response);
                        return redirect()->back()->with('dataArray', true);
                    } else {
                        notify()->error('Data not Found', "Sorry");
                    }
                } else {

                    notify()->error($response['message'], "Sorry");
                    return redirect()->back();
                }
            } catch (\Exception $e) {
                Log::info("CSV File Upload : " . $e->getMessage());
                notify()->error("There some wrong at server side please try later" . $e->getMessage(), "Sorry");
                return redirect()->back();

            }
        }

    }

}
