<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Session;
use Laravolt\Avatar\Facade as Avatar;
use Auth;
class manageAuth extends Controller
{
      public function store(Request $request)
    {  
         $formData = $request->validate([
            'email' => ['required','email',Rule::unique('users','email')],
            'password' => 'required|min:3|confirmed',
            'name' => ['required','min:3','max:15'],
        ]);
            $profile=Avatar::create($request->name)->toBase64();
             $newUser = User::create([
                                    'email' => $request->email,
                                    'password' => Hash::make($request->password),
                                    'name' => $request->name,
                                    'status' => 1,
                                    'role' => 'user',
                                    'gauth_type' => 'auth',
                                    'payment_method' => 'stripe',
                                    'profile_img' => $profile,
                                    ]);     
            Auth::login($newUser);
 
            return redirect("dashboard")->with('message','You have signed-in');
      
        
        
          
    }
      public function loginUser(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {

            return redirect()->intended('dashboard')
                        ->withSuccess('Signed in');
        }
   
        return redirect()->back()->with('error', 'Your provided credentials do not match in our records.');

    }

   public function createUser(Request $request)
    {  
         $formData = $request->validate([
            'email' => ['required','email',Rule::unique('users','email')],
            'password' => 'required|min:3',
            'name' => ['required','min:3','max:15'],
        ]);
            $profile=Avatar::create($request->name)->toBase64();
             $newUser = User::create([
                                    'email' => $request->email,
                                    'password' => Hash::make($request->password),
                                    'name' => $request->name,
                                    'status' => 1,
                                    'role' => $request->role,
                                    'gauth_type' => 'auth',
                                    'payment_method' => 'stripe',
                                    'profile_img' => $profile,
                                    ]);     
            notify()->success("Account Has been Created ","Created") ;
            return redirect()->back();
      
        
        
          
    }
    public function updateProfile(Request $request)
    {  
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:3|max:30|string',
            'organization' => 'min:3|max:30|string',
            'phoneNumber' =>  'required',
            
        ]);
    if ($validator->fails()) {
        notify()->error("Some fields are missing ","Oops") ;
            return redirect()->back()->withErrors($validator)->withInput();
    }else{
      
        $data= [
            'name' => $request->name,
            'organization' => $request->organization,
            'phone' =>  $request->phoneNumber,
            'address' => $request->address,
            'state' =>  $request->state,
            'zipcode' =>  $request->zipcode,
            'country'=>$request->country,
            'timeZone'=>$request->timeZone,
            'payment_method'=>$request->paymentMethod,
        ];
        $updataData= DB::table('users')->where('id',Auth::user()->id)->update($data);
            if ($updataData) {
                notify()->success("Profile Data has been updated","Good") ;
              return redirect()->back();

            } else{ notify()->error("Some thing went wrong","Oops") ;
                    return redirect()->back();

             }
            
    }
    }
    public function updatePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'currentPassword' => 'required|min:3|max:30|',
            'password' => 'required|min:3|confirmed',
        ]);
    if ($validator->fails()) {
        notify()->error("Some fields are missing ","Oops") ;
            return redirect()->back()->withErrors($validator)->withInput();
    }else{
            if (Hash::check($request->currentPassword,auth('sanctum')->user()->password)) {
                DB::table('users')->where('id',Auth::user()->id)->update(['password'=>$request->password]);
            }else{
                notify()->error("Invalid Current Password","Oops") ;
                return redirect()->back();
            }

         }
    }

}
