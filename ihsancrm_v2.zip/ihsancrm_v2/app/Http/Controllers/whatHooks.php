<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Validator;

class whatHooks extends Controller
{
 public function checkHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
        $dataGet=DB::table('bots')->where('rid','=',$request->session_id);

        if ($dataGet->count()>0):
            $data=$dataGet->get();
            $response=['message'=>$data[0]->uid,
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing",
            'status'=>404,
        ];
        return response($response,404);
        endif;
             

  }
         return response($response,201);
}
public function sentHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
        'message' => 'required',
        'to' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
        $data=[
            'client_number'=>$request->to,
            'message'=>$request->message,
            'msg_status'=>1,
            'bot_rid'=>$request->session_id,
        ];
        $dataGet=DB::table('whatai_chats')->insert($data);

        if ($dataGet):
            $response=['message'=>'Message Saved ',
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing. ",
            'status'=>404,
        ];
        return response($response,404);
        endif;
  }


}
public function receiveHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
        'message' => 'required',
        'from' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
        $data=[
            'client_number'=>$request->from,
            'message'=>$request->message,
            'msg_status'=>2,
            'bot_rid'=>$request->session_id,
        ];
        $dataGet=DB::table('whatai_chats')->insert($data);

        if ($dataGet):
            $response=['message'=>'Message Saved ',
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing. ",
            'status'=>404,
        ];
        return response($response,404);
        endif;
  }


}
public function unsentHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
        'message' => 'required',
        'to' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
        $data=[
            'client_number'=>$request->from,
            'message'=>$request->message,
            'msg_status'=>0,
            'bot_rid'=>$request->session_id,
        ];
        $dataGet=DB::table('whatai_chats')->insert($data);

        if ($dataGet):
            $response=['message'=>'Message Saved ',
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing. ",
            'status'=>404,
        ];
        return response($response,404);
        endif;
  }


}

}
// https://cd49-139-135-53-130.ngrok.io/api/receive-sms