<?php

namespace App\Http\Controllers;

use App\Models\Bot;
use App\Models\User;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\Rules\File;
use Validator;


class IhsanBot extends Controller
{
    public function customize(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'bot_name' => 'required|min:3|max:30',
            'company_name' => 'required|min:3|max:30',

        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        } else {
            if (!empty($request->customString)) {
                $bot = Bot::where('uid', $request->customString);
                if ($bot->count() > 0) {
                    $botData = $bot->first();
                    $filePath_Comp_c = $botData->company_logo;
                    $filePath_bot_c = $botData->bot_logo;

                    if ($request->file('company_logo')) {
                        $file_comp = $request->file('company_logo');
                        $fileName_Comp = "cmp_" . time() . '_' . base64_encode($file_comp->getClientOriginalName()) . "." . $file_comp->getClientOriginalExtension();
                        $filePath_Comp = $file_comp->storeAs('uploads', $fileName_Comp, 'public');
                        $filePath_Comp_c = '/storage/' . $filePath_Comp;
                    }
                    if ($request->file('bot_logo')) {
                        $file_logo = $request->file('bot_logo');
                        $fileName_bot = "bot_" . time() . '_' . base64_encode($file_logo->getClientOriginalName()) . "." . $file_logo->getClientOriginalExtension();
                        $filePath_bot = $file_logo->storeAs('uploads', $fileName_bot, 'public');
                        $filePath_bot_c = '/storage/' . $filePath_bot;
                    }
                    $bot = $bot->update([
                        'bot_name' => $request->bot_name,
                        'company_name' => $request->company_name,
                        'welcome_message' => $request->welcome_message,
                        'company_logo' => $filePath_Comp_c,
                        'bot_logo' => $filePath_bot_c,
                    ]);
                    notify()->info("Bot has been Updated", "Great");
                    return redirect()->route('ihsanbot.custom', ['key', $request->customString]);
                }
                notify()->error("Some thing went wrong", "Oops");
                return redirect()->back();
            } else {

                $filePath_Comp_c = $filePath_bot_c = 'assets/img/preview.png';
                if ($request->file('company_logo')) {
                    $file_comp = $request->file('company_logo');
                    $fileName_Comp = "cmp_" . time() . '_' . base64_encode($file_comp->getClientOriginalName()) . "." . $file_comp->getClientOriginalExtension();
                    $filePath_Comp = $file_comp->storeAs('uploads', $fileName_Comp, 'public');
                    $filePath_Comp_c = '/storage/' . $filePath_Comp;
                }
                if ($request->file('bot_logo')) {
                    $file_logo = $request->file('bot_logo');
                    $fileName_bot = "bot_" . time() . '_' . base64_encode($file_logo->getClientOriginalName()) . "." . $file_logo->getClientOriginalExtension();
                    $filePath_bot = $file_logo->storeAs('uploads', $fileName_bot, 'public');
                    $filePath_bot_c = '/storage/' . $filePath_bot;
                }
                $nameofNBB = strtolower(trim($request->bot_name)) . time();

                $uniq = str_replace('/', '', Hash::make(($nameofNBB)));
                $bot = Bot::create([
                    'bot_name' => $request->bot_name,
                    'user_id' => Auth::user()->id,
                    'company_name' => $request->company_name,
                    'bot_color' => $request->bot_color,
                    'welcome_message' => $request->welcome_message,
                    'company_logo' => $filePath_Comp_c,
                    'bot_logo' => $filePath_bot_c,
                    'uid' => $uniq,
                    'bot_sts' => 1,
                    'rid' => getRandomname(),
                    'webAiToken' => $nameofNBB,
                ]);

                if ($bot) {
                    notify()->success("Bot has been created", "Good");
                    return redirect('ihsanbot/customize/' . $uniq . "");
                } else {
                    notify()->error("Some thing went wrong", "Oops");
                    return redirect()->back();
                }
            }

        }
    }
    public function updateData($customize, $key)
    {
        $botData = DB::table('bots')->where('uid', $key)->get();
        if ($botData) {
            return view('panel/botDetails', ['uid' => $key, 'tab' => $customize, 'runData' => $botData]);
        } else {
            return redirect('ihsanbot/customize');
        }
    }
    public function botFile(Request $request, $key)
    {
        $validator = Validator::make($request->all(), [
            'files' => 'required',

        ]);
        if ($validator->fails()) {

            $messages = json_decode(json_encode($validator->messages()), true);

            notify()->error(reset($messages)[0], "oops");
            // $response = ['error' => 404, "message" => "file not received Valid "];

        } else {
            try {
                if ($request->file('files')) {

                    $oldData = getWhere('bots', 'uid', $key);
                    $file_comp = $request->file('files');
                    $source_file = ($oldData[0]->source_file != null) ? json_decode($oldData[0]->source_file) : [];
                    $source_file[] = $file_comp->getClientOriginalName();
                    $reader = new \Asika\Pdf2text;
                    $decode = $reader->decode($file_comp->path());
                    if ($decode != '') {
                        $response = Http::withHeaders([
                            'Authorization' => config('services.xxxx.xxWEBxKEYxx'),
                        ])->asForm()->post(config('services.xxxx.xxWEBxBOTxx') . '/create/embeddings', [
                            'uid' => $key,
                            'text' => $decode,
                        ]);
                        if ($response->failed()):
                            // return $response->body();
                            notify()->error("Something Went Wrong.", $response->status());
                        else:
                            $ret = DB::table('bots')->where('uid', $key)->update(['source_file' => json_encode($source_file)]);
                            notify()->success("Bot Has been Trained", "Great !");
                        endif;
                    } else {
                        notify()->error("Unable to extract text from PDF.", "oops");

                    }

                } else {
                    notify()->error("File not received file", "Oops");
                    $response = ['status' => 'error', "message" => "file not received file"];
                }
            } catch (\Exception $e) {
                notify()->error($e->getMessage(), "Oops");

            }

        }
        return redirect()->back();

    }
    public function showBots()
    {
        $botsData = Bot::where('bot_sts', 1)->paginate(6);
        $title = 'Disable Bot!';
        $text = "Are you sure you want to disable?";
        confirmDelete($title, $text);
        return view('admin.bots_list', compact('botsData'));
    }
    public function disableBot($key)
    {
        $botsData = Bot::where('uid', $key)->update(['bot_sts' => 0]);
        return redirect('admin/bots');
    }
}

/* if($req->file()) {

$filePath = $req->file('file')->storeAs('logos', $fileName, 'public');
}*/
