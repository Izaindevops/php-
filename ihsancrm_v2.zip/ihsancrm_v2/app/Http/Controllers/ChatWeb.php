<?php

namespace App\Http\Controllers;

use App\Models\botchat;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Validator;

class ChatWeb extends Controller
{
    public function __construct()
    {
        ini_set('max_execution_time', 2200);
    }
    public function sendMessage(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'message' => 'required|string',
        ]);
        if ($validator->fails()) {
            $response = ['error' => 404, "message" => "Invalid message"];
        } else {
            try {
                $message = botchat::create([
                    'send_id' => Auth::user()->id,
                    'bot_id' => getBot($request->randomKey)[0]->id,
                    'receive_id' => getBot($request->randomKey)[0]->id,
                    'is_bot' => 0,
                    'sender_email' => Auth::user()->email,
                    'sender_name' => Auth::user()->name,
                    'message' => $request->message,
                ]);


                $response = Http::withHeaders([
                    'Authorization' => config('services.xxxx.xxWEBxKEYxx'),
                ])->asForm()->post(config('services.xxxx.xxWEBxBOTxx').'/ask/query', [
                    'uid' => $request->randomKey,
                    'query' => $request->message,
                ]);
                if ($response->failed()):
                    $response = ['error' => 404, "message" => "Bot not working Try Later"];
                else:
                    $ret = DB::table('botchats')->insert([
                        'send_id' => getBot($request->randomKey)[0]->id,
                        'bot_id' => getBot($request->randomKey)[0]->id,
                        'receive_id' => Auth::user()->id,
                        'is_bot' => 1,
                        'sender_email' => Auth::user()->email,
                        'sender_name' => Auth::user()->name,
                        'message' => $response['response'],
                    ]);
                    if ($ret) {
                        $response = ['success' => 200, "message" => $response['response']];
                    } else {
                        $response = ['error' => 404, "message" => "Bot not working"];

                    }
                endif;
            } catch (\Exception $e) {
                $response = ['error' => $e->getMessage(), "message" => "Bot not working"];
                Log::info($e->getMessage());

            }
        }
        echo json_encode($response);
    }
    public function extractText(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'randomKey' => 'required',
        ]);

        if ($validator->fails()) {
            $response = ['status' => 404, "message" => "file not received Valid "];
            notify()->error("Invalid Key Try Later", "Oops");
            return redirect('ihsanbot/source/' . $request->randomKey . "");

        } else {
            try {
                if (countWhere('bots', 'uid', $request->randomKey) > 0) {
                    $getSource = getWhere('bots', 'uid', $request->randomKey);
                    $source_file = ($getSource[0]->source_file != null) ? json_decode($getSource[0]->source_file) : [];
                    if (count($source_file) > 0) {
                        $headers = [
                            'Content-Type' => 'application/json',
                        ];

                        $restText = '';

                        foreach ($source_file as $file_s):
                            //  return url('storage/'.$file_s);
                            $reader = new \Asika\Pdf2text;
                            $decode = $reader->decode('storage/' . $file_s);
                            $restText .= $decode;
                        endforeach;
                        if (!empty($restText)) {
                            // code...

                            $response = Http::asForm()->post(config('services.xxxx.xxBOTTRAINERxx') . '/embeddings', [
                                'uid' => $request->randomKey,
                                'text' => $restText,
                            ]);
                            if ($response->failed()):
                                // return $response->body();
                                notify()->error("Something Went Wrong.", $response->status());
                                return redirect()->back();
                            else:
                                notify()->success("Bot Has been Trained", "Great !");
                                return redirect()->back();
                            endif;
                        } else {
                            notify()->error("Something Wrong In your Provided PDF We Can't Retrieve Data from it", "Oops !");
                            return redirect()->back();
                        }

                    }

                }
                notify()->error("Invalid Key Try Later", "Oops");
                return redirect('ihsanbot/customize/' . $request->randomKey . "");
            } catch (\Exception $e) {
                Log::info($e->getMessage());
                notify()->error("there some wrong at server side please try later", "Sorry");
                return redirect('ihsanbot/customize/' . $request->randomKey . "");

            }

        }
    }
}
