<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Validator;

class FaceController extends Controller
{
    public function home()
    {

        return view('panel/facebook/facebook');
    }
    public function checkSession($key)
    {
        return view('panel/facebook/session', ['brid' => $key]);

    }
    public function tracking($key)
    {
        return view('panel/facebook/tracking', ['key' => false, 'botID' => $key]);

    }
    public function chats($key, $receiverUser, $senderUser)
    {
        $facechats = DB::table('facechats')->join('bots', 'facechats.bot_id', '=', 'bots.id')->where('bots.rid', $key)->where('facechats.account_name', $senderUser)->where('facechats.receiver_name', $receiverUser)->get();
        //$facechats = DB::table('facechats')->where('rid',$key)->where('status',1)->orderBy('created_at','DESC')->get();
        return view('panel/facebook/tracking', ['facechats' => $facechats, 'key' => true]);

    }

    public function checkSessionStatus(Request $request)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => config('services.xxxx.xxFBxKEYxx'),
            ])->get(config('services.xxxx.xxFBxAIxx') . '/status/session?session=' . $request->email);

            if ($response->failed()):
                $bots = DB::table('bots')->where('face_account_name', $request->email)->update(['is_face_linked' => 0, 'face_account_name' => null]);
                $responseD = ['message' => 'You Account not linked with Ai Please Try Again', 'status' => 'error'];

            else:

                if ($response['status'] == 'WORKING') {
                    $bots = DB::table('bots')->where('face_account_name', $request->email)->update(['is_face_linked' => 1]);
                    $responseD = ['message' => 'Your Account is Linked With Ai ', 'status' => $response['status']];

                } elseif ($response['status'] == '2FA_REQUIRED') {
                $responseD = ['message' => $response['message'], 'status' => $response['status']];
                } else {
                    if ($response['status'] == "ERROR_OCCURRED") {
                        $bots = DB::table('bots')->where('face_account_name', $request->email)->update(['is_face_linked' => 0, 'face_account_name' => null, 'face_page_url' => null]);

                    }
                    $responseD = ['message' => $response['message'], 'status' => $response['status']];
                }

            endif;
        } catch (\Exception $e) {
            $responseD = ['message' => 'Account is already Unlinked Please Link again ' . $e->getMessage(), 'status' => 'error'];

        }
        return response()->json($responseD, 200);
    }
    public function stopSession($key)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => config('services.xxxx.xxFBxKEYxx'),
            ])->asForm()->post(config('services.xxxx.xxFBxAIxx') . '/sessions/stop', [
                'session' => $key,

            ]);

            if ($response->failed()):
                DB::table('facechats')->join('bots', 'facechats.bot_id', '=', 'bots.id')->where('bots.rid', $key)->delete();
                DB::table('bots')->where('rid', $key)->update(['is_face_linked' => 0]);
                notify()->success("Account Has Been unLinked", "Great");
                return redirect()->back();

            else:
                DB::table('facechats')->join('bots', 'facechats.bot_id', '=', 'bots.id')->where('bots.rid', $key)->delete();
                $bots = DB::table('bots')->where('rid', $key)->update(['is_face_linked' => 0]);
                notify()->success("Account Has Been unlinked", "Great");
                return redirect()->back();

            endif;

        } catch (\Exception $e) {
            Log::info($e->getMessage());
            notify()->error("There some wrong at server side please try later", "Sorry");
            return redirect()->back();

        }

    }
    public function twoFactor(Request $request)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => config('services.xxxx.xxFBxKEYxx'),
            ])->asForm()->post(config('services.xxxx.xxFBxAIxx') . '/2fa/code', [
                'session' => $request->email,
                'code' => $request->code,

            ]);

            if ($response->failed()):
                if ($response->status()==404) {
                    $responseD = ['message' => $response['message'], 'status' => 'NOT_FOUND'];   
                }else{
                    $responseD = ['message' => $response['message'], 'status' => 'WRONG_CODE'];  
                }
                 $bots = DB::table('bots')->where('face_account_name', $request->email)->update(['is_face_linked' => 0]);

            else:
                $responseD = ['message' =>"Account Has Been Linked", 'status' => 'SUCCESS'];  
                $bots = DB::table('bots')->where('face_account_name', $request->email)->update(['is_face_linked' => 1]);
                
            endif;

        } catch (\Exception $e) {

            Log::info($e->getMessage());
            $responseD = ['message' => "There some wrong at server side please try later", 'status' => 'ERROR_OCCURRED']; 

        }
        return response()->json($responseD, 200);
    }
    public function config(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'bot' => 'required',
            'email' => 'email|required',
            'password' => 'required',
            'page_url' => 'required',

        ]);
        if ($validator->fails()) {
            $response = ['message' => 'Some fields are missing', 'status' => 'error'];
            // notify()->error("Some fields are missing ", "Oops");
            // return redirect()->back();
        } else {
            $checkAlreadyExists = DB::table('bots')->where('rid', $request->bot)->where('is_face_linked', 1)->count();
            $EmailAlreadyExists = DB::table('bots')->where('face_account_name', $request->email)->count();
            $countUser = DB::table('bots')->where('rid', $request->bot);
            if ($checkAlreadyExists > 0 && $countUser->count() < 0 && $EmailAlreadyExists > 0) {
                //  notify()->info("Bot is Already Linked with Another Account","Sorry");
                //        return redirect()->back();
                $response = ['message' => 'Bot is Already Linked with Another Account', 'status' => 'error'];
            } else {
                try {
                    $userID = $countUser->get();
                    // return config('services.xxxx.xxBOTTRAINERxx');
                    $response = Http::withHeaders([
                        'Authorization' => config('services.xxxx.xxFBxKEYxx'),
                    ])->asForm()->timeout(130)->post(config('services.xxxx.xxFBxAIxx') . '/sessions/start', [
                        'name' => $request->email,
                        'email' => $request->email,
                        'password' => $request->password, 
                        'asset_id' => $request->page_url,
                        'uid' => $userID[0]->uid,
                    ]);
                    if ($response->failed()):
                        $responseD = ['message' => $response['message'], 'status' => 'error'];
                        if($response->status()==400):
                            $responseD = ['message' => $response['message'], 'status' => 'success', 'email' => $request->email];
                        endif;
              
                    else:
                        if ($response['status'] == 'STARTING'):
    
                            $bots = DB::table('bots')->where('rid', $request->bot)->update(['is_face_linked' => 0, 'face_account_name' => $request->email, 'face_page_url' => $request->page_url]);

                            $responseD = ['message' => 'Please Wait We are Linking With Ai', 'status' => 'success', 'email' => $request->email];
        
                        else:
                            $responseD = ['message' => 'Unable to Linking Please try Again', 'status' => 'error'];
                        endif;
                    endif;
                } catch (\Exception $e) {
                    Log::info($e->getMessage());
                    $responseD = ['message' => 'Unable to Linking Please try Again', 'status' => 'error'];
                    //   notify()->error("There some wrong at server side please try later","Sorry") ;
                    //   return redirect()->back();

                }
            }

        }
        return response()->json($responseD, 200);
    }
}
