<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class DashboardCon extends Controller
{
    public function smsAiCHeck($value='')
    {
          $query=DB::table('bots')->where('user_id',auth()->user()->id)->where('is_sms_linked',1);
                    $queryCount=$query->count();
                     return view('panel/sms/smsai',['randomID'=>false]);

                    // if ($queryCount>0){

                    //      return view('panel/sms/sms_lists');
                    // }else{
                       
                    // }
        // 
        //
    }
public function config(Request $request)
    {
       $bots= DB::table('bots')->where('rid',$request->bot);
       $randID=getRandomname();
       $bots->update(['smsAiToken'=>$randID,'is_sms_linked'=>1]);
     notify()->success("Bot has been Linked","Great");

       return redirect()->back();
    }
 public function tracking($key)
{
   return view('panel/insta/tracking',['key'=>false,'botID'=>$key]);

}
public function chats($key,$receiverUser,$senderUser)
{
    $instachats = DB::table('instachats')->join('bots', 'instachats.bot_id', '=', 'bots.bot_id')->where('bots.rid',$key)->where('instachats.account_name',$senderUser)->where('instachats.receiver_name',$receiverUser)->get();
    //$instachats = DB::table('instachats')->where('rid',$key)->where('status',1)->orderBy('created_at','DESC')->get();
   return view('panel/insta/tracking',['instachats'=>$instachats,'key'=>true]);

}

}
