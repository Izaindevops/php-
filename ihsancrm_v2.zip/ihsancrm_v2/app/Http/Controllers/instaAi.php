<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Validator;

class instaAi extends Controller
{
    public function sentHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
        'message' => 'required',
        'to' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
        $botData=getBotByRandomID($request->session_id);
        $data=[
            'receiver_name'=>$request->to,
            'message'=>$request->message,
            'status'=>1,
            'is_bot'=>1,
            'bot_id'=>$botData[0]->id,
            'account_name'=>($botData[0]->insta_account_name)?$botData[0]->insta_account_name:"n/a",
        ];
        $dataGet=DB::table('instachats')->insert($data);

        if ($dataGet):
            $response=['message'=>'Message Saved ',
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing. ",
            'status'=>404,
        ];
        return response($response,404);
        endif;
  }


}
public function receiveHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
        'message' => 'required',
        'from' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
         $botData=getBotByRandomID($request->session_id);
        $data=[
            'receiver_name'=>$request->from,
            'message'=>$request->message,
            'status'=>1,
            'is_bot'=>0,
            'bot_id'=>$botData[0]->id,
            'account_name'=>($botData[0]->insta_account_name)?$botData[0]->insta_account_name:"n/a",
        ];
        $dataGet=DB::table('instachats')->insert($data);

        if ($dataGet):
            $response=['message'=>'Message Saved ',
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing. ",
            'status'=>404,
        ];
        return response($response,404);
        endif;
  }


}
public function unsentHook(Request $request) {
    $validator = Validator::make($request->all(), [
        'session_id' => 'required',
        'message' => 'required',
        'to' => 'required',
    ]);

    if ($validator->fails()) {
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>404,
        ];
        return response($response,404);
    }else{
         $botData=getBotByRandomID($request->session_id);
        $data=[
            'receiver_name'=>$request->to,
            'message'=>$request->message,
            'status'=>1,
            'is_bot'=>1,
            'bot_id'=>$botData[0]->id,
            'account_name'=>($botData[0]->insta_account_name)?$botData[0]->insta_account_name:"n/a",
        ];
        $dataGet=DB::table('instachats')->insert($data);

        if ($dataGet):
            $response=['message'=>'Message Saved ',
            'status'=>200,
        ];
        return response($response,200);
        else:
            $response=['message'=>"Sorry You are Sending Invalid Data or Something Missing. ",
            'status'=>404,
        ];
        return response($response,404);
        endif;
  }


}
}
