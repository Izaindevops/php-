<?php


namespace App\Http\Controllers;


use Socialite;

use Auth;

use Exception;
use App\Models\User;
use Laravolt\Avatar\Facade as Avatar;


class GoogleLogin extends Controller
{
   

    public function __construct()

    {

        $this->middleware('guest')->except('logout');

    }

    public function redirectToGoogle()

    {

        return Socialite::driver('google')->redirect();

    }

    public function handleGoogleCallback()

    {

        try {

            $user = Socialite::driver('google')->user();

            $finduser = User::where('email', $user->email)->first();

            if($finduser){

                Auth::login($finduser);

                return  redirect('/');

            }else{
                $profile=Avatar::create($user->name)->toBase64();
                $newUser = User::create([

                    'name' => $user->name,
                    'email' => $user->email,
                    'google_id'=> $user->id,
                     'gauth_type'=> 'google',
                    'status'=>1,
                    'isPaid'=>0,
                    'password' =>12345,
                    'role'=>'user',
                    'payment_method' => 'stripe',
                    'profile_img' => $profile,

                ]);

                Auth::login($newUser);

                return redirect('/dashboard');

            }

        } catch (Exception $e) {
                        return $e->getMessage();

            //dd($e->getMessage());


        }

    }

}



