<?php

namespace App\Http\Controllers;
use Stripe\StripeClient;
use Illuminate\Http\Request;
use Stripe\Exception\CardException;
use Stripe;
use Illuminate\Support\Facades\DB;
use Auth;
class stCheckOut extends Controller
{
    public function index()
    {
        return view('stripe');
    }

    public function store($request)


    { 
        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        Stripe\Charge::create ([
                "amount" => 5*100,
                "currency" => "USD",
                "source" => $request->stripeToken,
                "description" => "This payment is testing purpose",
        ]);
   
        Session::flash('success', 'Payment Successfull!');
           
        return back();
    }
    function flash($req){

$planData=getPlan(base64_decode($req),'n');
if ($planData) {
     Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
    $checkout_session=Stripe\Checkout\Session::create([
  'line_items' => [[
                'price_data' => [
                  'currency' => 'usd',
                  'unit_amount' =>(int)$planData[0]->price*100,
                  'product_data' => [
                    'name' => base64_decode($req).'Paid Plan for Year ',
                  ],
                ],
                'quantity' =>1,
              ]],
  'phone_number_collection' => [
    'enabled' => true,
  ],
  'mode' => 'payment',
  'payment_method_types' => ['card'],
  'success_url' => url('').'/payment/success',
  'cancel_url' => url('').'/settings/billing',
]);
    
  return redirect($checkout_session->url);   
}else{
        notify()->error("Invalid Session Try Again".$req,"Oops") ;
        return redirect('settings/billing');
   }

}
   function getId(){
    $toUpDate=[
            'isPaid'=>1,
            'planActiveTime'=>date('d-m-Y h:m:s'),
            'planId'=>base64_decode(session('planToken')),
            ];
        $toInsert=[
            'user_id'=>Auth::user()->id,
            'plan'=>base64_decode(session('planToken')),
            ];
            $upData=DB::table('users')->where('id','=',Auth::user()->id)->update($toUpDate); 
                if ($upData) {
                    $setData=DB::table('payments')->insert($toInsert); 
                     session()->pull('planToken',null);
                    session()->pull('planPrice',null);
                      notify()->success("Your Plan has been Activated","Good") ;
                        return redirect('settings/billing');
                }else{
                       notify()->error("Invalid Session Try Again","Oops") ;
                        return redirect('settings/billing');
                }
  }
}
