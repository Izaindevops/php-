<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use Auth;
use App\Models\Support;

class SupportSys extends Controller
{
    public function create(Request $request) {
        $validator = Validator::make($request->all(), [
            'title' => 'required|regex:/^[a-zA-Z ]*$/|min:3|max:24',
            'message' => 'required|min:2|max:120',
        ]);
    if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
    }else{
        $filePath_of_file=null;
        if ( $request->file('attachment')) {
            $file_comp = $request->file('attachment');
            $fileName_Comp = "attachment_".time().'_'.base64_encode($file_comp->getClientOriginalName()).".".$file_comp->getClientOriginalExtension();
             $filePath_Comp = $file_comp->storeAs('uploads', $fileName_Comp, 'public');
             $filePath_of_file='/storage/' . $filePath_Comp;
        }
        $currentTimestamp = microtime(true) * 1000; 
         $ret= Support::create([
            'support_title'  =>$request->title,
            'user_id'  =>Auth::user()->id,
            'support_token'=>str_replace('.','_',str_replace(' ','_',$request->title).'_'.$currentTimestamp),
            'support_message'  =>$request->message,
            'support_attachment'  => $filePath_of_file,
            'support_status'=>0,
            'by_support'=>0,
            ]);
            if ($ret) {
                notify()->success("Your Ticket has been Submited We'll contact you back soon","Good") ;
                return redirect('/support-messages/list');

            } else{ notify()->error("Some thing went wrong","Oops") ;
                    return redirect()->back();

             }
            
    }
    }
    public function adminreply(Request $request) {
        $validator = Validator::make($request->all(), [
            'message' => 'required|min:2|max:120',
            'support'=>'required',
        ]);
    if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
    }else{
       
        $support= DB::table('supports')->where('support_token',$request->support);
        if($support->count()>0):
            $setSupport=$support->get();
            $data = [
            
                'user_id'  =>Auth::user()->id,
                'support_message'  =>$request->message,
                'by_support'=>1,
                'support_id'=>$setSupport[0]->id,
            ];
         $ret= DB::table('support_messages')->insert($data);
            if ($ret) {
                $support->update(['support_status'=>1,'user_readed'=>0]);
                notify()->success("Ticket has been Submited","Good") ;
                return redirect('/admin/support-messages');

            } else{ notify()->error("Some thing went wrong","Oops") ;
                    return redirect()->back();

             }
        else:
                notify()->error("Some thing went wrong","Oops") ;
                return redirect()->back();
        endif;
            
    }
    
    }
    public function customerReply(Request $request) {
        $validator = Validator::make($request->all(), [
            'message' => 'required|min:2|max:120',
            'support'=>'required',
        ]);
    if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
    }else{
       
        $support= DB::table('supports')->where('support_token',$request->support);
        if($support->count()>0):
            $setSupport=$support->get();
            $data = [
            
                'user_id'  =>Auth::user()->id,
                'support_message'  =>$request->message,
                'by_support'=>0,
                'support_id'=>$setSupport[0]->id,
            ];
         $ret= DB::table('support_messages')->insert($data);
            if ($ret) {
                $support->update(['support_readed'=>0]);
                notify()->success("Ticket has been Submited","Good") ;
                return redirect('/support-messages/list');

            } else{ notify()->error("Some thing went wrong","Oops") ;
                    return redirect()->back();

             }
        else:
                notify()->error("Some thing went wrong","Oops") ;
                return redirect()->back();
        endif;
            
    }
    
    }
}
