<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
    use GuzzleHttp\Exception\GuzzleException;
    use GuzzleHttp\Client;
    use ClickSend\Configuration;
    use ClickSend\Api\SMSApi;
    use Illuminate\Support\Facades\DB;
    use Validator;
    use Auth;

class SmsClicks extends Controller
{

public function sendSM(Request $request)
{
    $validator = Validator::make($request->all(), [
        'message' => 'min:3|max:155',
    ]);
    $returnMessage='';
    if ($validator->fails()) {
          notify()->error("Message Length should be between 3 to 155.","Oops") ;
        return redirect()->back();
    }else{
        $config = Configuration::getDefaultConfiguration()->setUsername('info@ihsancrm.com')->setPassword('4121BFA1-F383-2AFA-0C7F-70EB9DCFBEC9');
        $apiInstance = new SMSApi(new Client(),$config);
       $totalNumbers= explode(",", $request->phoneNumbers);
       $dataArray=[];
       foreach ($totalNumbers as $key => $value) {
             $msg = new \ClickSend\Model\SmsMessage();
            $msg->setBody($request->message); 
           // $msg->setTo('+61411111111'); 
            $msg->setTo($value);
            $msg->setSource("sdk");
            $dataArray[]=$msg;
       } /*end of foreach*/
       //return $dataArray;
        $sms_messages = new \ClickSend\Model\SmsMessageCollection(); 
        $sms_messages->setMessages($dataArray);
        try {
            $results = $apiInstance->smsSendPost($sms_messages);
           $result=json_decode($results,true);
            if ($result['response_code']=="SUCCESS") {
                foreach ($result['data']['messages'] as $key => $value) {
                    if ($value['status']=="SUCCESS") {
                        $toInsert=[
                            'user_id'=>Auth::user()->id,
                            'bot_id'=>Auth::user()->id,
                            'body'=>$request->message,
                            'to_person'=>$value['to'],
                            'from_person'=>$value['from'],
                            'country'=>$value['country'],
                            'carrier'=>$value['carrier'],
                            'sms_status'=>"SENT",
                            'system_date'=>$value['date'],
                            'status'=>$value['status'],
                            'message_price'=>$value['message_price'],
                            'message_id'=>$value['message_id'],
                            'currency'=>$result['data']['_currency']['currency_name_short'],
                        ];


                    }else{
                           $toInsert=[
                            'user_id'=>Auth::user()->id,
                            'bot_id'=>Auth::user()->id,
                            'body'=>$request->message,
                            'to_person'=>$value['to'],
                            'sms_status'=>"FAILED",
                            'status'=>$value['status'],
                            'message_id'=>$value['message_id'],
                            'currency'=>$result['data']['_currency']['currency_name_short'],
                        ];
                        $returnMessage.='<li class="text-danger">'.$value['to'].' is invalid number</li>';
                    }
                }
                  $setData=DB::table('ai_SMS')->insert($toInsert); 
                    if ($setData) {
                        if (empty($returnMessage)) {
                             notify()->success("SMS has been sent ","Great !") ;
                        }else{
                             notify()->success("SMS has been sent on some numbers","Great !") ;
                        }
                       
                        return redirect()->back()->with('error',$returnMessage);
                    }else{
                        notify()->error("Something Went Wrong.","Oops") ;
                        return redirect()->back()->with('error',$returnMessage);
                    }
               
            }else{
                notify()->error("Something Went Wrong.","Oops") ;
                        return redirect()->back();

            }

        } catch (Exception $e) {
             notify()->error("Something Went Wrong.","Oops") ;
                        return redirect()->back();
        } /*end of try catch*/

    }
    return json_encode($response);

    
}
public function checkAcc()
{
  $config = Configuration::getDefaultConfiguration()
            ->setUsername('arslan.ahmad@medtronix.world')
    ->setPassword('7648BA7F-0D2D-BC73-2AB0-F2F0372A246E');

    $apiInstance = new SMSApi(new Client(),$config);
    $q = "sms/inbound"; // string | Your keyword or query.
    $page = 1; // int | Page number
    $limit = 10; // int | Number of records per page

    try {
        $result = $apiInstance->smsInboundGet($q, $page, $limit);
        print_r($result);
    } catch (Exception $e) {
        echo 'Exception when calling SMSApi->smsInboundGet: ', $e->getMessage(),    PHP_EOL;
    }
}
public function sendMessageTo(){
    $config = Configuration::getDefaultConfiguration()
            ->setUsername('arslan.ahmad@medtronix.world')
    ->setPassword('7648BA7F-0D2D-BC73-2AB0-F2F0372A246E');

$apiInstance = new SMSApi(new Client(),$config);
$msg = new \ClickSend\Model\SmsMessage();
 $phone_numbers = ['+923070882337', '+447462318020','+447801326650'];
$msg->setBody("Hi Testing Ai CRM"); 
$msg->setTo('++447801326650');
$msg->setSource("sdk");

/*$msg1 = new \ClickSend\Model\SmsMessage();
$msg1->setBody("test body"); 
$msg1->setTo('+923070882337');
$msg1->setSource("sdk");*/

// \ClickSend\Model\SmsMessageCollection | SmsMessageCollection model
$sms_messages = new \ClickSend\Model\SmsMessageCollection(); 
$sms_messages->setMessages([$msg]);

try {
    $result = $apiInstance->smsSendPost($sms_messages);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling SMSApi->smsSendPost: ', $e->getMessage(), PHP_EOL;
}

}

public function testApiWeb()
{
    $client = new Client();
$headers = [
  'Content-Type' => 'application/json'
];
$params=array(
'token' => '{TOKEN}'
);
$request = new Request('GET', 'https://api.ultramsg.com/{INSTANCE_ID}/instance/qrCode?'.http_build_query($params), $headers);
$res = $client->sendAsync($request)->wait();
echo $res->getBody();
}





}
