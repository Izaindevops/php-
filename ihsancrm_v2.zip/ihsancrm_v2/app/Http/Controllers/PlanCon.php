<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use Auth;


class PlanCon extends Controller
{
    public function upgrade($plan)
    {
        $plans=DB::table('plans')->where('name','plan')->get();
        if ($plans) {
           if (Auth::user()->payment_method="stripe") {
                return redirect('stripe/checkout/'.base64_encode($plan));
           }elseif (Auth::user()->payment_method="paypal") {

              return redirect('paypal/checkout');
           }
         notify()->error("You Didn't Choosed any payment method","Oops") ;
            return redirect()->back();

        }

        notify()->error('Something went Wrong',"Oops") ;
        return redirect()->back();

    }
}
