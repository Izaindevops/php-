<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use TextFlowClient;


use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Log;


class TextSMSAi extends Controller
{
        protected $apiKey;

//https://21fd-39-34-185-186.ngrok.io/api/receive-sms
    public function __construct()
    {
        $this->apiKey = 'HmmzlDNc6x7mKlEob39v1lh2DiXRSU61faqHU3idDcyOU260d5k5sjuC8GBX2hlQ';
    }
    public function sendSMS($value='')
    {
        $header=[
         "Content-Type"=> "application/json",
          "Authorization"=> "Bearer ".$this->apiKey,
          // /923018836188
       
        ];
    try {
        
            $postData=[  "phone_number"=>"923055175101", "text"=> "Masti kr rya to baz a aja"];
         $response = Http::withHeaders($header)->post('https://textflow.me/api/send-sms', $postData);
            if($response->failed() AND $response->status()!=201):
              // notify()->error("Something went wrong Try Later",$response->status()) ;
              // return redirect()->back();
               return $response['message'];
            else:
              return $response;

            endif;
    } catch (Exception $e) {
        return $e->getMessage();
    }

    }
    public function receiveSMS(Request $request)
{
     Log::info("Triggered");
    $toInsert=[
        'user_id'=>1,
        'bot_id'=>1,
        'body'=>$request->text,
        'from_person'=>$request->phone_number,
        'to_person'=>0,
        'status'=>'SUCCESS',
        'sms_status'=>"RECEIVED",
        'message_id'=>0,
        'rawData'=>json_encode($request->secret),
        
    ];
    $setData=DB::table('ai_SMS')->insert($toInsert); 
    if ($setData) {
         $response=['message'=>"Great SMS received",
            'status'=>200,

        ];
         Log::info("inerted");
        
    }else{
        $response=['message'=>"Sorry You are Sending Invalid Data Something Missing",
            'status'=>500,
        ];

    }
    return response($response,$response['status']);
  
}
}
