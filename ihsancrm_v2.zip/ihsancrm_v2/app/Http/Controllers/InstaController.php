<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Validator;

class InstaController extends Controller
{
    public $instaKey;
    public $instaUrl;
    public function __construct()
    {
        $this->instaUrl="https://instagram.ihsancrm.com/api/insta";
        $this->instaKey='za-cWiJDJMlz7TFJh1l42z7MC0VM9ZaTBwdCZaTDFKl13BlbkFJ';
    }
    public function instaHome()
    {

        return view('panel/insta/insta');
    }
    public function checkSession($key)
    {
        return view('panel/insta/session', ['brid' => $key]);

    }
    public function tracking($key)
    {
        return view('panel/insta/tracking', ['key' => false, 'botID' => $key]);

    }
    public function chats($key, $receiverUser, $senderUser)
    {
        $instachats = DB::table('instachats')->join('bots', 'instachats.bot_id', '=', 'bots.id')->where('bots.rid', $key)->where('instachats.account_name', $senderUser)->where('instachats.receiver_name', $receiverUser)->get();
        //$instachats = DB::table('instachats')->where('rid',$key)->where('status',1)->orderBy('created_at','DESC')->get();
        return view('panel/insta/tracking', ['instachats' => $instachats, 'key' => true]);

    }

    public function stopSession($key)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => $this->instaKey,
            ])->asForm()->post( $this->instaUrl.'/sessions/stop', [
                'session' => $key,

            ]);

            if ($response->failed()):
                if ($response->status() == 404) {
                    DB::table('bots')->where('rid', $key)->update(['is_insta_linked' => 0]);

                }
                notify()->error("Session Id OR Bot Id is Missing", "Sorry");
                return redirect()->back();

            else:

                $bots = DB::table('bots')->where('rid', $key)->update(['is_insta_linked' => 0]);
                if ($bots) {
                    notify()->success("Account Has Been unLinked", "Great");
                    return redirect('insta/ai');
                } else {
                    notify()->error("There some wrong at server side please try later", "Sorry");
                    return redirect()->back();
                }

            endif;
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            notify()->error("There some wrong at server side please try later", "Sorry");
            return redirect()->back();

        }

    }
    public function config(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'bot' => 'required',
            'email' => 'required',
            'password' => 'required',
            'page_url' => 'required',
        ]);
        if ($validator->fails()) {
            $response = ['message' => 'Some fields are missing', 'status' => 'error'];
        } else {
            $checkAlreadyExists = DB::table('bots')->where('rid', $request->bot)->where('is_insta_linked', 1)->count();
            $countUser = DB::table('bots')->where('rid', $request->bot);
            if ($checkAlreadyExists > 0 and $countUser->count() < 0) {

                $responseD = ['message' => "Bot is Already Linked with Another Account", 'status' => 'error'];
             
            } else {
                try {
                     $userID = $countUser->get();
                    // return config('services.xxxx.xxBOTTRAINERxx');
                    $response = Http::withHeaders([
                        'Authorization' => $this->instaKey,
                    ])->asForm()->timeout(130)->post($this->instaUrl.'/sessions/start', [
                       'name' => $request->email,
                        'email' => $request->email,
                        'password' => $request->password, 
                        'asset_id' => $request->page_url,
                        'uid' => $userID[0]->uid,   
                    ]);
                    if ($response->failed()):
                        $responseD = ['message' => $response['message'], 'status' => 'error'];
                        if($response->status()==400):
                            $responseD = ['message' => $response['message'], 'status' => 'success', 'email' => $request->email];
                        endif;
                       

                    else:
                        if ($response['status'] == 'STARTING'):
                        
                            $bots = DB::table('bots')->where('rid', $request->bot)->update(['is_insta_linked' => 0, 'insta_account_name' => $request->email]);

                            $responseD = ['message' => 'Please Wait We are Linking With Ai', 'status' => 'success', 'email' => $request->email];
        
                        else:
                            $responseD = ['message' => 'Unable to Linking Please try Again', 'status' => 'error'];
                        endif;
                    endif;
                } catch (\Exception $e) {
                    Log::info($e->getMessage());
                    $responseD = ['message' => 'Unable to Linking Please try Again.', 'status' => 'error'];

                }
            }

        }
        return response()->json($responseD, 200);

    }
    public function twoFactor(Request $request)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => $this->instaKey,
            ])->asForm()->post($this->instaUrl. '/2fa/code', [
                'session' => $request->email,
                'code' => $request->code,
            ]);

            if ($response->failed()):
                if ($response->status()==404) {
                    $responseD = ['message' => $response['message'], 'status' => 'NOT_FOUND'];   
                }else{
                    $responseD = ['message' => $response['message'], 'status' => 'WRONG_CODE'];  
                }
                DB::table('bots')->where('insta_account_name', $request->email)->update(['is_insta_linked' => 0]);

            else:
                $responseD = ['message' =>"Account Has Been Linked", 'status' => 'SUCCESS'];  
                DB::table('bots')->where('insta_account_name', $request->email)->update(['is_insta_linked' => 1]);
                
            endif;

        } catch (\Exception $e) {

            Log::info($e->getMessage());
            $responseD = ['message' => "There some wrong at server side please try later", 'status' => 'ERROR_OCCURRED']; 

        }
        return response()->json($responseD, 200);
    }
    
    public function checkSessionStatus(Request $request)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => $this->instaKey,
            ])->get($this->instaUrl. '/status/session?session='.$request->email);

            if ($response->failed()):
                Log::info($response);
                Log::info($response->status());
                $bots = DB::table('bots')->where('insta_account_name', $request->email)->update(['is_insta_linked' => 0, 'insta_account_name' => null]);
                $responseD = ['message' => 'Your Account not linked with Insta Ai Please Try Again', 'status' => 'error'];

            else:

                if ($response['status'] == 'WORKING') {
                    $bots = DB::table('bots')->where('insta_account_name', $request->email)->update(['is_insta_linked' => 1]);
                    $responseD = ['message' => 'Your Account is Linked With Insta Ai ', 'status' => $response['status']];

                } elseif ($response['status'] == '2FA_REQUIRED') {
                $responseD = ['message' => $response['message'], 'status' => $response['status']];
                } else {
                    if ($response['status'] == "ERROR_OCCURRED") {
                        $bots = DB::table('bots')->where('insta_account_name', $request->email)->update(['is_insta_linked' => 0, 'insta_account_name' => null]);

                    }
                    $responseD = ['message' => $response['message'], 'status' => $response['status']];
                }

            endif;
        } catch (\Exception $e) {
            $responseD = ['message' => 'Account is already Unlinked Please Link again ' . $e->getMessage(), 'status' => 'error'];

        }
        return response()->json($responseD, 200);
    }

}
