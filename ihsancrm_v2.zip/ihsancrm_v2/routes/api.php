<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TextSMSAi;
use App\Http\Controllers\whatHooks;
use App\Http\Controllers\instaAi;
use App\Http\Controllers\faceAi;

/*
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('receive-sms', [TextSMSAi::class,'receiveSMS']);
Route::post('ihsanai/whatsai/webhook', [whatHooks::class,'checkHook']);


Route::post('ihsanai/whatsai/sent', [whatHooks::class,'sentHook']);
Route::post('ihsanai/whatsai/receive', [whatHooks::class,'receiveHook']);
Route::post('ihsanai/whatsai/unsent', [whatHooks::class,'unsentHook']);

Route::post('ihsanai/instaAi/sent', [instaAi::class,'sentHook']);
Route::post('ihsanai/instaAi/receive', [instaAi::class,'receiveHook']);
Route::post('ihsanai/instaAi/unsent', [instaAi::class,'unsentHook']);

Route::post('ihsanai/faceAi/sent', [faceAi::class,'sentHook']);
Route::post('ihsanai/faceAi/receive', [faceAi::class,'receiveHook']);
Route::post('ihsanai/faceAi/unsent', [faceAi::class,'unsentHook']);
