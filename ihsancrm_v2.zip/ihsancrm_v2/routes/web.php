<?php

use App\Http\Controllers\ChatWeb;
use App\Http\Controllers\FaceController;
use App\Http\Controllers\GoogleLogin;
use App\Http\Controllers\IhsanBot;
use App\Http\Controllers\InstaController;
use App\Http\Controllers\manageAuth;
use App\Http\Controllers\payCheckOut;
use App\Http\Controllers\PlanCon;
use App\Http\Controllers\PushSMS;
use App\Http\Controllers\SMSController;
use App\Http\Controllers\stCheckOut;
use App\Http\Controllers\SupportSys;
use App\Http\Controllers\TextController;
use App\Http\Controllers\TextSMSAi;
use App\Http\Controllers\WhatsAi;
use App\Http\Controllers\PanelController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
 */

Route::get('/', function () {
    return view('home');
})->name('home');
Route::get('sendsms', [TextSMSAi::class, 'sendSMS'])->name("sendSMStouser");

Route::view('prices', 'prices')->name('prices');
Route::view('about-us', 'about')->name('about');
Route::view('contact-us', 'contact')->name('contact');
Route::view('register', 'register')->name('register');

Auth::routes();

//Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('logout', function () {
    Session::flush();
    Auth::logout();

    return Redirect('/');
})->name('logout');
Route::get('forgot-password', function () {
    return view('auth/passwords/email');
})->name('forgot-password');

Route::get('auth/google', [GoogleLogin::class, 'redirectToGoogle'])->name("googleAuth");
Route::get('allChats', [PushSMS::class, 'getAllChats'])->name("getAllChats");

Route::get('google/callback', [GoogleLogin::class, 'handleGoogleCallback']);

Route::post('register', [manageAuth::class, 'store'])->name('register.user');
Route::post('loginUser', [manageAuth::class, 'loginUser'])->name('login.user');

/*-----------------panel--------------------*/
Route::group(
   [ 'middleware' => ['auth', 'user']],
   function () {

 
      Route::get('WhatsappAi/screen/{key}/qrcode', function ($key) {
         return view('panel.viewScreen', ['brid' => $key]);
     })->name('whatsapp.session.qrcode');
    Route::get('/showImage', function () {
        return view('image');
    })->name('image');

    Route::get('/WhatsappAi/session/{key}/close', [WhatsAi::class, 'closeSession'])->name('whatsapp.session.close');
    Route::post('startSession', [WhatsAi::class, 'startSession'])->name('startSession');
    Route::post('refreshSession', [WhatsAi::class, 'refreshSession'])->name('refreshSession');
    Route::get('screenshot', [WhatsAi::class, 'startScreenshot'])->name('startScreenshot');
    Route::get('WhatsappAi', [WhatsAi::class, 'show'])->name('whats.show');
    Route::get('/WhatsappAi/create', function () {
        return view('panel.checkWAi', ['screenshot' => null]);
    })->name('whats.create');

    Route::get('/WhatsappAi/messages/{key}/sent', function ($key) {
        return view('panel.whatsAi_msgs', ['uid' => $key, 'type' => 'sent']);
    })->name('whats.sent');
    Route::get('/WhatsappAi/messages/{key}/received', function ($key) {
        return view('panel.whatsAi_msgs', ['uid' => $key, 'type' => 'received']);
    })->name('whats.received');
    Route::get('/WhatsappAi/messages/{key}/unsent', function ($key) {
        return view('panel.whatsAi_msgs', ['uid' => $key, 'type' => 'unsent']);
    })->name('whats.unsent');
    Route::get('/WhatsappAi/messages/{key}/all', function ($key) {
        return view('panel.whatsAi_msgs', ['uid' => $key, 'type' => 'all']);
    })->name('whats.all');

    Route::get('/support-messages/list', [PanelController::class, 'supportList'])->name('support.list');
    Route::get('/support-messages/create', [PanelController::class, 'supportCreate'])->name('support.create');



    Route::get('/support-message/{key}', function ($key) {
        return view('panel.support-messages', ['key' => $key]);
    })->name('panel.support.view');
    Route::post('supportsubmit', [SupportSys::class, 'create'])->name('support.submit');
    Route::post('customerreply', [SupportSys::class, 'customerReply'])->name('customer.reply');

    Route::post('sendWebMessage', [ChatWeb::class, 'sendMessage'])->name('chat.web');
    Route::post('sendSM', [SmsClicks::class, 'sendSM'])->name('chat.sms');
    Route::get('checkAccount', [SmsClicks::class, 'sendMessageTo'])->name('checkAc');
    Route::get('checkapi', [SmsClicks::class, 'testApiWeb'])->name('checkapi');

    Route::get('dashboard', function () {
        return view('panel/home');
    })->name('dashboard');

/*---------------------SMS-------------------------------------------*/
    Route::get('/SMS/ai', [SMSController::class, 'smsAiCHeck'])->name('sms.settings');
    Route::post('/SMS/survay', [SMSController::class, 'survaySettings'])->name('sms.survay');
    Route::post('/SMS/config', [SMSController::class, 'config'])->name('sms.config');
    Route::post('/SMS/send', [SMSController::class, 'sendSMS'])->name('sms.send');
    Route::get('/SMS/sender/{key}', [SMSController::class, 'send'])->name('sms.session.send');
    Route::get('/SMS/stop/{key}', [SMSController::class, 'stopSession'])->name('sms.session.stop');
    Route::get('/SMS/tracking/{key}', [SMSController::class, 'tracking'])->name('sms.session.chat');
    Route::get('/SMS/tracking/{key}/{receiverUser}', [SMSController::class, 'chats'])->name('sms.session.chat.full');



Route::post('SMS/submit-by-link', [SMSController::class, 'submitByLink'])->name('sms.by.link');
Route::post('SMS/submit-by-file', [SMSController::class, 'submitByFile'])->name('sms.by.file');


/*---------------------inta-------------------------------------------*/
    Route::get('/insta/ai', [InstaController::class, 'instaHome'])->name('insta.show');
    Route::get('/insta/session/start', [InstaController::class, 'instaHome'])->name('insta.session.start');
    Route::get('/insta/session/stop/{key}', [InstaController::class, 'stopSession'])->name('insta.session.stop');
    Route::post('/insta/session/status', [InstaController::class, 'checkSessionStatus'])->name('insta.session.status');
    Route::post('/insta/session/check/{key}', [InstaController::class, 'checkSession'])->name('insta.session.check');
    
    Route::get('/insta/tracking/{key}', [InstaController::class, 'tracking'])->name('insta.session.chat');
    Route::get('/insta/tracking/{key}/{receiverUser}/{senderUser}', [InstaController::class, 'chats'])->name('insta.session.chat.full');
    Route::post('/insta/session/factor', [InstaController::class, 'twoFactor'])->name('insta.session.twoFactor');

    Route::post('/insta/config', [InstaController::class, 'config'])->name('insta.session.config');

/*---------------------face-------------------------------------------*/
    Route::get('/facebook/ai', [FaceController::class, 'home'])->name('facebook.show');
    Route::get('/facebook/session/start', [FaceController::class, 'home'])->name('facebook.session.start');
    Route::post('/facebook/session/status', [FaceController::class, 'checkSessionStatus'])->name('facebook.session.status');
    Route::post('/facebook/session/factor', [FaceController::class, 'twoFactor'])->name('facebook.session.twoFactor');

    Route::get('/facebook/session/stop/{key}', [FaceController::class, 'stopSession'])->name('facebook.session.stop');
    Route::get('/facebook/session/check/{key}', [FaceController::class, 'checkSession'])->name('facebook.session.check');
    Route::get('/facebook/tracking/{key}', [FaceController::class, 'tracking'])->name('facebook.session.chat');
    Route::get('/facebook/tracking/{key}/{receiverUser}/{senderUser}', [FaceController::class, 'chats'])->name('facebook.session.chat.full');
    Route::post('/facebook/config', [FaceController::class, 'config'])->name('facebook.session.config');

   /*---------------------web ai-------------------------------------------*/
   Route::get('/web/ai', [PanelController::class, 'webAi'])->name('webai.show');
   Route::get('/web/ai/{uid}', [PanelController::class, 'webAiEmbedding'])->name('webai.embedding');
/*---------------------profile-------------------------------------------*/


    Route::post('auth/profile/update', [manageAuth::class, 'updateProfile'])->name('user.profile.update');
    Route::post('auth/profile/password', [manageAuth::class, 'updatePassword'])->name('user.profile.password');

    Route::get('settings/{id?}', function ($id) {
        return view('panel/account/settings', ['activeTab' => $id]);
    })->name('settings.account');


    Route::get('ihsanbot/list', [PanelController::class, 'botList'])->name('bot.list');
    Route::get('billing/history', [PanelController::class, 'billingHistory'])->name('billing.history');

    Route::post('ihsanbot/customize/{key}/file/upload', [IhsanBot::class, 'botFile'])->name('bot.file');



    Route::get('ihsanbot', function () {
        return view('panel/botDetails', ['runData' => null, 'uid' => 0]);
    })->name('ihsanbot');
    Route::get('ihsanbot/{customize}', function ($customize) {
        return view('panel/botDetails', ['tab' => $customize, 'runData' => null]);
    })->name('ihsanbot.random');

    Route::get('ihsanbot/{customize}/{key}', [IhsanBot::class, 'updateData'])->name('ihsanbot.custom');
    Route::get('upgrade/plan/{plan?}', [PlanCon::class, 'upgrade'])->name('upgrade.plan');

    Route::get('pdf', [ChatWeb::class, 'extractText'])->name("bot.train");

    Route::get('query/{key}', [TextController::class, 'testBot'])->name("test.bot");

/*-----------------------------------*/
    Route::post('customize', [IhsanBot::class, 'customize'])->name('bot.customize');
    Route::post('customizeUpdate', [IhsanBot::class, 'customizeUpdate'])->name('bot.customizeUpdate');

});

/*-----------------admin--------------------*/

Route::group(
    ['as'=>'admin.','middleware' => ['auth', 'admin'], 'prefix' => 'admin'],
    function () {
        Route::get('dashboard',  function () {
            return view('admin.dashboard');
        })->name('to.dashboard');
        Route::get('', function () {
            return view('admin.dashboard');
        })->name('dashboard');

        Route::get('plans', function () {
            return view('admin.plans');
        })->name('plans');
        Route::get('users', function () {
            return view('admin.create-user');
        })->name('users');

        Route::get('payments', function () {
            return view('payment_history');
        })->name('payments');
        Route::get('/users/customers', function () {
            return view('admin.user-list', ['type' => 'customers']);
        })->name('user-app');
        Route::get('/users/panel', function () {
            return view('admin.user-list', ['type' => 'panel']);
        })->name('user-panel');
        Route::get('bots', [IhsanBot::class, 'showBots'])->name('botsList');

        Route::get('bot/{id}/{name}', function ($id, $name) {
            return view('admin.bots-info', ['botID' => $id, 'name' => $name]);
        })->name('bot.info');

        Route::get('user/info/{id}/{name?}', function ($id) {
            return view('admin.user-info', ['id' => $id]);
        })->name('user.info');

        Route::post('user/create', [manageAuth::class, 'createUser'])->name('createUser');

        Route::get('/support-messages', function () {
            return view('admin.support-messages', ['key' => null]);
        })->name('support.messages');

        Route::get('/support-message/{key}', function ($key) {
            return view('admin.support-messages', ['key' => $key]);
        })->name('support.view');
        Route::get('/support-message/{key}/accept', function ($key) {
            return view('admin.support-messages', ['key' => $key]);
        })->name('support.view');
        Route::post('supportreply', [SupportSys::class, 'adminreply'])->name('support.reply');

    

    });
    Route::delete('bot/disable/{key}', [IhsanBot::class, 'disableBot'])->name('bot.disable');
/*---------------------------*/
Route::name('stripe.')
    ->controller(stCheckOut::class)
    ->group(function () {
        Route::get('stripe/checkout/{req}', 'flash')->name('checkout');
        Route::get('payment/success', 'getId')->name('details');
    });
Route::name('paypal.')
    ->controller(payCheckOut::class)
    ->group(function () {
        Route::post('paypal/checkout', 'payment')->name('checkout');
        Route::get('success', 'success')->name('success');
        Route::get('success', 'cancel')->name('cancel');
    });

    Route::get('/clear-cache', function () {
        \Artisan::call('optimize:clear');
        return 'Cache cleared';
    });
    