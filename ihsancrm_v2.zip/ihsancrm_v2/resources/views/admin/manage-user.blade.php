@extends('layouts.admin')
@section('content')

<div class="container">
	<div class="row">
		<div class="col-sm-10 mx-auto">
			<div class="card">
				<div class="card-header"></div>
				<div class="card-body">
					<form action="">
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<x-admin.foot/>
@endsection