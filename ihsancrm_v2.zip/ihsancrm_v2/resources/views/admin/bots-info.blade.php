@extends('layouts.admin')
@php
    $bots = getWhere('bots', 'uid', $botID);
@endphp
@section('title', $bots[0]->bot_name . ' | Ihsan Ai')
@section('content')
    <style type="text/css">
        .max_height {
            max-height: 150px;
        }

        .bxs-check-circle {
            font-size: 20px !important;
            color: green;
            float: right;
        }

        .bxs-x-circle {
            font-size: 20px !important;
            color: red;
            float: right;
        }
    </style>
    <div class="container mt-2">
        <div class="row">
            <div class="col-sm-10 mx-auto">
                <div class="card">
                    <div class="card-header h4 border-bottom">
                        <strong class="text-dark">{{ $bots[0]->bot_name }}</strong> Created By <strong
                            class="text-dark">{{ getUser($bots[0]->user_id)[0]->name }}</strong>
                    </div>
                    <div class="card-body">
                        <div class="row mt-2">
                            <div class="col-sm-3"> <img class="img-fluid max_height" src="{{ $bots[0]->bot_logo }}"> </div>
                            <div class="col-sm-6">
                                <p><strong>Bot Name : </strong> {{ $bots[0]->bot_name }}</p>
                                <p><strong>Bot Color : </strong> <span class="badge"
                                        style="background-color: {{ $bots[0]->bot_color }};">Color</span> </p>
                            </div>
                            <div class="col-sm-3">
                        

                                <span>Web Ai <i class='bx bxs-check-circle'></i></span> <br>
                                @if ($bots[0]->is_whats_linked == 1)
                                    <span>Whatsapp Ai <i class='bx bxs-check-circle'></i></span> <br>
                                @else
                                    <span>Whatsapp Ai <i class='bx bxs-x-circle'></i></span> <br>
                                @endif
                                @if ($bots[0]->is_sms_linked == 1)
                                    <span>SMS Ai <i class='bx bxs-check-circle'></i></span> <br>
                                @else
                                    <span>SMS Ai <i class='bx bxs-x-circle'></i></span> <br>
                                @endif
                                @if ($bots[0]->is_insta_linked == 1)
                                    <span>Instagram Ai <i class='bx bxs-check-circle'></i></span> <br>
                                @else
                                    <span>Instagram Ai <i class='bx bxs-x-circle'></i></span> <br>
                                @endif
                                @if ($bots[0]->is_face_linked == 1)
                                    <span>Facebook Ai <i class='bx bxs-check-circle'></i></span> <br>
                                @else
                                    <span>Facebook Ai <i class='bx bxs-x-circle'></i></span> <br>
                                @endif

                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-sm-3"> <img class="img-fluid max_height" src="{{ $bots[0]->company_logo }}">
                            </div>
                            <div class="col-sm-7">
                                <p><strong>Company Name : </strong> {{ $bots[0]->company_name }}</p>
                            </div>
                        </div>
                        <hr>
                        <div class="row mt-2">
                            <div class="col-sm-10">
                                <p><strong>Welcome Message : </strong> {{ $bots[0]->welcome_message }}</p>
                            </div>
                            <div class="col-sm-10">
                                {{-- <p><strong>Source File : </strong>
                                @if ($bots[0]->source_file != null)
                                @foreach (json_decode($bots[0]->source_file) as $file)
                                <a target="_blank" href="{{url($file)}}">View File</a>,
                                @endforeach
                            </p>
                            @else
                            <span class="badge bg-dark">File Not Uploaded Yet</span>
                            @endif --}}
                            </div>
                        </div>
                    </div> {{-- end of card body --}}
                </div>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-sm-10 mx-auto">
                <div class="card">
                    <div class="card-header bg-dark text-white h4">
                        Recent Payments
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <td>Sr No.</td>
                                    <td>Plan</td>
                                    <td>Amount</td>
                                    <td>Activated At</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                
                                $userData = getWhere('payments', 'user_id', $bots[0]->user_id);
                                
                                $c = 0;
                                ?>
                                @foreach ($userData as $user)
                                    @php
                                        $c++;
                                    @endphp
                                    <tr>
                                        <td>
                                            {{ $c }}
                                        </td>
                                        <td>
                                            {{ ucwords($user->plan) }}
                                        </td>
                                        <td>
                                            ${{ $user->amount }}
                                        </td>
                                        <td>{{ getTimeFormat('d-m-Y', $user->created_at) }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <x-admin.foot />
@endsection
