@extends('layouts.admin')
@section('title','Bots Lists | Ihsan Ai')
@section('content')
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-10 mx-auto">
            <div class="card">
                <div class="card-header h4 border-bottom text-white bg-dark">
                    Bots List
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sr No.</th>
                                <th>Bot Name</th>
                                <th>Created By</th>
                                <th>Created at</th>
                                <th>More</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                            $bots=getWhere('bots','bot_sts',0);
                            $c=0;
                            foreach($botsData as $bot):
                            $c++;
                            @endphp
                            <tr>
                                <td>{{$c}}</td>
                                <td>{{$bot->bot_name}}</td>
                                <td>{{getUser($bot->user_id)[0]->name}}</td>
                                <td>{{getTimeFormat('d-m-Y',$bot->created_at)}}</td>
                                <td class="text-center">
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="/admin/bot/{{$bot->uid}}/{{$bot->bot_name}}">More Info</a>
                                            <a href="{{ route('bot.disable', $bot->uid) }}" class="dropdown-item" data-confirm-delete="true">Disable</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @php
                            endforeach;
                            @endphp
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-12">
                            {!! $botsData->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<x-admin.foot />
@endsection
