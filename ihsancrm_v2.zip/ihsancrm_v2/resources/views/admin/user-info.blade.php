@extends('layouts.admin')
   @section('title',"User Info-Ihsan AI")

@section('content')
               <!-- begin row -->
               <div class="container mt-3">
                   
     <div class="row">
                           <div class="col-sm-12">
<div class="card card-statistics">
    <?php $getUser=getUser(base64_decode($id)); ?>
    @if($getUser[0]->role=="user")
    <div class="card-body p-0">
                                        <div class="row no-gutters">
                                            <div class="col-xl-3 p-2 pb-xl-0 pb-5 border-right p-3">
                                                                <img src="{{$getUser[0]->profile_img}}" class="img-fluid " alt="users-avatar">
                                                            </div>
                                            <div class="col-xl-5 col-md-6 col-12 border-t border-right">
                                                <div class="page-account-form">
                                                    <div class="form-titel border-bottom p-3">
                                                        <h5 class="mb-0 py-2">Personal Information</h5>
                                                    </div>
                                                    <div class="p-4">
                                                        <h4 class="mb-1">{{$getUser[0]->name}}</h4>
                                                        <h5 class="mb-1"><i>{{$getUser[0]->email}}</i></h5>
                                                        <h5 class="mb-1"><i>{{$getUser[0]->phone}}</i> </h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6 border-t col-12">
                                                <div class="page-account-form">
                                                    <div class="form-titel border-bottom p-3">
                                                        @if($getUser[0]->isPaid==1)
                                                        <h5 class="mb-0 py-2">Plan :  {{($getUser[0]->planId!=null)?$getUser[0]->planId:"Not Active"}}</h5>
                                                        <h5 class="mb-0 py-2">Active Time :  {{getTimeFormat('d-m-Y',$getUser[0]->planActiveTime)}}</h5>
                                                      @endif
                                                    </div>
                                                    <div class="p-4"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="card">
                                            <div class="card-header h5 border-bottom">
                                                Bots List
                                            </div>
                                            <div class="card-body">
                    <table class="table">
                        <thead> 
                                <tr>
                                    <th>Sr No.</th>
                                    <th>Bot Name</th>
                                    <th>Created at</th>
                                    <th>More</th>
                                </tr>
                        </thead>
                        <tbody> 
                            @php
                                    $bots=getWhere('bots','user_id',$getUser[0]->id);
                                    $c=0;
                                    foreach($bots as $bot):
                                        $c++;

                            @endphp
                                <tr>
                                    <td>{{$c}}</td>
                                    <td>{{$bot->bot_name}}</td> 
                                    <td>{{getTimeFormat('d-m-Y',$bot->created_at)}}</td>
                                    <td class="text-center">
                                        <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                          <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                          <a class="dropdown-item" href="/admin/bot/{{$bot->uid}}/{{$bot->bot_name}}">More Info</a>
                                         
                                        </div>
                                      </div>
                                     </td>
                                </tr>
                                @php
                                    endforeach;
                                @endphp
                        </tbody>    
                    </table>
                </div>
                                        </div>
                                    </div> {{-- end of card body --}}
                                    <hr>    
                                    <div class="card">
                                        <div class="card-header h5 border-bottom">Recent Payments</div>
                                        <div class="card-body">
                               <table class="table table-stripped datatable-wrapper datatable">
                                   <thead>
                                       <tr>
                                           <td>Sr No.</td>
                                           <td>Plan</td>

                                           <td>Amount</td>
                                            <td>Activated At</td>
                                       </tr>
                                   </thead>
                                   <tbody>
                                   <?php 
                            
                                    $userData=getWhere('payments','user_id',$getUser[0]->id);
                                    $c=0;
                                    ?>
                                    @foreach($userData as $user)
                                    @php
                                        $c++;
                                    @endphp

                                       <tr>
                                           <td>
                                               {{$c}}
                                              
                                           </td>
                                           <td>
                                                {{ucwords($user->plan)}}
                                           </td>

                                           <td>
                                               ${{$user->amount}}
                                           </td>
                                           
                                           <td>{{getTimeFormat('d-m-Y',$user->created_at)}}</td>

                                       </tr>
                                       @endforeach
                                   
                                   </tbody>
                               </table>
                              
                                    </div>
                                    </div>
                                @else
                                    <div class="card-body p-0">
                                        <div class="row no-gutters">
                                            <div class="col-xl-3 p-2 pb-xl-0 pb-5 border-right p-3">
                                                                <img src="{{$getUser[0]->profile_img}}" class="img-fluid " alt="users-avatar">
                                                            </div>
                                            <div class="col-xl-5 col-md-6 col-12 border-t border-right">
                                                <div class="page-account-form">
                                                    <div class="form-titel border-bottom p-3">
                                                        <h5 class="mb-0 py-2">Personal Information</h5>
                                                    </div>
                                                    <div class="p-4">
                                                        <h4 class="mb-1">{{$getUser[0]->name}}</h4>
                                                        <h5 class="mb-1"><i>{{$getUser[0]->email}}</i></h5>
                                                        <h5 class="mb-1"><i>{{$getUser[0]->phone}}</i> </h5>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-4 col-md-6 border-t col-12">
                                                <div class="page-account-form">
                                                    <div class="form-titel border-bottom p-3">
                                                        <h5 class="mb-0 py-2"></h5>
                                                      
                                                    </div>
                                                    <div class="p-4"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> {{-- end of card body --}}
                            @endif

                                </div>
                               
</div>
</div>
               </div>
                                         <x-admin.foot/>


 @endsection

