@extends('layouts.admin')
@section('content')
     <div class="container mt-4">
         <div class="row">
            @error("email")
                @php  notify()->error("Email Already Register","Sorry") ; @endphp
            @enderror
             @error("name")
                @php  notify()->error($message,"Sorry") ; @endphp
            @enderror
         
                           <div class="col-sm-10 mx-auto">
                               <div class="card">
                                    <div class="card-header ">
                                            Create User
                                        </div>
                                    <div class="card-body">
                                      <form method="POST" action="{{route('admin.createUser')}}">
                                             @csrf
                                            <div class="form-group row">  
                                                 <div class=" col-md-6">
                                                    <label for="inputEmail4">User Name</label>
                                                    <input name="name" type="text" class="form-control" value="" required id="inputEmail4" placeholder="Enter User Name">
                                                </div>
                                                <div class=" col-md-6">
                                                    <label for="inputEmail4">Email</label>
                                                    <input name="email" type="email" class="form-control" required  value="" id="inputEmail4" placeholder="Enter Email">
                                                </div>
                                               
                                            </div>
                                             <div class="row form-group">  
                                                 <div class=" col-md-6">
                                                    <label for="pho">Phone Number</label>
                                                    <input name="phone" type="text" class="form-control" value="" required id="pho" placeholder="Enter Phone Number">
                                                </div>
                                                <div class=" col-md-6">
                                                    <label for="">Address</label>
                                                    <input name="address" type="text" class="form-control" required  value="" id="" placeholder="Enter Address">
                                                </div>
                                               
                                            </div>

                                            <div class="row form-group">
                                                <div class=" col-md-6">
                                                    <label for="inputCity">Password</label>
                                                    <input name="password" placeholder="Enter Password"   value="" type="password" class="form-control" >
                                                </div>
                                                
                                                <div class=" col-md-6">
                                                    <label for="inputState">User Role</label>
                                                    <select required name="role" id="inputState" class="form-control">
                                                        <option value="admin">Admin</option>
                                                        <option value="sub_admin">Sub Admin</option>
                                                    </select>
                                                </div>
                                              
                                            </div>
                                           
                                            <button type="submit" class="btn btn-primary float-right mt-2">Save</button>
                                        </form>
                                                  </div>
                                </div>
                           </div>
                        
     </div>
     </div>              

<x-admin.foot/>

@endsection
