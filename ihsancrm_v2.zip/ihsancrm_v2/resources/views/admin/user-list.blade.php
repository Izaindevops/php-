@extends('layouts.admin')
   @section('title',"User List-Ihsan AI")
    @section('content')
              <!-- begin row -->
                    <div class="container mt-5">
                        <!-- end row -->
                        <!-- begin row -->
                        <div class="row">
                           <div class="col-sm-12">
                               <div class="card">

                                   <div class="card-header h4 border-bottom">Users List</div>
                                   <div class="card-body">
                        @if($type=="customers")        
                               <table class="table table-stripped datatable-wrapper datatable">
                                   <thead>
                                       <tr>
                                           <td>Sr No.</td>
                                           <td>Name</td>
                                           <td>Email</td>
                                            <td>Plan</td>
                                            <td>Status</td>

                                           <td>More Info</td>
                                       </tr>
                                   </thead>
                                   <tbody>
                                   <?php 
                                   $c=0;
                            
                                    $userData=getWhere('users','role','user');
                                

                                    ?>
                                    @foreach($userData as $user)
                                    @php     $c++; @endphp
                                       <tr>
                                           <td>
                                               {{$loop->iteration}}
                                              
                                           </td>
                                           <td>
                                                {{$user->name}}
                                           </td>

                                           <td>
                                                {{$user->email}}
                                           </td>
                                            <td>
                                               
                                                <span class="badge bg-danger">{{($user->planId!=null)?$user->planId:"Not Active"}}</span>
                                           
                                           </td>
                                           <td>
                                            
                                            @if($user->status==1)
                                            <span class="badge bg-secondary text-white"> Enabled</span>
                                            @else
                                            <span class="badge bg-danger text-dark"> Disabled</span>
                                            @endif
                                           
                                           </td>
                                           
                                           <td>

                                        <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                          <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                          <a class="dropdown-item" href="{{route('admin.user.info',['id'=>base64_encode($user->id),'name'=>$user->name])}}">More Info</a>
                                         
                                        </div>
                                      </div>
                         </td>

                                       </tr>
                                       @endforeach
                                   
                                   </tbody>
                               </table>
                               @else
                                <table class="table table-stripped datatable-wrapper datatable">
                                   <thead>
                                       <tr>
                                           <td>Sr No.</td>
                                           <td>Name</td>
                                           <td>Email</td>
                                           <td>Role</td>
                                            <td>Status</td>
                                           <td>More Info</td>
                                       </tr>
                                   </thead>
                                   <tbody>
                                   <?php 
                            
                                    $userData=getWhereNot('users','role','user');
                                    ?>
                                    @foreach($userData as $user)
                                       <tr>
                                           <td>
                                            {{$loop->iteration}}
                                           </td>
                                           <td>
                                                {{$user->name}}
                                           </td>

                                           <td>
                                                {{$user->email}}
                                           </td>
                                           <td>
                                                {{$user->role}}
                                           </td>

                                           <td>
                                            
                                            @if($user->status==1)
                                            <span class="badge badge-primary text-dark">Enabled</span>
                                            @else
                                            <span class="badge badge-danger">Disabled</span>
                                            @endif
                                           
                                           </td>
                                           
                                           <td>

                                        <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                          <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                          <a class="dropdown-item" href="{{route('admin.user.info',['id'=>base64_encode($user->id),'name'=>$user->name])}}">More Info</a>
                                         
                                        </div>
                                      </div>
                                                                            </td>

                                       </tr>
                                       @endforeach
                                   
                                   </tbody>
                               </table>
                             @endif
                                   </div>
                               </div>
                           </div>
                        </div>
                        </div>
                          <x-admin.foot/>
@endsection
                                              <!-- end row -->
                    