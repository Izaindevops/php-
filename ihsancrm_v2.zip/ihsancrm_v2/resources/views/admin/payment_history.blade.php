@extends('layouts.admin')
    @section('content')
              <!-- begin row -->
              <div class="container mt-5">
                        <!-- end row -->
                        <!-- begin row -->
                           <div class="row">
                           <div class="col-sm-12">
                               <div class="card">
                                   <div class="card-header h4 border-bottom">
                                       Billing History
                                   </div>
                                   <div class="card-body">
                               <table class="table table-stripped datatable-wrapper datatable">
                                   <thead>
                                       <tr>
                                           <td>Sr No.</td>
                                           <td>User</td>
                                           <td>Plan</td>

                                           <td>Amount</td>
                                            <td>Activated At</td>
                                       </tr>
                                   </thead>
                                   <tbody>
                                   <?php 
                            
                                    $userData=getAll('payments');
                                    $c=0;
                                    ?>
                                    @foreach($userData as $user)
                                    @php
                                        $c++;
                                    @endphp

                                       <tr>
                                           <td>
                                               {{$c}}
                                              
                                           </td>
                                           <td>{{getUser($user->user_id)[0]->name}}</td>
                                           <td>
                                                {{ucwords($user->plan)}}
                                           </td>

                                           <td>
                                               ${{$user->amount}}
                                           </td>
                                           
                                           <td>{{getTimeFormat('d-m-Y',$user->created_at)}}</td>

                                       </tr>
                                       @endforeach
                                   
                                   </tbody>
                               </table>
                              
                                   </div>
                               </div>
                           </div>
                        </div>

                    </div>
                         <x-admin.foot/>
@endsection
                                              <!-- end row -->
                    