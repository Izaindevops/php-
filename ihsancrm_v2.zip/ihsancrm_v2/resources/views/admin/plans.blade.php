
     @extends('layouts.admin')
@section('content')
      <!-- plans-Section -->
           <div class="container" >
           <div class="row mt-4">
                <div class="col-6">
                  <div class="card">
                    <div class="card-body">
                        <form>
                                <div class="mb-3">
                                  <label for="Name" class="form-label">Name</label>
                              <input type="text" class="form-control" id="Name" aria-describedby="emailHelp" placeholder="Name">
                                </div>
                              <div class="mb-3">
                                <label for="Privious" class="form-label">Price</label>
                              <input type="link" class="form-control" id="Privious" placeholder="Price">
                              </div>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>

                    </div>

                  </div>

                  </div>

             <!-- table -->
                  <div class="col-6">
                    <div class="card">
                      <div class="card-body">
                      <table class="table table-hover">
                        <thead>
                            <tr>
                            <th scope="col">#</th>
                            <th scope="col">Plan Name</th>
                            <th scope="col">Price</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                          <tbody>
                               @php
                            
                                    $plans=getAll('plans');
                                    $c=0;
                                    foreach($plans as $plan):
                                    $c++;
                                    @endphp
                        <tr>
                          <th scope="row">{{$c}}</th>
                          <td>{{$plan->name}}</td>
                          <td>200$</td>
                          <td><a href=""><i class="fa fa-edit text-dark"></i> </a>  </td>
                        </tr>
                        @php endforeach; @endphp
                      </tbody>
                    </table>
                      </div>
  
                    </div>
  
                    </div>
  
  
                  </div>
                
    <x-admin.foot/>
  </div>
            @endsection