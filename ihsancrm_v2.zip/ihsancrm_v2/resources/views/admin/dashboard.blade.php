@extends('layouts.admin')
@section('content')
<style type="text/css">
	.dashboard-cards .bx{
		font-size: 3.15rem;
	}
	.dashboard-cards .avatar{
    width: 3.375rem;
    height: 3.375rem;
	}


</style>
@php
 $today_customer=DB::table('users')->where('created_at',date('Y-m-d'))->count();
 $today_bots=DB::table('bots')->where('created_at',date('Y-m-d'))->count();
@endphp
<div class="container mt-5">	
	<div class="row">
		<div class="col-sm-3">
			<div class="card card-border-shadow-primary h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1 dashboard-cards">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-primary "><i class='bx bx-user-pin'></i></span>
          </div>
          <h2 class="ms-1 mb-0">{{countWhere('users','role','user')}}</h2>
        </div>
        <p class="mb-1">Total Customers</p>
        <p class="mb-0">
          <span class="fw-medium me-1">10</span>
          <small class="text-muted">This Month</small>
        </p>
      </div>
    </div>
	</div>
	<div class="col-sm-3">
			<div class="card card-border-shadow-warning h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1 dashboard-cards">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-warning "><i class='bx bxs-user-plus'></i></span>
          </div>
          <h2 class="ms-1 mb-0">{{$today_customer}}</h2>
        </div>
        <p class="mb-1">Today Joined </p>
        <p class="mb-0">
          <span class="fw-medium me-1">10</span>
          <small class="text-muted">This week</small>
        </p>
      </div>
    </div>

	</div>
	<div class="col-sm-3">
			<div class="card card-border-shadow-secondry h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1 dashboard-cards">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-secondry "><i class='bx bx-bot'></i></span>
          </div>
          <h2 class="ms-1 mb-0">{{countWhere('bots','bot_sts',0)}}</h2>
        </div>
        <p class="mb-1">Total Bots</p>
        <p class="mb-0">
          <span class="fw-medium me-1">10</span>
          <small class="text-muted">This Month</small>
        </p>
      </div>
    </div>
    
	</div>
	<div class="col-sm-3">
			<div class="card card-border-shadow-danger h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1 dashboard-cards">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-danger "><i class='bx bx-bot'></i></span>
          </div>
          <h2 class="ms-1 mb-0">{{$today_bots}}</h2>
        </div>
        <p class="mb-1">Today Bots</p>
        <p class="mb-0">
          <span class="fw-medium me-1">10</span>
          <small class="text-muted">This Month</small>
        </p>
      </div>
    </div>
    
	</div>

	</div>
	<div class="row mt-2">
		<div class="col-md-6 col-lg-6 mb-4">
                  <div class="card h-100">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="card-title m-0 me-2">Transactions</h5>
                      <div class="dropdown">
                        <button class="btn p-0" type="button" id="transactionID" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="bx bx-dots-vertical-rounded"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="transactionID">
                          <a class="dropdown-item" href="javascript:void(0);">View All</a>
                        </div>
                      </div>
                    </div>
                    <div class="card-body">
                      <ul class="p-0 m-0">
                      	@php 
                      	$payments=getByLImit('payments'); 
                      		foreach($payments as $payment):
                      	@endphp
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                          	@if($payment->payment_method=="stripe")
                            <i class='bx bxl-stripe h3' ></i>
                            @elseif($payment->payment_method=="paypal")
                             <i class='bx bxl-paypal h3' ></i>
                             @else
                             
                             @endif
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">{{ucwords($payment->plan)}} Plan</small>
                              <h6 class="mb-0">{{ucwords($payment->payment_method)}}</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">{{ucwords($payment->amount)}}</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        @php endforeach; @endphp
                       
                      </ul>
                    </div>
                  </div>
                </div>
	</div>
</div>	
<x-admin.foot/>
@endsection