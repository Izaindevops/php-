@extends('layouts.app')
@section('title', 'Home | IHSAN AI')
@section('content')

<div class="container pt--80 pt_md--60 pt_sm--50">
    <div class="row align-items-start">
        <div class="col-lg-6 col-md-12 col-sm-12 col-12 order-xl-1 order-lg-1 order-md-2 order-sm-2 order-2">
            <div class="banner-four-content mt--100 mt_md--50 mt_sm--50">
                <h1 class="title">
                    Make your <br>
                    automated replies <br>
                    conversational
                    <span class="right-tag">Ai Chatbot</span>
                </h1>
                <p class="disc">
                    An all-in-one platform to build and launch conversational <br>
                    chatbots without coding so your support team can focus <br>
                    on complex inquiries.
                </p>
                <div class="button-area-main">
                    <a href="{{ route('register') }}" class="rts-btn btn-primary">Get Started</a>
                    {{-- <a class="btn-only" href="#">Book a Demo <i class="fa-regular fa-arrow-right"></i></a>
 --}}
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12 col-12 order-xl-2 order-lg-2 order-md-1 order-sm-1 order-1 mt--20">
            <div class="thumbnail-banner-right">
                <img src="{{ url('other/images/banner/05.png') }}" alt="banenr" loading="lazy">
            </div>
        </div>
    </div>
</div>
<!-- rts about-area start -->
<div class="rts-about-four rts-section-gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="about-inner-main-four">
                    <h2 class="title">
                        Start conversations, win <br>
                        loyal customers
                    </h2>
                    <p class="disc">
                        Chat with customers. Solve their problems in real time. Offer <br> custom discounts based on
                        browsing history. And make product <br> recommendations based on their behavior.
                    </p>
                    <div class="check-main-wrapper">
                        <!-- soingle check -->
                        <div class="single-check">
                            <i class="fa-regular fa-check"></i>
                            <p>Automate up to 47%</p>
                        </div>
                        <!-- soingle check end -->
                        <!-- soingle check -->
                        <div class="single-check">
                            <i class="fa-regular fa-check"></i>
                            <p>Turn visitors into paying customers</p>
                        </div>
                        <!-- soingle check end -->
                        <!-- soingle check -->
                        <div class="single-check">
                            <i class="fa-regular fa-check"></i>
                            <p>Supercharge your customer service team</p>
                        </div>
                        <!-- soingle check end -->
                    </div>
                    <a href="about.html" class="rts-btn btn-primary">Try Now</a>
                </div>
            </div>
            <div class="col-lg-6 mt_sm--50">
                <div class="thumbnail-main">
                    <img src="{{ url('other/images/about/03.png') }}" alt="thumbnail" loading="lazy">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- rts about-area end -->


<!-- rts sservice area start -->
<div class="rts-service-aarea-four rts-section-gap bg-service-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-main-center-4">
                    <h2 class="title">
                        Keep conversations going <br>
                        across channels
                    </h2>
                    <p class="disc">
                        Customers want to connect with you using their favorite channels <br>
                        Integrate IhsanAI with multiple platforms to make sure.
                    </p>
                </div>
            </div>
        </div>
        <div class="row g-5 mt--20">
            {{-- 1 --}}
            <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                <!-- ingle service area start -->
                <div class="single-service-area-4">
                    <div class="icon">
                        <svg width="40" height="36" viewBox="0 0 40 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M0 5.5C0 2.76562 2.1875 0.5 5 0.5H35C37.7344 0.5 40 2.76562 40 5.5V30.5C40 33.3125 37.7344 35.5 35 35.5H5C2.1875 35.5 0 33.3125 0 30.5V5.5ZM7.5 10.5C8.82812 10.5 10 9.40625 10 8C10 6.67188 8.82812 5.5 7.5 5.5C6.09375 5.5 5 6.67188 5 8C5 9.40625 6.09375 10.5 7.5 10.5ZM35 8C35 6.98438 34.1406 6.125 33.125 6.125H14.375C13.2812 6.125 12.5 6.98438 12.5 8C12.5 9.09375 13.2812 9.875 14.375 9.875H33.125C34.1406 9.875 35 9.09375 35 8Z" fill="#21599C" />
                        </svg>
                    </div>
                    <h5 class="title">Website</h5>
                    <p class="disc" style="height: 132px">
                        {{ Str::limit('website, a cutting-edge platform, seamlessly integrates Artificial Intelligence (AI) across various fields to deliver a transformative and personalized user experience. Harnessing the power of AI, your site is a dynamic hub where innovation converges with user-centric functionality ', 170, $end = ' [...]') }}
                    </p>

                    <a href="#">More Details <i class="fa-solid fa-arrow-right"></i></a>
                </div>
                <!-- ingle service area end -->
            </div>
            {{-- 2 --}}
            <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                <!-- ingle service area start -->
                <div class="single-service-area-4">
                    <div class="icon">
                        <svg width="41" height="40" viewBox="0 0 41 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M35.9219 0C38.7344 0 40.9219 2.26562 40.9219 5V27.3438C40.9219 30 38.6562 32.2656 35.9219 32.2656H24.6719L14.9062 39.6094C14.2812 40 13.4219 39.6094 13.4219 38.8281V32.3438H5.92188C3.10938 32.3438 0.921875 30.1562 0.921875 27.4219V5C0.921875 2.26562 3.10938 0 5.92188 0H35.9219ZM10.9219 18.75C12.3281 18.75 13.4219 17.5781 13.4219 16.25C13.4219 15 12.25 13.8281 10.9219 13.8281C9.51562 13.8281 8.42188 15 8.42188 16.25C8.42188 17.5781 9.51562 18.75 10.9219 18.75ZM20.9219 18.75C22.3281 18.75 23.4219 17.5781 23.4219 16.25C23.4219 15 22.25 13.8281 20.9219 13.8281C19.5156 13.8281 18.4219 15 18.4219 16.25C18.4219 17.5781 19.5156 18.75 20.9219 18.75ZM30.9219 18.75C32.3281 18.75 33.4219 17.5781 33.4219 16.25C33.4219 15 32.25 13.8281 30.9219 13.8281C29.5156 13.8281 28.4219 15 28.4219 16.25C28.4219 17.5781 29.5156 18.75 30.9219 18.75Z" fill="#21599C" />
                        </svg>
                    </div>
                    <h5 class="title">SMS</h5>
                    <p class="disc" style="height: 132px">
                        {{ Str::limit('Experience the future of communication with our innovative AI-powered SMS platform. We\'ve seamlessly integrated Artificial Intelligence to revolutionize the way you send and receive text messages. Our AI algorithms analyze your messaging patterns, understand your preferences, and craft personalized SMS content tailored just for you', 170, $end = ' [...]') }}
                    </p>
                    <a href="#">More Details <i class="fa-solid fa-arrow-right"></i></a>
                </div>
                <!-- ingle service area end -->
            </div>
            {{-- 3 --}}
            <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                <!-- ingle service area start -->
                <div class="single-service-area-4">
                    <div class="icon">
                        <svg width="40" height="41" viewBox="0 0 40 41" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20 0.625C30.9375 0.625 39.375 8.67188 39.375 19.4531C39.375 33.125 26.3281 40.7812 14.375 37.5C13.6719 37.3438 13.5938 37.5 9.53125 39.2969C8.51562 39.6875 7.34375 38.9844 7.34375 37.8906C7.1875 34.2969 7.34375 33.9844 6.71875 33.3594C2.89062 30 0.625 25.0781 0.625 19.4531C0.625 8.67188 9.0625 0.625 20 0.625ZM31.6406 15.1562C32.1875 14.2969 31.1719 13.2812 30.3125 13.9062L24.2188 18.5156C23.75 18.8281 23.2031 18.8281 22.8125 18.5156L18.2812 15.1562C16.875 14.1406 14.9219 14.4531 14.0625 15.9375L8.35938 24.9219C7.8125 25.7812 8.82812 26.7969 9.6875 26.1719L15.7812 21.5625C16.25 21.25 16.7969 21.25 17.1875 21.5625L21.7188 24.9219C23.125 25.9375 25.0781 25.625 25.9375 24.1406L31.6406 15.1562Z" fill="#21599C" />
                        </svg>
                    </div>
                    <h5 class="title">Messenger</h5>
                    <p class="disc" style="height: 132px">
                        {{ Str::limit('Discover the future of messaging with our AI-powered Messenger. We have integrated Artificial Intelligence to elevate your chat experience to new heights. Our AI understands your conversations, learns from your interactions, and adapts to your communication style', 170, $end = ' [...]') }}
                    </p>
                    <a href="#">More Details <i class="fa-solid fa-arrow-right"></i></a>
                </div>
                <!-- ingle service area end -->
            </div>
            {{-- 4 --}}
            <div class="col-lg-4  col-md-6 col-sm-12 col-12">
                <!-- ingle service area start -->
                <div class="single-service-area-4">
                    <div class="icon"><svg width="40" height="41" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

                            <title>whatsapp [#128]</title>
                            <desc>Created with Sketch.</desc>
                            <defs>

                            </defs>
                            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g id="Dribbble-Light-Preview" transform="translate(-300.000000, -7599.000000)" fill="#000000">
                                    <g id="icons" transform="translate(56.000000, 160.000000)">
                                        <path d="M259.821,7453.12124 C259.58,7453.80344 258.622,7454.36761 257.858,7454.53266 C257.335,7454.64369 256.653,7454.73172 254.355,7453.77943 C251.774,7452.71011 248.19,7448.90097 248.19,7446.36621 C248.19,7445.07582 248.934,7443.57337 250.235,7443.57337 C250.861,7443.57337 250.999,7443.58538 251.205,7444.07952 C251.446,7444.6617 252.034,7446.09613 252.104,7446.24317 C252.393,7446.84635 251.81,7447.19946 251.387,7447.72462 C251.252,7447.88266 251.099,7448.05372 251.27,7448.3478 C251.44,7448.63589 252.028,7449.59418 252.892,7450.36341 C254.008,7451.35771 254.913,7451.6748 255.237,7451.80984 C255.478,7451.90987 255.766,7451.88687 255.942,7451.69881 C256.165,7451.45774 256.442,7451.05762 256.724,7450.6635 C256.923,7450.38141 257.176,7450.3464 257.441,7450.44643 C257.62,7450.50845 259.895,7451.56477 259.991,7451.73382 C260.062,7451.85686 260.062,7452.43903 259.821,7453.12124 M254.002,7439 L253.997,7439 L253.997,7439 C248.484,7439 244,7443.48535 244,7449 C244,7451.18666 244.705,7453.21526 245.904,7454.86076 L244.658,7458.57687 L248.501,7457.3485 C250.082,7458.39482 251.969,7459 254.002,7459 C259.515,7459 264,7454.51465 264,7449 C264,7443.48535 259.515,7439 254.002,7439" id="whatsapp-[#128]" fill="#21599C">

                                        </path>
                                    </g>
                                </g>
                            </g>
                        </svg></div>
                    <h5 class="title">Whatsapp</h5>
                    <p class="disc" style="height: 132px">
                        {{ Str::limit('"Experience the evolution of messaging with our AI-powered WhatsApp integration. Imagine a chat experience where Artificial Intelligence takes the lead, understanding your conversations, learning your preferences, and delivering a more personalized interaction.', 170, $end = ' [...]') }}
                    </p>
                    <a href="#">More Details <i class="fa-solid fa-arrow-right"></i></a>
                </div>
                <!-- ingle service area end -->
            </div>
            
        </div>
    </div>
</div>
<!-- rts sservice area end -->


<!-- rts core feature area start -->
<div class="rts-core-feature-area rts-section-gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-main-center-4">
                    <h2 class="title">
                        What’s included: core features
                    </h2>
                    <p class="disc">
                        Adjust the chat window design to fit your brand and style.
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt--50">
            <div class="col-xl-3 col-lg-6">
                <div class="left-area-core-feature-image">
                    <img src="{{ url('other/images/case/09.png') }}" alt="case" loading="lazy">
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="d-flex align-items-start">
                    <div class="tab-content" id="v-pills-tabContent">
                        <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                            <div class="thumbnail-core-feature">
                                <img src="other/images/case/10.png" alt="case-thumbnail" loading="lazy">
                            </div>
                        </div>
                        <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                            <div class="thumbnail-core-feature">
                                <img src="other/images/case/11.svg" alt="case-thumbnail" loading="lazy">
                            </div>
                        </div>
                        <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                            <div class="thumbnail-core-feature">
                                <img src="other/images/case/12.svg" alt="case-thumbnail" loading="lazy">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-12 mt_md--30 mt_sm--30">
                <div class="nav feature-nav-btn flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <div class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                        <!-- single tabs button feature -->
                        <div class="single-core-feature">
                            <h6 class="title">Welcome screen</h6>
                            <p class="disc">Say "Hi" and get the Toking <br>
                                started in a creative way.</p>
                        </div>
                        <!-- single tabs button feature end -->
                    </div>
                    <div class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                        <!-- single tabs button feature -->
                        <div class="single-core-feature">
                            <h6 class="title">One-click management</h6>
                            <p class="disc">Say "Hi" and get the Toking <br>
                                started in a creative way.</p>
                        </div>
                        <!-- single tabs button feature end -->
                    </div>
                    <div class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                        <!-- single tabs button feature -->
                        <div class="single-core-feature">
                            <h6 class="title">Custom greetings</h6>
                            <p class="disc">Say "Hi" and get the Toking <br>
                                started in a creative way.</p>
                        </div>
                        <!-- single tabs button feature end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- rts core feature area end -->

<!-- customers review area start -->
<div class="rts-tstimonials-area rts-section-gap bg-service-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-main-center-4">
                    <h2 class="title">
                        We are team of coaches, experts and agencies <br>
                        like you have chosen IhsanAI
                    </h2>
                    <p class="disc">
                        Top-rated on Trustpilot, G2, and AppSumo
                    </p>
                </div>
            </div>
        </div>
        <div class="rwo">
            <div class="col-lg-12">

            </div>
        </div>
    </div>
    <div class="container-full mt--50">
        <div class="row">
            <div class="col-lg-12">
                <div class="swiper-testimonials-4">
                    <div class="swiper mySwiper-t4">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <!-- single swiepr start -->
                                <div class="single-team-area">
                                    <img src="{{ url('other/images/brand/quote.png') }}" alt="" class="quote" loading="lazy">
                                    <div class="star">
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star-half-stroke"></i>
                                    </div>
                                    <p class="disc">
                                        I have used some AI writing tools liked Rytr, Peppertype, and Jasper but I found
                                        Writesonic to be the best for writing complete blog posts.
                                    </p>
                                    <div class="authore-area">
                                        <div class="author">
                                            <img src="{{ url('other/images/team/20.png') }}" alt="team" loading="lazy">
                                            <div class="info">
                                                <p>Samuel</p>
                                                <span>Blogger</span>
                                            </div>
                                        </div>
                                        {{-- <img src="{{url('other/images/team/brand/01.png')}}" alt="" loading="lazy"> --}}
                                    </div>
                                </div>
                                <!-- single swiepr end -->
                            </div>
                            <div class="swiper-slide">
                                <!-- single swiepr start -->
                                <div class="single-team-area">
                                    <img src="{{ url('other/images/brand/quote.png') }}" alt="" class="quote" loading="lazy">
                                    <div class="star">
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star-half-stroke"></i>
                                    </div>
                                    <p class="disc">
                                        I have used some AI writing tools liked Rytr, Peppertype, and Jasper but I found
                                        Writesonic to be the best for writing complete blog posts.
                                    </p>
                                    <div class="authore-area">
                                        <div class="author">
                                            <img src="{{ url('other/images/team/16.png') }}" alt="team" loading="lazy">
                                            <div class="info">
                                                <p>Samuel</p>
                                                <span>Blogger</span>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <!-- single swiepr end -->
                            </div>
                            <div class="swiper-slide">
                                <!-- single swiepr start -->
                                <div class="single-team-area">
                                    <div class="star">
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-sharp fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star-half-stroke"></i>
                                    </div>
                                    <p class="disc">
                                        I have used some AI writing tools liked Rytr, Peppertype, and Jasper but I found
                                        Writesonic to be the best for writing complete blog posts.
                                    </p>
                                    <div class="authore-area">
                                        <div class="author">
                                            <img src="{{ url('other/images/team/22.png') }}" alt="team" loading="lazy">
                                            <div class="info">
                                                <p>Samuel</p>
                                                <span>Blogger</span>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <!-- single swiepr end -->
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- customers review area end -->




<!-- blog area start -->
<div class="rts-faq-area pb--100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-conter-area">
                    <h2 class="title">
                        IhsanAI chatbots: <br>
                        Frequently asked questions
                    </h2>
                    {{-- IhsanAI --}}

                </div>
            </div>
        </div>
        <div class="row mt--60">
            <div class="col-lg-12">
                <div class="accordion-area-one">
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    What is IhsanAI content writing tool?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for
                                    trending topics in your industry or address common questions or challenges your
                                    audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    what languages does it supports?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for
                                    trending topics in your industry or address common questions or challenges your
                                    audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    What is Seo wirting ai and how do i use it?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for
                                    trending topics in your industry or address common questions or challenges your
                                    audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    what languages does it supports?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for
                                    trending topics in your industry or address common questions or challenges your
                                    audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    Does IhsanAI to write long articles?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for
                                    trending topics in your industry or address common questions or challenges your
                                    audience may be facing.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- blog area end -->

<!-- rts brand area start -->
<div class="rts-brand-area pb--100">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="brand-area-4">
                    <img src="other/images/brand/01.png" alt="brand-area">
                    <img src="other/images/brand/02.png" alt="brand-area">
                    <img src="other/images/brand/03.png" alt="brand-area">
                    <img src="other/images/brand/04.png" alt="brand-area">
                    <img src="other/images/brand/05.png" alt="brand-area">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- rts brand area end -->


@endsection

