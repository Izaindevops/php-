@extends('layouts.app')
@section('title',"Reset Password | ISHAN AI")
@section('content')

    <!-- reset area start -->
    <div class="rts-reset-area rts-section-gap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single-form-s-wrapper text-start ptb_sm--50">
                        <div class="head">
                            <h5 class="title">Reset Your Password</h5>
                            <p class="mb--20">Strong passwords include numbers, letters, and
                                punctuation marks.</p>
                        </div>
                        <div class="body">
                            <form method="POST" action="{{ route('password.email') }}">
                        @csrf
                                <div class="input-wrapper">
                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                                </div>
                                 @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                                
                                <button type="submit" class="rts-btn btn-primary"> {{ __('Send Password Reset Link') }}</button>
                                <p><a href="log-in.html"><i class="fa-solid fa-arrow-left"></i> Back to Login</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- rtsa reset area end -->
@endsection
