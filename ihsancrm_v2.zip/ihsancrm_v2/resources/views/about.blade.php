@extends('layouts.app')
@section('title',"About-us | ISHAN AI")
@section('content')

@endsection