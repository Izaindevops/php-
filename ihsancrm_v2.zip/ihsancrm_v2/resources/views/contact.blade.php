@extends('layouts.app')
@section('title',"Contact-us | ISHAN AI")
@section('content')
<style type="text/css">
.links-main {
    color: #ffff !important;
}

.dbox .icon span {
    font-size: 20px;
    color: #fff;
}

.dbox .icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #613C7B;
    margin: 0 auto;
    margin-bottom: 20px;
}

.backOfContack {
    background: #21599C;
}

.form-control {
    border: 1px solid #613C7B !important;
}

label {
    color: #fff;
}

</style>
<!-- rts breadcrumb area start-->
<div class="rts-bread-crumb-area bg_image">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inne">
                    <div class="title-area">
                        <h1 class="bread-title">Contact us</h1>
                        <div class="inner-wrapper">
                            <a href="/">Home</a>/
                            <a href="#" class="active">Contact us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- rts breadcrumb area end -->
<div class="pricing-plane-area rts-section-gap">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="wrapper">
                    <div class="row mb-5">
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-map-marker"></span>
                                </div>
                                <div class="text">
                                    <p><span>Address:</span> 198 West 21th Street, Suite 721 New York NY 10016</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <div class="text">
                                    <p><span>Phone:</span> <a href="tel://1234567920">+ 1235 2355 98</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-paper-plane"></span>
                                </div>
                                <div class="text">
                                    <p><span>Email:</span> <a href="mailto:info@ihsancrm.com">info@ihsancrm.com</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="dbox w-100 text-center">
                                <div class="icon d-flex align-items-center justify-content-center">
                                    <span class="fa fa-globe"></span>
                                </div>
                                <div class="text">
                                    <p><span>Website</span> <a href="#">ihsancrm.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row no-gutters backOfContack">
                        <div class="col-md-7">
                            <div class="contact-wrap w-100 p-md-5 p-4">
                                <h3 class="mb-4  text-white">Contact Us</h3>
                                <div id="form-message-warning" class="mb-4"></div>
                                {{-- <div id="form-message-success  text-white" class="mb-4">
                                    Your message was sent, thank you!
                                </div>
                                --}}
                                <form method="POST" id="contactForm" name="contactForm" class="contactForm">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="label" for="name">Full Name</label>
                                                <input type="text" class="form-control" name="name" id="name" placeholder="Name">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="label" for="email">Email Address</label>
                                                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="subject">Subject</label>
                                                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="label" for="#">Message</label>
                                                <textarea name="message" class="form-control" id="message" cols="30" rows="4" placeholder="Message"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <a href="{{route('register')}}" class="rts-btn btn-primary-2 d-none d-md-inline">Get Started</a>
                                                <div class="submitting"></div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-5 d-flex align-items-stretch p-0">
                            <div class="info-wrap w-100 p-5 img" style="background-image: url(other/images/ihsan_bot_img.jpg);background-size: cover;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
