<button style=" position: fixed; bottom: 10px; right: 10px; z-index: 100;" type="button" class="btn chatBot-btn " data-bs-toggle="modal" data-bs-target="#exampleModal ">
    <i class="fa fa-commenting-o" aria-hidden="true" style="font-size: 50px; color: rgb(95, 105, 160);"></i>
    <p>Chat Now</p>
</button>
<div class="modal fade" id="exampleModal" data-bs-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" style="max-width: 400px;
                            margin-right: 10px;">
        <div class="modal-content">
            <div class="modal-header p-0">
                <button style="padding: 7px;position: relative;top: 48px;left: -38px;z-index:5;" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="app-chat ">
                    <!-- Chat History -->
                    <div class="col app-chat-history">
                        <div class="chat-history-header border-bottom pt-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex overflow-hidden align-items-center">
                                    <div class="flex-shrink-0 avatar">
                                        <img src="{{url('assets/img/preview.png')}}" alt="Avatar" class="rounded-circle" data-bs-toggle="sidebar" data-overlay="" data-target="#app-chat-sidebar-right">
                                    </div>
                                    <div class="chat-contact-info flex-grow-1 ms-3">
                                        <h4 class="m-0 font-semibold">Name</h4>
                                        <small class="user-status text-muted">Powered By <a href="#"><strong>Ihsan Ai</strong></a> </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="chat-history-body  ps--active-y" style="background-color: #F5F5F9;">
                            <ul class="list-unstyled chat-history mb-0">
                                <li class="chat-message">
                                    <div class="d-flex overflow-hidden">
                                        <div class="user-avatar flex-shrink-0 me-3">
                                            <div class="avatar avatar-sm">
                                                <img src="{{url('assets/img/preview.png')}}" alt="Avatar" class="rounded-circle botAvatar">
                                            </div>
                                        </div>
                                        <div class="chat-message-wrapper flex-grow-1">
                                            <div class="chat-message-text">
                                                <p class="mb-0">{{$welComeMessage}}</p>
                                            </div>
                                            <div class="text-muted mt-1">
                                                <small></small>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="chat-message chat-message-right d-none ">
                                    <div class="d-flex overflow-hidden">
                                        <div class="chat-message-wrapper flex-grow-1">
                                            <div class="chat-message-text">
                                                <p class="mb-0">{{$welComeMessage}} </p>
                                            </div>
                                            <div class="text-end text-muted mt-1">
                                                <i class="bx bx-check-double text-success"></i>
                                                <small></small>
                                            </div>
                                        </div>
                                        <div class="user-avatar flex-shrink-0 ms-3">
                                            <div class="avatar avatar-sm">
                                                <img src="{{url("assets/img/avatars/1.png")}}" alt="Avatar" class="rounded-circle customeAva">
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="chat-message chat-message-right d-none ">
                                    <div class="d-flex overflow-hidden">
                                        <div class="chat-message-wrapper flex-grow-1">
                                            <div class="chat-message-text">
                                                <p class="mb-0">{{$welComeMessage}} </p>
                                            </div>
                                            <div class="text-end text-muted mt-1">
                                                <i class="bx bx-check-double text-success"></i>
                                                <small></small>
                                            </div>
                                        </div>
                                        <div class="user-avatar flex-shrink-0 ms-3">
                                            <div class="avatar avatar-sm">
                                                <img src="{{url("assets/img/avatars/1.png")}}" alt="Avatar" class="rounded-circle customeAva">
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="chat-message chat-message-right d-none">
                                    <div class="d-flex overflow-hidden">
                                        <div class="chat-message-wrapper flex-grow-1">
                                            <div class="chat-message-text">
                                                <p class="mb-0">{{$welComeMessage}} </p>
                                            </div>
                                            <div class="text-end text-muted mt-1">
                                                <i class="bx bx-check-double text-success"></i>
                                                <small></small>
                                            </div>
                                        </div>
                                        <div class="user-avatar flex-shrink-0 ms-3">
                                            <div class="avatar avatar-sm">
                                                <img src="{{url("assets/img/avatars/1.png")}}" alt="Avatar" class="rounded-circle customeAva">
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="ps__rail-x" style="left: 0px; bottom: -1059px;">
                                <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;">
                                </div>
                            </div>
                            <div class="ps__rail-y" style="top: 1059px; height: 40px; right: 0px;">
                                <div class="ps__thumb-y" tabindex="0" style="top: 39px; height: 1px;">
                                </div>
                            </div>
                        </div>
                        <!-- Chat message form -->
                        <div class="chat-history-footer mt-3">
                            <form action="{{route('chat.web')}}" class="d-flex" method="POST" id="sendMessageToWeb">
                                @csrf
                                <input class="form-control message-input border-0 me-3 shadow-none" placeholder="Type your message here..." id="message" name="message" minlength="2">
                                <input type="hidden" value="{{$uid}}" name="randomKey">
                                <input type="hidden" value="{{Auth::user()->email}}" name="email">
                                <input type="hidden" value="{{Auth::user()->name}}" name="name">
                                <button type="submit" class="btn btn-primary btn-sm d-flex send-msg-btn d-flex align-items-center justify-content-center">
                                    <i class="bx bx-paper-plane me-md-1 me-0"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /Chat History -->
                <!-- Sidebar Right -->
                <div class="app-overlay"></div>
            </div>
        </div>
    </div>
</div>
<script>
// Function to display a new message in the chat box



// Event handler for clicking the send button
/*      $("#sendMessageBtn").on("click", function () {
          var message = $("#messageInput").val().trim();
          if (message !== "") {
              sendMessage(message);
              $("#messageInput").val("");
          }
      });

      // Event handler for pressing Enter in the input field
      $("#messageInput").on("keypress", function (event) {
          if (event.which === 13) {
              var message = $("#messageInput").val().trim();
              if (message !== "") {
                  sendMessage(message);
                  $("#messageInput").val("");
              }
          }
      });*/



// Function to send a message via AJAX

</script>
