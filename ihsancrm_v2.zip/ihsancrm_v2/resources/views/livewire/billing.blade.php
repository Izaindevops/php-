<div class="card mb-4">
      <!-- Current Plan -->
      <h5 class="card-header">Current Plan</h5>
            @if(Auth::user()->isPaid)

      <div class="card-body">
        <div class="row">
          <div class="col-md-6 mb-1">
            <div class="mb-4">
              <h6 class="fw-semibold mb-2">Your Current Plan is {{ucwords(Auth::user()->planId)}}</h6>
              <p>A simple start for everyone</p>
            </div>
            <div class="mb-4">
              @php
                $time = strtotime(Auth::user()->planActiveTime);
$final = date("M d-Y", strtotime("+1 month", $time));
$now = time(); // or your date as well
$your_date = strtotime(date("Y-m-d", strtotime("+1 month", $time)));
$datediff = $now - $your_date;
$percentage = (abs(round($datediff / (60 * 60 * 24))) / 30) * 100;


              @endphp
              <h6 class="fw-semibold mb-2">Active until {{$final}}</h6>
              <p>We will send you a notification upon Subscription expiration</p>
            </div>
            <div class="mb-4">
              <h6 class="fw-semibold mb-2"><span class="me-2">${{ucwords(getPlans()[2]->price)}} Per Month</span> <span class="badge bg-label-primary">Popular</span></h6>
              <p>Standard plan for small to medium businesses</p>
            </div>
          </div>
          <div class="col-md-6 mb-1">
            <div class="alert alert-warning mb-4 d-none" role="alert">
              <h6 class="alert-heading fw-bold mb-1">We need your attention!</h6>
              <span>Your plan requires update</span>
            </div>
            <div class="plan-statistics">
              <div class="d-flex justify-content-between">
                <span class="fw-semibold mb-2">Days</span>
                <span class="fw-semibold mb-2">{{abs(round($datediff / (60 * 60 * 24)))}} of 30 Days</span>
              </div>
              <div class="progress">
                <div class="progress-bar " style="width:{{abs(round($percentage))}}% " role="progressbar" aria-valuenow="{{abs(round($percentage))}}" aria-valuemin="0" aria-valuemax="30"></div>
              </div>
              <p class="mt-1 mb-0">{{abs(round($datediff / (60 * 60 * 24)))}} days remaining until your plan requires update</p>
            </div>
          </div>
        </div>
      </div>
      @else 
      <h4 class="text-center">You have not Actived any plan</h4>

      @endif
      <!-- Modal -->


      <!-- /Modal -->

      <!-- /Current Plan -->
    </div>
    <div class="card overflow-hidden">
  <!-- Pricing Plans -->
      
  <div class="pb-sm-5 pb-2 rounded-top">
    <div class="container py-5">
      <h2 class="text-center mb-2 mt-0 mt-md-4">Find the right plan for your site</h2>
      <p class="text-center pb-3"> Get started with us - it's perfect for individuals and teams. Choose a subscription plan that meets your needs. </p>
      <div class="row mx-0 gy-3 px-lg-5">
        <!-- Basic -->
        <div class="col-lg mb-md-0 mb-4">
          <div class="card border rounded shadow-none">
            <div class="card-body">
              <div class="my-3 pt-2 text-center">
                <img src="{{url('assets/img/icons/unicons/cc-primary.png')}}" alt="Starter Image" height="80">
              </div>
              <h3 class="card-title fw-semibold text-center text-capitalize mb-1">{{ucwords(getPlans()[0]->name)}}</h3>
              <p class="text-center">A simple start for everyone</p>
              <div class="text-center">
                <div class="d-flex justify-content-center">
                  <sup class="h6 pricing-currency mt-3 mb-0 me-1 text-primary">$</sup>
                  <h1 class="fw-semibold display-4 mb-0 text-primary">{{getPlans()[0]->price}}</h1>
                  <sub class="h6 pricing-duration mt-auto mb-2 text-muted fw-normal">/month</sub>
                </div>
              </div>

              <ul class="ps-3 my-4 list-unstyled">
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span>Limit Bots</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Unlimited forms and surveys</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Unlimited fields</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Basic form creation tools</li>
                <li class="mb-0"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Up to 2 subdomains</li>
              </ul>
              @if(getPlans()[0]->name==Auth::user()->planId)
              <a href="javascript:void(0)" disabled class="btn btn-secondary d-grid w-100">Activated</a>
              @else
              <a href="{{route('upgrade.plan',getPlans()[0]->name)}}" class="btn btn-primary d-grid w-100">Upgrade</a>
              @endif
            </div>
          </div>
        </div>

        <!-- Pro -->
        <div class="col-lg mb-md-0 mb-4">
          <div class="card border-primary border shadow-none">
            <div class="card-body position-relative">
              <div class="position-absolute end-0 me-4 top-0 mt-4">
                <span class="badge bg-label-primary">Popular</span>
              </div>
              <div class="my-3 pt-2 text-center">
                <img src="{{url('assets/img/icons/unicons/cc-success.png')}}" alt="Pro Image" height="80">
              </div>
              <h3 class="card-title fw-semibold text-center text-capitalize mb-1">{{ucwords(getPlans()[1]->name)}}</h3>
              <p class="text-center">For small to medium businesses</p>
              <div class="text-center">
                <div class="d-flex justify-content-center">
                  <sup class="h6 pricing-currency mt-3 mb-0 me-1 text-primary">$</sup>
                  <h1 class="price-toggle price-yearly fw-semibold display-4 text-primary mb-0">{{getPlans()[1]->price}}</h1>
                  <h1 class="price-toggle price-monthly fw-semibold display-4 text-primary mb-0 d-none">49</h1>
                  <sub class="h6 text-muted pricing-duration mt-auto mb-2 fw-normal">/month</sub>
                </div>
                <small class="price-yearly price-yearly-toggle text-muted"></small>
              </div>

              <ul class="ps-3 my-4 list-unstyled">
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Up to 5 users</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> 120+ components</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Basic support on Github</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Monthly updates</li>
                <li class="mb-0"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Integrations</li>
              </ul>

                @if(getPlans()[1]->name==Auth::user()->planId))
              <a href="javascript:void(0)" disabled class="btn btn-secondary d-grid w-100">Activated</a>
              @else
              <a href="{{route('upgrade.plan',getPlans()[1]->name)}}" class="btn btn-primary d-grid w-100">Upgrade</a>
              @endif
            </div>
          </div>
        </div>

        <!-- Enterprise -->
        <div class="col-lg">
          <div class="card border rounded shadow-none">
            <div class="card-body">

              <div class="my-3 pt-2 text-center">
                <img src="{{url('assets/img/icons/unicons/cc-warning.png')}}" alt="Pro Image" height="80">
              </div>
              <h3 class="card-title text-center text-capitalize fw-semiboldA mb-1">{{ucwords(getPlans()[2]->name)}}</h3>
              <p class="text-center">Solution for big organizations</p>

              <div class="text-center">
                <div class="d-flex justify-content-center">
                  <sup class="h6 text-primary pricing-currency mt-3 mb-0 me-1">$</sup>
                  <h1 class="price-toggle price-yearly fw-semibold display-4 text-primary mb-0">{{getPlans()[2]->price}}</h1>
                  <h1 class="price-toggle price-monthly fw-semibold display-4 text-primary mb-0 d-none">99</h1>
                  <sub class="h6 pricing-duration mt-auto mb-2 fw-normal text-muted">/month</sub>
                </div>
                <small class="price-yearly price-yearly-toggle text-muted"></small>
              </div>

              <ul class="ps-3 my-4 list-unstyled">
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Up to 10 users</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> 150+ components</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Basic support on Github</li>
                <li class="mb-2"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Monthly updates</li>
                <li class="mb-0"><span class="badge badge-center w-px-20 h-px-20 rounded-pill bg-label-primary me-2"><i class="bx bx-check bx-xs"></i></span> Speedy build tooling</li>
              </ul>

                @if(getPlans()[2]->name==Auth::user()->planId))
              <a href="javascript:void(0)" disabled class="btn btn-secondary d-grid w-100">Activated</a>
              @else
              <a href="{{route('upgrade.plan',getPlans()[2]->name)}}" class="btn btn-primary d-grid w-100">Upgrade</a>
              @endif
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--/ FAQS -->
</div>