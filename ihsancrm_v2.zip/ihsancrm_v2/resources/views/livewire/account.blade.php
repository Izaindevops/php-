<div class="card">
    <h5 class="card-header">Profile Details</h5>
    <hr class="my-0" />
    <div class="card-body">
        <form id="formAccountSettings" method="POST" action="{{route('user.profile.update')}}">
            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="firstName" class="form-label">Name *</label>
                    <input class="form-control" type="text" id="firstName" name="name" value="{{Auth::user()->name}}" autofocus />
                </div>
                <div class="mb-3 col-md-6">
                    <label for="email" class="form-label">E-mail</label>
                    <input readonly class="form-control" type="text" id="email" name="email" value="{{Auth::user()->email}}" placeholder="john.doe@example.com" />
                </div>
                <div class="mb-3 col-md-6">
                    <label for="organization" class="form-label">Organization</label>
                    <input type="text" class="form-control" name="organization" value="{{Auth::user()->organization}}" value="ThemeSelection" />
                </div>
                @csrf
                <div class="mb-3 col-md-6">
                    <label class="form-label" for="phoneNumber">Phone Number *</label>
                    <div class="input-group input-group-merge">
                        <input type="text" name="phoneNumber" value="{{Auth::user()->phone}}" class="form-control" placeholder="+1 202 555 0111" />
                    </div>
                </div>
                <div class="mb-3 col-md-10 mx-auto">
                    <label for="address" class="form-label">Address</label>
                    <textarea class="form-control" name="address">{{Auth::user()->address}}</textarea>
                </div>
                <div class="mb-3 col-md-6">
                    <label for="state" class="form-label">State</label>
                    <input class="form-control" value="{{Auth::user()->state}}" type="text" id="state" name="state" placeholder="California" />
                </div>
                <div class="mb-3 col-md-6">
                    <label for="zipCode" class="form-label">Zip Code</label>
                    <input type="text" class="form-control" id="zipCode" name="zipCode" placeholder="231465" maxlength="6" value="{{Auth::user()->zipCode}}" />
                </div>
                <div class="mb-3 col-md-4">
                    <label class="form-label" for="country">Country</label>
                    <select name="country" class="select2 form-select">
                        <option value="">Select</option>
                        <option {{(Auth::user()->country=="Australia")?"selected":""}} value="Australia">Australia</option>
                        <option {{(Auth::user()->country=="Canada")?"selected":""}} value="Canada">Canada</option>
                        <option {{(Auth::user()->country=="United Kingdom")?"selected":""}} value="United Kingdom">United Kingdom</option>
                        <option {{(Auth::user()->country=="United States")?"selected":""}} value="United States">United States</option>
                    </select>
                </div>
                <div class="mb-3 col-md-4">
                    <label for="timeZones" class="form-label">Timezone</label>
                    <select name="timeZone" class="select2 form-select">
                        <option {{(Auth::user()->timeZone=="")?"selected":""}} value="">Select Timezone</option>
                        <option {{(Auth::user()->timeZone=="-12")?"selected":""}} value="-12">(GMT-12:00) International Date Line West</option>
                        <option {{(Auth::user()->timeZone=="-8")?"selected":""}} value="-8">(GMT-08:00) Pacific Time (US & Canada)</option>
                        <option {{(Auth::user()->timeZone=="-8")?"selected":""}} value="-8">(GMT-08:00) Tijuana, Baja California</option>
                        <option {{(Auth::user()->timeZone=="-7")?"selected":""}} value="-7">(GMT-07:00) Arizona</option>
                        <option {{(Auth::user()->timeZone=="-7")?"selected":""}} value="-7">(GMT-07:00) Chihuahua, La Paz, Mazatlan</option>
                        <option {{(Auth::user()->timeZone=="-7")?"selected":""}} value="-7">(GMT-07:00) Mountain Time (US & Canada)</option>
                        <option {{(Auth::user()->timeZone=="-6")?"selected":""}} value="-6">(GMT-06:00) Central America</option>
                        <option {{(Auth::user()->timeZone=="-6")?"selected":""}} value="-6">(GMT-06:00) Central Time (US & Canada)</option>
                        <option {{(Auth::user()->timeZone=="-6")?"selected":""}} value="-6">(GMT-06:00) Guadalajara, Mexico City, Monterrey</option>
                        <option {{(Auth::user()->timeZone=="-6")?"selected":""}} value="-6">(GMT-06:00) Saskatchewan</option>
                        <option {{(Auth::user()->timeZone=="-5")?"selected":""}} value="-5">(GMT-05:00) Bogota, Lima, Quito, Rio Branco</option>
                        <option {{(Auth::user()->timeZone=="-5")?"selected":""}} value="-5">(GMT-05:00) Eastern Time (US & Canada)</option>
                        <option {{(Auth::user()->timeZone=="-4")?"selected":""}} value="-4">(GMT-04:00) Atlantic Time (Canada)</option>
                        <option {{(Auth::user()->timeZone=="-4"
)?"selected":""}} value="-4">(GMT-04:00) Caracas, La Paz</option>
                    </select>
                </div>
                <div class="col-sm-4">
                    <small class="text-light fw-semibold d-inline">Select Your Payment Method</small><br>
                    <div class="form-check form-check-inline mt-3">
                        <input class="form-check-input" {{(Auth::user()->payment_method=="paypal")?"checked":""}} type="radio" name="paymentMethod" id="inlineRadio1" value="paypal">
                        <label class="form-check-label" for="inlineRadio1">Paypal</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" {{(Auth::user()->payment_method=="stripe")?"checked":""}} type="radio" name="paymentMethod
" id="inlineRadio2" value="stripe">
                        <label class="form-check-label" for="inlineRadio2">Stripe</label>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                <button type="submit" class="btn btn-primary me-2">Save changes</button>
                <button type="reset" class="btn btn-outline-secondary">Cancel</button>
            </div>
        </form>
    </div>
    <!-- /Account -->
</div>
