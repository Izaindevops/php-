<div>
    <!-- Button trigger modal -->
   
    <div class="modal fade" id="smallModal" tabindex="-1" style="display: none;" aria-hidden="true">
        <div class="modal-dialog " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel2">Grab numbers from your CSV file</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="nav-align-top mb-4">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#navs-top-home" aria-controls="navs-top-home" aria-selected="true">By Link</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#navs-top-profile" aria-controls="navs-top-profile" aria-selected="false" tabindex="-1">By File</button>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="navs-top-home" role="tabpanel">
                                @if ( session()->has('success') )
                                    
                               
                                <div class="alert alert-dark">
                                    {{session()->has('message')}} 
                                </div>
                                @endif
                                <form action="{{route('sms.by.link')}}" id="sheet_form" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="botKey" value="{{$botKey}}" id="">
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label for="sheet_id" class="form-label">Sheet ID</label>
                                            <input type="text" id="sheet_id"  name="sheet_id" class="form-control" placeholder="Enter Sheet ID">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label for="column_name" class="form-label w-100">Column Name <i class="fa fa-info text-primary float-right h5" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<span>Enter First phone number of column</span>"></i></label>
                                            <input type="text" id="page_url"  name="column_name" class="form-control" placeholder="Enter Column Name">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                            </div>
                            <div class="tab-pane fade" id="navs-top-profile" role="tabpanel">
                                <form action="{{route('sms.by.file')}}" id="sheet_form" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="botKey" value="{{$botKey}}" id="">
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label for="sheet_file" class="form-label">Sheet File</label>
                                            <input type="file" id="sheet_file"  name="sheet_file" class="form-control" placeholder="L" accept=".csv">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col mb-3">
                                            <label for="column_name" class="form-label w-100">Column Name <i class="fa fa-info text-primary float-right h5" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<span>Enter First phone number of column</span>"></i></label>
                                            <input type="text" id="column_name"  name="column_name" class="form-control" placeholder="Enter Column Name">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
</div>