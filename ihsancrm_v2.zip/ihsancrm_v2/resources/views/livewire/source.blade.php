@if(isset($uid) AND $uid!=null)
<div class="row">
    <div class="col-sm-6">
        <h4>Source</h4>
        <p>Upload documents to your knowledge base or website to train on
            your own data.</p>
        <form class="form-bs-inline" action="{{route('bot.file',$uid)}}" method="POST" enctype="multipart/form-data">
            @csrf
            {{-- sendDummyFile --}}
            <input class="form-control" required type="file" name="files" accept=".pdf">
            <button type="submit" class="btn btn-dark mt-2 float-right">Upload and Train </button>
        </form>
    </div>
    <div class="col-sm-6">
        @if($listOfFiles[0]!=null && count($listOfFiles)>0)
        <div class="card mt-5">
            <div class="card-body">
                <table class="table w-100 ">
                    <thead></thead>
                    <tbody id="appendDataFiles">
                        @if($listOfFiles[0]!=null && count($listOfFiles)>0)
                        @foreach(json_decode($listOfFiles[0]) as $key => $file_name)
                        <tr>
                            <td>
                                <p style="word-wrap: break-word;">{{$file_name}}</p>
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>

                </table>
            </div>
        </div>
        @endif
    </div>
</div>
@endif
