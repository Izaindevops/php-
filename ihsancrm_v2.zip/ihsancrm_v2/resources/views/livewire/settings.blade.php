<div>
                  <ul class="nav nav-pills flex-column flex-md-row mb-3">
       

                    <li class="nav-item">
                      <a href="{{ route('settings.account') }}" wire:click.prevent="changeTab('account')" class="nav-link {{ $activeTab === 'account' ? 'active' : '' }}" ><i class="bx bx-user me-1"></i> Account</a>
                    </li>
                    <li class="nav-item">
                      <a href="{{ route('settings.account') }}" wire:click.prevent="changeTab('security')" class="nav-link  {{ $activeTab === 'security' ? 'active' : '' }}"
                        ><i class="bx bx-lock me-1"></i> Security</a
                      >
                    </li>
                    <li class="nav-item">
                      <a href="{{ route('settings.account') }}" wire:click.prevent="changeTab('billing')" class="nav-link {{ $activeTab === 'billing' ? 'active' : '' }}"
                        ><i class="bx bx-detail-alt me-1"></i> Billing & Plans</a
                      >
                    </li>
                  
    </ul>

    <div wire:loading>
        Loading...
    </div>

    <div wire:loading.remove>
        @if ($activeTab === 'account')
            <livewire:account />
        @elseif ($activeTab === 'security')
            <livewire:security />
        @elseif ($activeTab === 'billing')
            <livewire:billing />
        @endif
    </div>
      <script>
        document.addEventListener('livewire:load', function () {
            Livewire.on('changeTab', function (tab, url) {
                history.pushState(null, null, url);
            });
        });
    </script>   
</div>
