<div>
    <style>
        .chat-contact-list-item:hover {
      background-color: rgba(66, 69, 68, 0.049) !important;
    }
    .list-unstyled.chat-history{
            height: 100vh;
    overflow-y: scroll;
    }
    </style>
    <div class="app-chat overflow-hidden card">
        <div class="row g-0">
     
            <!-- Chat & Contacts -->
            <div class="col app-chat-contacts app-sidebar flex-grow-0 overflow-hidden border-end" id="app_chat-contacts">
                <div class="sidebar-header pt-3 px-3 mx-1">
                    <div class="d-flex align-items-center me-3 me-lg-0">
                        <div class="flex-grow-1 input-group input-group-merge rounded-pill ms-1">
                            <span class="input-group-text" id="basic-addon-search31"><i class="bx bx-search fs-4"></i></span>
                            <input type="text" class="form-control chat-search-input" placeholder="Search..." aria-label="Search..." aria-describedby="basic-addon-search31">
                        </div>
                    </div>
                    <i class="bx bx-x cursor-pointer position-absolute top-0 end-0 mt-2 me-1 fs-4 d-lg-none d-block chat_menu" data-overlay="" data-bs-toggle="sidebar" data-target="#app-chat-contacts"></i>
                </div>
                <hr class="container-m-nx mt-3 mb-0">
                <div class="sidebar-body ps ps--active-y">
                    <!-- Chats -->
                    <ul class="list-unstyled chat-contact-list pt-1" id="chat-list">
                        <li class="chat-contact-list-item chat-contact-list-item-title">
                            <h5 class="text-primary mb-0">SMS</h5>
                        </li>
                        <li class="chat-contact-list-item chat-list-item-0 d-none">
                            <h6 class="text-muted mb-0">No Chats Found</h6>
                        </li>
                        @php
                            //$getData=DB::table('ai_sms')->where('user_id',Auth::user()->id)->get();
                            $getData=DB::table('ai_sms')->select('from_person')->distinct()->where('user_id',Auth::user()->id)->orderBy('created_at','desc')->get();
                            foreach ($getData as $key => $values) {
                               $lastMessage =DB::table('ai_sms')->where('from_person',$values->from_person)->get();
                        @endphp
                           
                        <li wire:click="getAllSMS('{{$values->from_person}}')"   class="chat-contact-list-item {{($selectedUserId==$lastMessage[0]->from_person)?'active':''}}">
                            <a class="d-flex align-items-center" >
                                <div class="flex-shrink-0 avatar" >
                                    <img   src="{{getBotByID($lastMessage[0]->bot_id)[0]->bot_logo}}" alt="Avatar" class="rounded-circle">
                                </div>
                                <div class="chat-contact-info flex-grow-1 ms-3">
                                    <h6 class="chat-contact-name text-truncate m-0">{{$values->from_person}}</h6>
                                    <p class="chat-contact-status text-truncate mb-0 text-muted">{{getBotByID($lastMessage[0]->bot_id)[0]->bot_name}}</p>
                                </div>
                                <small class="text-muted mb-auto">{{getTimeFormat('h:m:s ',$lastMessage[0]->created_at)}}</small>
                            </a>
                        </li>
                        @php
                    }
                        @endphp
                    </ul>
                    <!-- Contacts -->
                    <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                        <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                    </div>
                    <div class="ps__rail-y" style="top: 0px; height: 377px; right: 0px;">
                        <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 132px;"></div>
                    </div>
                </div>
            </div>
            <!-- /Chat contacts -->
            <!-- Chat History -->
            @if ($selectedUserId)
                
          
            <div class="col app-chat-history" >
                <div class="chat-history-wrapper">
                    <div class="chat-history-header border-bottom">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex overflow-hidden align-items-center">
                                <i class="bx bx-menu bx-sm cursor-pointer d-lg-none d-block me-2 chat_menu" data-bs-toggle="sidebar" data-overlay="" data-target="#app-chat-contacts"></i>
                                <div class="flex-shrink-0 avatar">
                                    <img src="{{$messagesIMG}}" alt="Avatar" class="rounded-circle" data-bs-toggle="sidebar" data-overlay="" data-target="#app-chat-sidebar-right">
                                </div>
                                <div class="chat-contact-info flex-grow-1 ms-3">
                                    <h6 class="m-0">{{$messagesBot}}</h6>
                                    <small class="user-status text-muted">{{$messagesName}}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                       <div class="chat-history-body ps ps--active-y" style="background-color:#d9dee340;">
                         <ul class="list-unstyled chat-history mb-0" >
                            
                            @php
                            
                        if (count($messagesAll)>0) {
                                    # code...
                                 
                              foreach ($messagesAll as $value) {
                            
                                if ($value->is_bot==0) {
                                # code...
                        
                            @endphp
                            <li class="chat-message">
                                <div class="d-flex overflow-hidden">
                                    <div class="user-avatar flex-shrink-0 me-3">
                                        <div class="avatar avatar-sm">
                                            <img src="{{getBotByID($value->bot_id)[0]->bot_logo}}" alt="Avatar" class="rounded-circle">
                                        </div>
                                    </div>
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0">{{$value->body}}</p>
                                        </div>
                                      
                                        <div class="text-muted mt-1">
                                            <small>{{getTimeFormat('h:m:s ',$value->created_at)}}</small>
                                        </div>
                                    </div>
                                </div>
                            </li>  
                            @php
                                }else {
                            @endphp
                            <li class="chat-message chat-message-right ">
                                <div class="d-flex overflow-hidden">
                                    <div class="chat-message-wrapper flex-grow-1">
                                        <div class="chat-message-text">
                                            <p class="mb-0 text-white">{{$value->body}}</p>
                                        </div>
                                        <div class="text-end text-muted mt-1">
                                           
                                            <small>{{getTimeFormat('h:m:s ',$value->created_at)}}</small>
                                        </div>
                                    </div>
                                    <div class="user-avatar flex-shrink-0 ms-3">
                                        <div class="avatar avatar-sm">
                                            <img src="{{url('assets/img/android-svgrepo-com.svg')}}" alt="Avatar" class="rounded-circle">
                                        </div>
                                    </div>
                                </div>
                            </li>

                            @php
                                } 
                            }
                        }
                            @endphp
                        </ul>
                        <div class="ps__rail-x" style="left: 0px; bottom: -783px;">
                            <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                        </div>
                        <div class="ps__rail-y" style="top: 783px; height: 292px; right: 0px;">
                            <div class="ps__thumb-y" tabindex="0" style="top: 212px; height: 79px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            <!-- /Chat History -->
      
        </div>
    </div>
    
    <x-panel.foot />
    <script src="{{url('assets/js/custom.js')}}"></script>
    
    </div>