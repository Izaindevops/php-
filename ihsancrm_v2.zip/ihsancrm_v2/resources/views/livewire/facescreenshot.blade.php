<div class="container">
  <div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                <div class="col-sm-6"></div>
                <div class="col-sm-6">
                   @if ($imageData!=null AND $codeMessage=='200')
                    <a class="btn btn-primary float-right mx-1" href="{{route('facebook.session.stop',['key'=>$brid])}}">Unlink Account</a>
                    @else
                     
                    @endif
                   
                          <a class="btn btn-outline-primary float-right mx-1" href="{{route("facebook.show")}}">Go Back</a>
                </div>
            </div>
            </div>
            <div class="card-body">
                
      <div wire:poll.59s="screenDiv" class="mx-auto" style="height: 100vh;background-color:#white">

        @if ($imageData!=null AND $codeMessage=='200')
        <img src="data:image/jpeg;base64,{{ $imageData }}" alt="Image">
        @else
        @if ($codeMessage!=0)
       <div class="row">
        <div class="col-sm-8 mx-auto">
          <div class="alert alert-danger mt-5 ">
            <i class='bx bxs-error-circle  mr-2 mt-1'></i>

            {{$codeMessage}}.Your Sesssion has been Closed or Not Created Yet 
            <a href="{{route('facebook.show')}}">Click Here to Create Again</a>
          </div>
        </div>
       </div>

        @endif
        @endif

        </div>
      
            </div>
        </div>
    </div>
    </div>
  </div>
  
</div>