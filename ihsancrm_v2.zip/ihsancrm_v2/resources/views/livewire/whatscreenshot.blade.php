<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <div wire:poll.5s="screenDiv" class="mx-auto" style="height: 100vh;background-color:#white">

        @if ($imageData!=null AND $codeMessage=='200')
  
        <img src="data:image/jpeg;base64,{{ $imageData }}" alt="Image">
        @else


        @endif



        {{-- <div class="d-flex justify-content-center align-items-center">


          <div class="spinner-border spinner-border-lg text-primary " role="status">
            <span class="visually-hidden">Loading...</span>

          </div> --}}
        </div>
      </div>
    </div>
  </div>

</div>
