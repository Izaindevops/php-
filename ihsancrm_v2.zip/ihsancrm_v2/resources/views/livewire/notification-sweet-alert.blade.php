<div>
   @if ($modFor=='smsai_unlink')
    @php
        $modalMessage="Do you want to unlink your  bot from SMS";
    @endphp
        <button  wire:click="alertConfirm" type="button" title="Logout" class="btn btn-sm btn-dark">Unlink<i class='bx bx-log-out'></i></button> <br>
   @endif
   @if ($modFor=='smsai_showkey')
         @php
        $modalMessage=$paraValue;
        $modalText="Bot Api Key";
    @endphp
        <button wire:click="showSMSKey" type="submit" title="Check Session" class="btn btn-sm btn-secondary">SMS Ai Key<i class='bx bx-show'></i></button>  <br>
   @endif
</div>