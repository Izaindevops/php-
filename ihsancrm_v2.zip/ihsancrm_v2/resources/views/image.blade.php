@extends('layouts.panel')
@section('content')
$imageData = base64_encode($image->image_blob);

return view('image.show', compact('imageData'));
<img src="data:image/jpeg;base64,{{ $imageData }}" alt="Image">
@endsection