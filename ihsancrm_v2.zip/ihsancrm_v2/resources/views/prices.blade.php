@extends('layouts.app')
@section('title',"Prices | ISHAN AI")
@section('content')
<style type="text/css">
.links-main {
    color: #ffff !important;
}

</style>
<!-- rts breadcrumb area start-->
<div class="rts-bread-crumb-area bg_image">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-inne">
                    <div class="title-area">
                        <h1 class="bread-title">Pricing Plan</h1>
                        <div class="inner-wrapper">
                            <a href="/">Home</a>/
                            <a href="#" class="active">Pricing Plan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- rts breadcrumb area end -->
<!-- rts pricing plane area start -->
<div class="pricing-plane-area rts-section-gap">
    <div class="container">
        <div class="row">
            <div class="col-lgl-12">
                <div class="title-conter-area">
                    <span class="pre-title-bg">Pricing Plane</span>
                    <h2 class="title">
                        Ready to Get Started? <br>
                        We'll Keep You Under Budget
                    </h2>
                </div>
            </div>
        </div>
        <!-- tabs area start -->
        <div class="tab-area-pricing-two mt--30">
            <ul class="nav nav-tabs pricing-button-one two" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class=" active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Monthly Pricing</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Annual Pricing</button>
                </li>
                <li class="save-badge">
                    <span>SAVE 25%</span>
                </li>
            </ul>
            <div class="tab-content mt--20" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <div class="row g-5 mt--10">
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <!-- single pricing-area -->
                            <div class="single-pricing-single-two active">
                                <div class="head">
                                    <span class="top">Basic</span>
                                    <div class="date-use">
                                        <h4 class="title">$Free</h4>
                                        <span>/month</span>
                                    </div>
                                </div>
                                <div class="body">
                                    <p class="para">A premium pricing plan is a pricing <br> structure that is designed.</p>
                                    <div class="check-wrapper">
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>10,000 Monthly Word Limit</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>10+ Templates</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>All types of content</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>10+ Languages</p>
                                        </div>
                                        <!-- single check end-->
                                    </div>
                                    <a href="#" class="pricing-btn">Get Started</a>
                                </div>
                            </div>
                            <!-- single pricing-area end -->
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <!-- single pricing-area -->
                            <div class="single-pricing-single-two active">
                                <div class="head">
                                    <span class="top">Diamond</span>
                                    <div class="date-use">
                                        <h4 class="title">$399</h4>
                                        <span>/month</span>
                                    </div>
                                </div>
                                <div class="body">
                                    <p class="para">A premium pricing plan is a pricing <br> structure that is designed.</p>
                                    <div class="check-wrapper">
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>60,000 Monthly Word Limit</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>60+ Templates</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>All types of content</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>60+ Languages</p>
                                        </div>
                                        <!-- single check end-->
                                    </div>
                                    <a href="#" class="pricing-btn">Get Started</a>
                                </div>
                            </div>
                            <!-- single pricing-area end -->
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <!-- single pricing-area -->
                            <div class="single-pricing-single-two active">
                                <div class="head">
                                    <span class="top">Silver</span>
                                    <div class="date-use">
                                        <h4 class="title">$199</h4>
                                        <span>/month</span>
                                    </div>
                                </div>
                                <div class="body">
                                    <p class="para">A premium pricing plan is a pricing <br> structure that is designed.</p>
                                    <div class="check-wrapper">
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>30,000 Monthly Word Limit</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>30+ Templates</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>All types of content</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>40+ Languages</p>
                                        </div>
                                        <!-- single check end-->
                                    </div>
                                    <a href="#" class="pricing-btn">Get Started</a>
                                </div>
                            </div>
                            <!-- single pricing-area end -->
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <div class="row g-5 mt--10">
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <!-- single pricing-area -->
                            <div class="single-pricing-single-two">
                                <div class="head">
                                    <span class="top">Basic</span>
                                    <div class="date-use">
                                        <h4 class="title">$Free</h4>
                                        <span>/month</span>
                                    </div>
                                </div>
                                <div class="body">
                                    <p class="para">A premium pricing plan is a pricing <br> structure that is designed.</p>
                                    <div class="check-wrapper">
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>10,000 Monthly Word Limit</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>10+ Templates</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>All types of content</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>10+ Languages</p>
                                        </div>
                                        <!-- single check end-->
                                    </div>
                                    <a href="#" class="pricing-btn">Get Started</a>
                                </div>
                            </div>
                            <!-- single pricing-area end -->
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <!-- single pricing-area -->
                            <div class="single-pricing-single-two active">
                                <div class="head">
                                    <span class="top">Diamond</span>
                                    <div class="date-use">
                                        <h4 class="title">$399</h4>
                                        <span>/month</span>
                                    </div>
                                </div>
                                <div class="body">
                                    <p class="para">A premium pricing plan is a pricing <br> structure that is designed.</p>
                                    <div class="check-wrapper">
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>60,000 Monthly Word Limit</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>60+ Templates</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>All types of content</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>60+ Languages</p>
                                        </div>
                                        <!-- single check end-->
                                    </div>
                                    <a href="#" class="pricing-btn">Get Started</a>
                                </div>
                            </div>
                            <!-- single pricing-area end -->
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <!-- single pricing-area -->
                            <div class="single-pricing-single-two">
                                <div class="head">
                                    <span class="top">Silver</span>
                                    <div class="date-use">
                                        <h4 class="title">$199</h4>
                                        <span>/month</span>
                                    </div>
                                </div>
                                <div class="body">
                                    <p class="para">A premium pricing plan is a pricing <br> structure that is designed.</p>
                                    <div class="check-wrapper">
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>30,000 Monthly Word Limit</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>30+ Templates</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>All types of content</p>
                                        </div>
                                        <!-- single check end-->
                                        <!-- single check -->
                                        <div class="check-area">
                                            <i class="fa-solid fa-check"></i>
                                            <p>40+ Languages</p>
                                        </div>
                                        <!-- single check end-->
                                    </div>
                                    <a href="#" class="pricing-btn">Get Started</a>
                                </div>
                            </div>
                            <!-- single pricing-area end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- tabs area end -->
    </div>
</div>
<!-- rts pricing plane area end -->
<!-- rts faq area stat -->
<div class="rts-faq-area rts-section-gapBottom bg_faq">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-conter-area">
                    <h2 class="title">
                        Questions About our GenAI? <br>
                        We have Answers!
                    </h2>
                    <p class="disc">
                        please feel free to reach out to us. We are always happy to assist you and provide any additional.
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt--60">
            <div class="col-lg-12">
                <div class="accordion-area-one">
                    <div class="accordion" id="accordionExample">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    What is AhsanAI content writing tool?
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for trending topics in your industry or address common questions or challenges your audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    what languages does it supports?
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for trending topics in your industry or address common questions or challenges your audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    What is sEO wirting ai and how do i use it?
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for trending topics in your industry or address common questions or challenges your audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFour">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    what languages does it supports?
                                </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for trending topics in your industry or address common questions or challenges your audience may be facing.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingFive">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    Does AhsanAI to write long articles?
                                </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    Once you know your audience, choose a topic that will resonate with them. Look for trending topics in your industry or address common questions or challenges your audience may be facing.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- rts faq area end -->
<!-- cta area start -->
<!-- cta area start -->
<div class="rts-cta-area rts-section-gapBottom  bg_faq">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="cta-main-wrapper bg_image">
                    <div class="left">
                        <h3 class="title">
                            All set to level up <br>
                            your content game?
                        </h3>
                        <a href="{{route('register')}}" class="rts-btn btn-primary">Get Started Now</a>
                    </div>
                    <div class="right">
                        <img src="{{url('assets/images/cta/02.png')}}" alt="cta-area">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- cta area end -->
<!-- cta area end -->
@endsection
