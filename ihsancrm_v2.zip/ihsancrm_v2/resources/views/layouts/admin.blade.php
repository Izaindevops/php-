<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
@notifyCss
<x-admin.head />
@livewireStyles
<style type="text/css">
#laravel-notify {
    z-index: +999999 !important;
}

</style>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            <x-admin.aside />
            <!-- / Menu -->
            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <x-admin.header />
                <!-- / Navbar -->
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    @yield('content')
                  @include('sweetalert::alert')

                    <x-notify::notify />
                </div>
            </div>
        </div>
    </div>
    @livewireScripts
    @notifyJs
    @stack('js')
</body>

</html>
