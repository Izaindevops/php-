<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
     <x-head/>

<body class="index-four">
      <x-header/>

      @yield('content')
<x-footer/>
    <div id="anywhere-home" class="">
    </div>
<x-sidebar/>

    <script src="other/js/jquery.min.js" defer></script>
    <script src="other/js/metismenu.js" defer></script>
    <script src="other/js/bootstrap.min.js" defer></script>
    <script src="other/js/swiper.js" defer></script>
    <script src="other/js/contact.form.js" defer></script>
    <script src="other/js/main.js" defer></script>
    @stack('js')
</body>
</html>
