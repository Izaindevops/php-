
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   @notifyCss
<x-panel.head/>
 @livewireStyles

   <style type="text/css">#laravel-notify{
z-index: +999999 !important;
}</style>
<body>

  <!-- Layout wrapper -->
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->
        <x-panel.aside/>

      <!-- / Menu -->

      <!-- Layout container -->
      <div class="layout-page">
        <!-- Navbar -->

       <x-panel.header/>


        <!-- / Navbar -->

        <!-- Content wrapper -->
        <div class="content-wrapper">
            @yield('content')
             <x-notify::notify />
        </div>
      </div>
    </div>
  </div>
 
@livewireScripts
 @notifyJs

</body>
</html>
<script type="text/javascript" src="{{url("assets/js/sweetalert.min.js")}}"></script>
<script type="text/javascript" src="{{url("assets/js/dialogue.js")}}"></script>
@stack('js')
<script>
   $(document).ready(function() {
    $(".btn-lm").on("submit", function() {
      let disabledBtn= $(this);
      disabledBtn.prop("disabled", true);
      disabledBtn.html(`Wait...`);
      setTimeout(function() {
        disabledBtn.html(`<i class='bx bx-loader-alt'></i>`);

      }, 2000); 
    });
    $(".form-bs-inline").submit(function(e) {
    
      let submitButton = $(this).find('button[type="submit"]');
      submitButton.prop("disabled", true);
      submitButton.html(`Wait...`);
      $(this).submit();

      setTimeout(function() {
       
        submitButton.html(`<i class='bx bx-loader-alt'></i>`);
      }, 2000); 
    });
  });



 
</script>
