    <!-- header style two -->
    <div id="side-bar" class="side-bar header-two">
        <button class="close-icon-menu"><i class="far fa-times"></i></button>

        <!-- mobile menu area start -->
        <div class="mobile-menu-main">
            <nav class="nav-main mainmenu-nav mt--30">
                <ul class="mainmenu metismenu" id="mobile-menu-active">
                    <li class="has-droupdown parent">
                        <a href="#" class="main">Home</a>
                        <ul class="submenu mm-collapse">
                            <li><a class="mobile-menu-link" href="index.html">Home One</a></li>
                            <li><a class="mobile-menu-link" href="index-two.html">Home Two</a></li>
                            <li><a class="mobile-menu-link" href="index-three.html">Home Three</a></li>
                            <li><a class="mobile-menu-link" href="index-four.html">Home Four</a></li>
                            <li><a class="mobile-menu-link" href="index-five.html">Home Five</a></li>
                        </ul>
                    </li>
                    <li class="has-droupdown parent">
                        <a href="#" class="main">Pages</a>
                        <ul class="submenu mm-collapse">
                            <li><a class="mobile-menu-link" href="about.html">About Us</a></li>
                            <li><a class="mobile-menu-link" href="blog.html">Blog</a></li>
                            <li><a class="mobile-menu-link" href="blog-details.html">Blog Details</a></li>
                            <li><a class="mobile-menu-link" href="contact.html">Contact</a></li>
                            <li><a class="mobile-menu-link" href="use-case.html">Use Case</a></li>
                            <li><a class="mobile-menu-link" href="use-case-2.html">Use Case 2</a></li>
                            <li><a class="mobile-menu-link" href="case-details.html">Use Case Details</a></li>
                            <li><a class="mobile-menu-link" href="case-details-2.html">Use Case Details</a></li>
                            <li><a class="mobile-menu-link" href="pricing.html">Pricing</a></li>
                            <li><a class="mobile-menu-link" href="pricing-two.html">Pricing Two</a></li>
                            <li><a class="mobile-menu-link" href="pricing-three.html">Pricing Three</a></li>
                            <li><a class="mobile-menu-link" href="faq.html">FAQ</a></li>
                            <li><a class="mobile-menu-link" href="log-in.html">Log In</a></li>
                            <li><a class="mobile-menu-link" href="registration.html">Registration</a></li>
                            <li><a class="mobile-menu-link" href="reset.html">Reset</a></li>
                            <li><a class="mobile-menu-link" href="404.html">Not Found</a></li>
                            <!-- <li class="has-droupdown third-lvl">
                                <a class="main" href="#">Project Details</a>
                                <ul class="submenu-third-lvl mm-collapse">
                                    <li><a href="project-details.html"></a>Project Details</li>
                                    <li><a href="project-details-gallery.html"></a>Project Details Gallery</li>
                                    <li><a href="project-details-vedio.html"></a>Project Details Vedio</li>
                                    <li><a href="project-details-carousel.html"></a>Project Details carousel</li>
                                </ul>
                            </li> -->
                        </ul>
                    </li>
                    <li class="parent">
                        <a href="feature.html" class="main">Feature</a>
                    </li>
                    <li class="parent">
                        <a href="contact.html" class="main">Contact</a>
                    </li>
                </ul>
            </nav>

            <div class="rts-social-style-one pl--20 mt--100">
                <ul>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-youtube"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- mobile menu area end -->
    </div>
    <!-- header style two End -->

     <!-- rts backto top start -->
    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
        </svg>
    </div>
    <!-- rts backto top end -->