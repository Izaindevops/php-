<div class="card">
    <div class="card-header">
        <h3>Follow these Steps</h3>
    </div>
    <div class="card-body">
        <h4>1. Place it in your head of your website</h4>
        <code style="background: #F5F5F9;padding: 5px 8px;">
            &lt;link rel="stylesheet"
            href="https://cdn.jsdelivr.net/gh/ShehrozShabbir/ihsancrm/ihsancrmV2.1.css"&gt;
        </code>

        <h4 class="mt-2">2. Place it in your bottom of your website</h4>
        <code style="background: #F5F5F9;padding: 5px 8px;">
            &lt;script
            src="https://cdn.jsdelivr.net/gh/ShehrozShabbir/ihsancrm/ihsancrmV2.1.js">&lt;/script&gt;
            <br>
            <br>
            &lt;script&gt;<br>
            const ihsanCRM_init = ihsanCRM('ihsanCRMWebAi', {<br>
            name: '{{ $botdata != null ? $botdata->bot_name : '' }}',<br>
            token: '{{ $botdata != null ? $botdata->rid : '' }}'<br>
            });<br>
            &lt;/script&gt;
        </code>
        <h6 class="text-danger mt-3"><b class="text-dark">Note : </b> Token is private
            key to access web ai don't share it at public</h6>
    </div>
</div>