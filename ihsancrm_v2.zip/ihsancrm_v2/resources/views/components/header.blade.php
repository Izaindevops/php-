<!-- rts header area start
  #1255a3
  #81007f header--sticky-->
<header class="header-one ">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="header-main-wrapper">
                    <a href="/" class="logo">
                        <img src="{{url('other/images/logo/logo_ai.png')}}" style="width: 200px;" class="img-fluid" alt="">
                    </a>
                    <!-- nav -->
                    <div class="nav-area-main d-xl-block d-lg-block d-md-none d-sm-none d-none">
                        <nav>
                            <ul>
                                <li><a class="links-main" href="{{route('home')}}">Home</a></li>
                                <li><a class="links-main" href="{{route('prices')}}">Prices</a></li>
                                <li><a class="links-main" href="{{route('contact')}}">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                    <!-- nav end -->
                    <div class="buttzon-area">
                        @auth
                        @if (auth()->user()->role=="admin")
                        <a href="{{route('admin.to.dashboard')}}" class="rts-btn btn-primary d-none d-md-inline">Dashboard</a>
                        @else
                        <a href="{{route('dashboard')}}" class="rts-btn btn-primary d-none d-md-inline">Dashboard</a>
                        @endif
                        @else
                        <a href="{{route('login')}}" class="rts-btn btn-primary mr--30 d-none d-md-inline">Sign in</a>
                        <a href="{{route('register')}}" class="rts-btn btn-primary-2 d-none d-md-inline">Get Started</a>
                        @endauth
                    </div>
                    <div class="menu-btn d-xl-none d-lg-none d-md-block d-sm-block" id="menu-btn">
                        <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect y="14" width="20" height="2" fill="#1F1F25"></rect>
                            <rect y="7" width="20" height="2" fill="#1F1F25"></rect>
                            <rect width="20" height="2" fill="#1F1F25"></rect>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- rts header area end -->
