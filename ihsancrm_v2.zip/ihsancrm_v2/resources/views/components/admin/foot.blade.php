 <script src="{{url('assets/vendor/libs/jquery/jquery.js')}}"></script>
  <script src="{{url('assets/vendor/libs/popper/popper.js')}}"></script>
  <script src="{{url('assets/vendor/js/bootstrap.js')}}"></script>
  <script src="{{url('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')}}"></script>

  <script src="{{url('assets/vendor/js/menu.js')}}"></script>
  <!-- Owl-Carousel -->
  <script src="{{url('assets/js/owl.carousel.min.js')}}"></script>

  <!-- Vendors JS -->
  <script src="{{url('assets/vendor/libs/apex-charts/apexcharts.js')}}"></script>

  <!-- Main JS -->
  <script src="{{url('assets/js/main.js')}}"></script>

  <!-- Page JS -->
  <script src="{{url('assets/js/dashboards-analytics.js')}}"></script>
  
     <!-- file-upload -->
    <script src="{{url('assets/js/file-upload/jquery.ui.widget.js')}}"></script>
    <script src="{{url('assets/js/file-upload/jquery.fileupload.js')}}"></script>
    <script src="{{url('assets/js/file-upload/jquery.iframe-transport.js')}}"></script>


    <script src="{{url('assets/js/file-upload/jquery.fancy-fileupload.js')}}"></script>
   <script src="{{url('assets/js/app-chat.js')}}"></script>
    <!-- perfect-scrollbar.js-->
    <script src="{{url('assets/js/perfect-scrollbar.js')}}"></script>
   <script src="{{url('assets/js/ui-toasts.js')}}"></script>

    <!-- custom JS -->
 