@extends('layouts.panel')
@section('title',"Dashboards | IHSAN AI")
@section('content')
  
@php
 $today_customer=DB::table('users')->where('created_at',date('Y-m-d'))->count();
 $today_bots=DB::table('bots')->where('user_id',Auth::user()->id)->count();
 $bot_tarined=DB::table('bots')->where('user_id',Auth::user()->id)->whereNot('source_file',NULL)->count();

@endphp

          <!-- news -->
          <section class="news">
            <div class="container-xxl flex-grow-1 container-p-y">
                
  <div class="row">
  <div class="col-sm-3">
      <div class="card card-border-shadow-secondry h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1 dashboard-cards">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-secondry "><i class='bx bx-bot'></i></span>
          </div>
          <h2 class="ms-1 mb-0">{{$today_bots}}</h2>
        </div>
        <p class="mb-1">Total Bots</p>
        
      </div>
    </div>
    
  </div>
  <div class="col-sm-3">
      <div class="card card-border-shadow-danger h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1 dashboard-cards">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-danger "><i class='bx bx-bot'></i></span>
          </div>
          <h2 class="ms-1 mb-0">{{$bot_tarined}}</h2>
        </div>
        <p class="mb-1">Trained Bots</p>
        
      </div>
    </div>
    
  </div>

  </div>
  <div class="row mt-2">
    <div class="col-md-6 col-lg-6 mb-4">
                  <div class="card h-100">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h5 class="card-title m-0 me-2">Recent Transactions</h5>
                      <div class="dropdown">
                        <button class="btn p-0" type="button" id="transactionID" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="bx bx-dots-vertical-rounded"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="transactionID">
                          <a class="dropdown-item" href="javascript:void(0);">View All</a>
                        </div>
                      </div>
                    </div>
                    <div class="card-body">
                      <ul class="p-0 m-0">
                        @php 
                  
                        $payments=DB::table('payments')->where('user_id',Auth::user()->id)->get();
                          foreach($payments as $payment):
                        @endphp
                        <li class="d-flex mb-4 pb-1">
                          <div class="avatar flex-shrink-0 me-3">
                            @if($payment->payment_method=="stripe")
                            <i class='bx bxl-stripe h3' ></i>
                            @elseif($payment->payment_method=="paypal")
                             <i class='bx bxl-paypal h3' ></i>
                             @else
                             
                             @endif
                          </div>
                          <div class="d-flex w-100 flex-wrap align-items-center justify-content-between gap-2">
                            <div class="me-2">
                              <small class="text-muted d-block mb-1">{{ucwords($payment->plan)}} Plan</small>
                              <h6 class="mb-0">{{ucwords($payment->payment_method)}}</h6>
                            </div>
                            <div class="user-progress d-flex align-items-center gap-1">
                              <h6 class="mb-0">{{ucwords($payment->amount)}}</h6>
                              <span class="text-muted">USD</span>
                            </div>
                          </div>
                        </li>
                        @php endforeach;  @endphp
                       
                      </ul>
                    </div>
                  </div>
                </div>
  </div>

            </div>
          </section>
          
        
<x-panel.foot/>
<script src="assets/js/custom.js"></script>


          @endsection