@extends('layouts.panel')
@section('title','Bot List | Ihsan AI')
@section('content')
<style type="text/css">
  .list-group-item {
     margin-top: 10px;
   }
   .card-img-top{
    max-height: 100px;
     max-width: 100px;
     margin: 0px auto;
     border-radius:2px;
    
   }
   .card i{
        font-size:12px;
        text-align:center;
   }
   .card .messages{
    padding-bottom: 10px;
   }
   .card .messages a{
    color: #21599C;
    font-size: 14px;
    font-weight: bold
   }
   .list-group-item {
    border: none;
    margin-top: 4px;
    padding: 0px;
   }

   
</style>
       <section class="news">
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-6">
                  <h4>Instagram Ai </h4>
                </div>
                <div class="col-6">
                  <button type="button" class="btn btn-primary float-right " data-bs-toggle="modal" data-bs-target="#smallModal">Link With Bot</button>
                </div>
                
                <div class="row">
                  @php
                    $query=DB::table('bots')->where('user_id',Auth::user()->id)->where('is_insta_linked',1);
                    $queryGet=$query->get();
                    
                    $queryCount=$query->count();
                    if ($queryCount>0){
                  @endphp
                  @foreach ($queryGet as $value)
                <div class="col-sm-3 mb-3">
                  <div class="card p-2 h-100">
                    <img  class="card-img-top"  src="{{$value->bot_logo}}" alt="">

                    <div class="card-body">
                      <h5 class="card-title text-center">{{$value->bot_name}}</h5>
                      <p class="card-text text-center">{{$value->insta_account_name}}</p>
                      <div class="messages">
                      </div>
                     <div class="text-right">
                        <a href="{{route('insta.session.stop',['key'=>$value->rid])}}" title="Logout" class="btn btn-sm btn-dark"><i class='bx bx-log-out'></i></a>

                  
                        <a href="{{route('insta.session.check',['key'=>$value->rid])}}" title="Check Session" class="btn btn-sm btn-secondary"><i class='bx bx-show'></i></a>  
                        <a href="{{route('insta.session.chat',['key'=>$value->rid])}}" title="View Chat" class="btn btn-sm btn-primary"><i class='bx bx-chat'></i></a>    
                    </div>
                    </div>
                  </div>
                </div>
                @endforeach
               @php
                   }else { @endphp
                    <div class="col-sm-12 ">
                      <h5 class="text-dark text-center">You dont Linked any bot Yet  </h5>
                      </div>
                    @php  
                   }
               @endphp
              </div>
            </div>
            <div class="modal fade" id="smallModal" tabindex="-1" style="display: none;" aria-hidden="true">
          <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
              <form  id="linkinta_form"  method="POST">
                @csrf
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel2">Fill Fields to Link Your Bot </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="row">
                  <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Insta Username</label>
                    <input type="text" name="email"  class="form-control" placeholder="Enter Name">
                  </div>
                </div>
                 <div class="row">
                  <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Insta Password</label>
                    <input type="text" name="password" class="form-control" placeholder="Enter Name">
                  </div>
                </div>
                <div class="row">
                  <div class="col mb-3">
                    <label for="nameSmall" class="form-label w-100">Asset ID  <i  class="fa fa-info text-primary float-right h5" data-bs-toggle="tooltip" data-bs-offset="0,4" data-bs-placement="bottom" data-bs-html="true" title="" data-bs-original-title="<span>Login as facebook page ,then go to bussiness.facebook.com through page then copy asset id from URL </span>"></i>  </label>
                    <input type="text" name="page_url" class="form-control" placeholder="Enter Page's Asset ID">
                  </div>
       
                </div>
                <div class="row">
                  <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Bot</label>
                    <select class="form-control" required name="bot">
                         @php
                                $getBots=userBots();
                            @endphp
                            @foreach ($getBots as $bot)
                            <option value="{{$bot->rid}}">{{$bot->bot_name}}</option>
                            @endforeach
                    </select>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" id="link_btn_bot" class="btn btn-primary btn-lm">Link with Bot</button>
              </div>
            
              </form>
            </div>
          </div>
        </div>

          </section>

          <!-- Button trigger modal -->


 
<x-panel.foot />
@endsection
@push('js')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    const Toastr = Swal.mixin({
  toast: true,
  position: "center",
  showConfirmButton: false,
  timer: 2000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.onmouseenter = Swal.stopTimer;
    toast.onmouseleave = Swal.resumeTimer;
  }
});


    $("#linkinta_form").on('submit',function(e) {
        e.preventDefault();
        e.stopPropagation();

        var form = $('#linkinta_form');
        $.ajax({
            type: 'POST',
            url: "{{route('insta.session.config')}}",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            dataType:'json',
            beforeSend:function() {
                $('#link_btn_bot').prop("disabled",true);
                $('#link_btn_bot').text("Linking...");
            },
            success:function (response) {
                if(response.status=="success"){
                
                  showInterVal();
                  checkStatus(response.email,'auto');
                }else{
                  Toastr.fire({
                    icon: response.status,
                    title: response.message
                  });
                }
                $('#smallModal').modal('hide');
               
               // $("#id_cart_table").load(location.href + " #id_cart_table > *");
                $('button[type="submit"]').prop("disabled",false);
                $('button[type="submit"]').text("Link with Bot");

            }
        });//ajax call
    });//main

function showInterVal(){
  let timerInterval;
  Swal.fire({
  title: "Please Wait We are Linking...!",
 
  timer: 10000,
  timerProgressBar: true,
  didOpen: () => {
    Swal.showLoading();
  
  },
  willClose: () => {
    clearInterval(timerInterval);
  }
}).then((result) => {
  /* Read more about handling dismissals below */
  if (result.dismiss === Swal.DismissReason.timer) {
    showInterVal();
  }
});
}

function checkStatus(email,type) {
      $.ajax({
            url: "{{route('insta.session.status')}}",
            method: "post",
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
            dataType: "json",

            data: {email:email},
            beforeSend: function (request) {
                return request.setRequestHeader(
                    "X-CSRF-Token",
                    $("meta[name='csrf-token']").attr("content")
                );
            },
            success: function (response) {
              if(type!=='auto'){
                Swal.fire({
                title: "What Bot Says...",
                text: response.message,
                icon:'info',});
                if(response.status=="error" || response.status=='ERROR_OCCURRED'){
                  setTimeout(() => {
                  location.reload();
                  }, 1500);
                }
              }else{

              
              Swal.hideLoading();
              if(response.status=="WORKING"){
                Swal.hideLoading();
                Swal.fire({
                    title: "Great",
                    text: "Your Account Has been Linked with Ai",
                    icon:'info',

                  });
               
                setTimeout(() => {
                  location.reload();
                  }, 1500);
           
                }else if(response.status=="STARTING" || response.status=="LOGIN_SUCCESS"){
                  showInterVal();
                  setTimeout(() => {
                    checkStatus(email,'auto');
                  }, 3000);

                }else if(response.status=="2FA_REQUIRED"){
                  show2FA(email);
            

                }else if(response.status=="AUTH_REQUIRED"){
                  Swal.fire({
                    title: "Don't Close Current Tab",
                    text: response.message,
                    icon:'info',

                  });
                  setTimeout(() => {
                    checkStatus(email,'auto');
                  }, 3000);

                }else{
                  
                  Swal.fire({
                title: "What Bot Says...",
                text: response.message,
                icon:'info',

              });
                  
                }
              }
            },
        });
}
function show2FA(email) {
    Swal.fire({
  title: "Please Enter Code...",
  input: "text",
  inputAttributes: {
    autocapitalize: "off"
  },
  showCancelButton: true,
  confirmButtonText: "Submit",
  showLoaderOnConfirm: true,
  preConfirm: async (login) => {
    $.ajax({
            url: "{{route('insta.session.twoFactor')}}",
            method: "post",
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
            dataType: "json",

            data: {email:email,code:login},
            beforeSend: function (request) {
                return request.setRequestHeader(
                    "X-CSRF-Token",
                    $("meta[name='csrf-token']").attr("content")
                );
            },
            success: function (response) {
              if(response.status=="NOT_FOUND"){
                    Swal.fire({
                    title: "Please Start Session again",
                    text: response.message,
                    icon:'info',

                  });
              }else if(response.status=="SUCCESS"){
                    Swal.fire({
                    title: "Great",
                    text: response.message,
                    icon:'success',

                  });
              
                  setTimeout(function(){
                    window.location.reload();
                  },1000);
              }else if(response.status=="WRONG_CODE"){
                Swal.showValidationMessage(response.message);
              }else{
                Swal.fire({
                    title: "Oops",
                    text: response.message,
                    icon:'error',

                  });

              }
              
            },
        });
  },
  allowOutsideClick: () => !Swal.isLoading()
});
}
  </script> 
  @endpush



