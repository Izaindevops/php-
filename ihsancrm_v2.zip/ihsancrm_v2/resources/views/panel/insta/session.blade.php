@extends('layouts.panel')
@section('title','InstaAi| Ihsan AI')
@section('content')


@livewire('instascreenshot',['brid'=>$brid])
@endsection