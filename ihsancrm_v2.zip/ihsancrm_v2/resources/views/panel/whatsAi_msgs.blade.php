@extends('layouts.panel')
@section('content')
<section class="news">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <div class="card-header h4">{{ucwords($type)}} Messages List</div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <td>Sr No.</td>
                            <td>Bot</td>
                            <td>From </td>
                            <td>Message</td>
                          
                        </tr>
                    </thead>
                    <tbody>
                    @php
                    $query=DB::table('bots')->where('uid',$uid);
                    if ($query->count()>0) {
                        $messages=$query->get();
                    
                    if ($type=='sent') {
                        $queryData=DB::table('whatai_chats')->where('msg_status',1)->where('bot_rid',$messages[0]->rid)->get();
                    }elseif ($type=='received') {
                        $queryData=DB::table('whatai_chats')->where('msg_status',2)->where('bot_rid',$messages[0]->rid)->get();
                    }elseif ($type=='unsent') {
                        $queryData=DB::table('whatai_chats')->where('msg_status',0)->where('bot_rid',$messages[0]->rid)->get();
                    }else {
                        $queryData=DB::table('whatai_chats')->where('bot_rid',$messages[0]->rid)->get();
                    }
                    $c=0;
                    foreach ($queryData as $key => $value):
                    $c++;  
                  
                    @endphp
                        <tr>
                            <td>{{$c}}</td>
                            <td>{{$messages[0]->bot_name}}</td>
                            <td>{{$value->client_number}} </td>
                            <td>{{$value->message}}</td>
                        </tr>
                        
                    @php
                    endforeach;
                }
                    @endphp
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection