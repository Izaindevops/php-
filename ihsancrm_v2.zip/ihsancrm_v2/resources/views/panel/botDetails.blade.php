@extends('layouts.panel')
@section('title', 'Customize | IHSAN AI')
@section('content')
    <style type="text/css">
        .chat-history-footer {
            margin-top: 4px;
            background-color: #fff;
            box-shadow: 0 0.125rem 0.25rem rgba(161, 172, 184, .4);
        }

        .chat-message-right p {
            color: white;
        }
    </style>
    <!-- ihsanbot customiz -->
    @php
        if ($runData) {
            $senData = $runData;
        } else {
            $senData = null;
        }
    @endphp
    <section class="container botsonic">
        <div class="row">
            <div class="col-sm-11 mx-auto">
                <ul class="nav nav-tabs mx-auto" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#customize_bot"
                            type="button" role="tab" aria-controls="profile" aria-selected="false">Customize</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="home-tab" data-bs-toggle="tab" data-bs-target="#source_bot"
                            type="button" role="tab" aria-controls="home" aria-selected="true">Source</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact"
                            type="button" role="tab" aria-controls="contact" aria-selected="false">Starter
                            Question</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="inbox-tab" data-bs-toggle="tab" data-bs-target="#inbox" type="button"
                            role="tab" aria-controls="contact" aria-selected="false">Inbox</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="embedding-tab" data-bs-toggle="tab" data-bs-target="#embedding"
                            type="button" role="tab" aria-controls="contact" aria-selected="false">Embedding</button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="customize_bot" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="row">
                            <div class="col-sm-6">
                                <form action="{{ route('bot.customize') }}" method="POST" id="customize_bot_fm"
                                    enctype="multipart/form-data" class="form-bs-inline">
                                    @csrf
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row form-group mt-1">
                                                <label>Company Name</label>
                                                <input class="form-control" placeholder="Enter Your Company Name"
                                                    name="company_name"
                                                    value="{{ $senData != null ? $runData[0]->company_name : '' }}"
                                                    type="text">
                                                @error('company_name')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <input type="hidden" name="customString" value="{{ $senData != null ? $runData[0]->uid : '' }}">
                                            <div class="row form-group mt-1">
                                                <label>Bot Name</label>
                                                <input class="form-control" placeholder="Enter Bot Name" name="bot_name"
                                                    value="{{ $senData != null ? $runData[0]->bot_name : '' }}" type="text">
                                                @error('bot_name')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="row form-group mt-2">
                                                <div class="col-sm-10">
                                                    <div class="mb-3">
                                                        <label for="formFile" class="form-label">Company Logo</label>
                                                        <input class="form-control " name="company_logo" type="file"
                                                            id="companyLogoInput" accept="image/jpg,image/jpeg,.jpg,.jpeg">
                                                        @error('company_logo')
                                                            <span class="text-danger">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <img class="bot-logo mt-4"
                                                        src="{{ url($senData != null ? $runData[0]->company_logo : 'assets/img/preview.png') }}"
                                                        id="companyLogo">
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col-sm-10">
                                                    <div class="mb-3">
                                                        <label for="formFile" class="form-label">Bot Logo</label>
                                                        <input class="form-control" name="bot_logo" type="file"
                                                            id="botLogoInput" accept="image/jpg,image/jpeg,.jpg,.jpeg">
                                                        @error('bot_logo')
                                                            <span class="text-danger">{{ $message }}</span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-sm-2">
                                                    <img class="bot-logo mt-4"
                                                        src="{{ url($senData != null ? $runData[0]->company_logo : 'assets/img/preview.png') }}"
                                                        id="botLogo">
                                                </div>
                                            </div>

                                            <input class="form-control" name="bot_color" value="#fff" type="hidden">


                                            <div class="row form-group mt-1">
                                                <label>Welcome Message</label>
                                                <textarea class="form-control" name="welcome_message" value="" type="text">{{ $senData != null ? $runData[0]->welcome_message : 'Hey there, how can I help you?' }}</textarea>
                                                @error('welcome_message')
                                                    <span class="text-danger">{{ $message }}</span>
                                                @enderror
                                            </div>
                                            <div class="row mt-2">
                                                @if ($uid != null)
                                                    <button class=" btn btn-primary w-25 float-right btn-lm"
                                                        type="submit">Update</button>
                                                @else
                                                    <button class="btn btn-primary w-25 float-right btn-lm"
                                                        type="submit">Create</button>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-sm-6">
                                @if ($uid)
                                    @if ($runData[0]->source_file!=null)
                                    @livewire('chat', ['uid' => $uid, 'welComeMessage' => $senData != null ? $runData[0]->welcome_message : 'Hey there, how can I help you?'])
                                @endif
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade " id="source_bot" role="tabpanel" aria-labelledby="home-tab">
                        @livewire('source', ['uid' => $uid])
                    </div>
                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                        <div class="row">
                            <div class="col-sm-6">
                                @if ($uid)
                                    <h4>Starter Questions</h4>
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row form-group mt-1">
                                                <label>Starter Questions</label>
                                                <textarea class="form-control" name="" value="" type="text">Hey there, how can I help you?</textarea>
                                            </div>
                                            <div class="row mt-2">
                                                <button class="btn btn-primary w-25 float-right"
                                                    type="submit">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="embedding" role="tabpanel" aria-labelledby="embedding-tab">
                        <div class="row">
                            @if ($uid)
                                <div class="col-sm-11 mx-auto">
                                    <h4>Embeddings </h4>
                                    <x-embeddings :uid="$uid" />
                                </div>
                            @endif
                        </div>
                    </div>
                    <div class="tab-pane fade" id="inbox" role="tabpanel" aria-labelledby="inbox-tab">
                        @if ($uid)
                            @livewire('chatbot-lists', ['uid' => $uid])
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>
    <x-panel.foot />
    <script src="{{ url('assets/js/custom.js') }}"></script>
    <script>
        // file-upload JS
        $(document).ready(function() {
            $("#sendDummyFile").FancyFileUpload({
                url: "panel/file/upload",
                params: {
                    action: "fileuploader",
                    "_token": "{{ csrf_token() }}",
                    "id": "{{ $uid }}",

                },
                maxfilesize: -1,
                'accept': ['pdf'],

                'retries': 1,
                'edit': false,
                'uploadcompleted': function(e, data) {

                    $('#appendDataFiles').append('<tr><td><p style="word-wrap: break-word;">' + data
                        .files[0].name + '</p></td></tr>');

                    location.reload();

                },

            });

            function readURL(input, id) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#' + id).attr('src', e.target.result);
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#companyLogoInput").change(function() {
                readURL(this, "companyLogo");
            });
            $("#botLogoInput").change(function() {
                readURL(this, "botLogo");
            });
            $('#customize_bot_fm2').on('submit', function(e) {
                e.preventDefault();
                e.stopPropagation();
                let form = $('#customize_bot_fm2');
                $.ajax({
                    type: $(this).attr('method'),
                    url: $(this).attr('action'),
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: "json",
                    beforeSend: function() {
                        $('button[type="submit"]').prop("disabled", true);
                    },
                    success: function(response) {
                        $('button[type="submit"]').prop("disabled", false);
                        if (response.sts == 'success') {
                            SendMessage('primary', 'Great', response.msg);
                            // $('table').load(location.href+' table');
                            $('#customize_bot_fm').trigger("reset");
                        } else {
                            SendMessage('danger', 'Great', response.msg);
                        }



                    }
                }); //ajax call
            });
        });
        $('#sendMessageToWeb').on('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
            let message = $("#message").val().trim();
            if (message !== "") {
                let customeAva = $(".customeAva").attr('src');

                displayMessage(message, customeAva);

            }

            let form = $('#sendMessageToWeb');
            $.ajax({
                type: $(this).attr('method'),
                url: $(this).attr('action'),
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                beforeSend: function() {
                    $('#sendMessageToWeb button[type="submit"]').prop("disabled", true);
                },
                success: function(response) {
                    let botAvatar = $(".botAvatar").attr('src');
                    displayPromt(response.message, botAvatar)
                    $('#sendMessageToWeb button[type="submit"]').prop("disabled", false);
                    $("#message").val("");
                    if (response.status == 200) {
                        $('table').load(location.href + ' table');
                        $('#sendMessageToWeb').trigger("reset");
                    } else {}



                }
            }); //ajax call
        });
    </script>
@endsection
