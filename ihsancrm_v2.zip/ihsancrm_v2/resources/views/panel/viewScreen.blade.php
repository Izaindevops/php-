@extends('layouts.panel')
@section('title','WhatupAi| Ihsan AI')
@section('content')


@livewire('whatscreenshot',['brid'=>$brid])
@endsection