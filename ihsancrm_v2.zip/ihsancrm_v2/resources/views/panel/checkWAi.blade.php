@extends('layouts.panel')
@section('title','WhatsappAi | Ihsan AI')
@section('content')
<section class="news">
    <div class="container-xxl flex-grow-1 container-p-y">
        @if ($screenshot!=null)
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-12">
                        <form action="{{route('refreshSession')}}" method="POST">
                            @csrf
                            <button class="btn btn-primary" type="submit">Refresh </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <img src="data:image/jpeg;base64,{{ $screenshot }}" alt="Image">
            </div>
        </div>
        @else
      
        <div class="card">
            <div class="card-header"></div>
            <div class="card-body">
                @if (cBots()>0)
                    
                
               <form action="{{route('startSession')}}" class="form-bs-inline " method="POST">
                @csrf
                <div class="row">
                    <div class="col-sm-5">
                        <label>Enter Whatsapp Mobile Number</label>
                        <input type="text" class="form-control" name="phone">

                    </div>
                    <div class="col-sm-5">
                        <label>Select Bot</label>
                        <select class="form-control" name="bot">
                            @php
                                $getBots=userBots();
                            @endphp
                            @foreach ($getBots as $bot)
                            <option value="{{$bot->rid}}">{{$bot->bot_name}}</option>
                            @endforeach
                           
                        </select>
                        
                    </div>
                    <div class="col-sm-10">
                        
                        <label> <span>Note:After Configure  Scan the QR Code through your WhatsApp App. </span></label><br>
                        <button type="submit" class="btn btn-primary" style="float: right">Config</button><br>
                       
                    </div>
                </div>
               </form>
               @else
               <div class="col-sm-12 ">
                <h5 class="text-dark text-center">You don't Created any bot Yet <a href='{{route('ihsanbot')}}'>Click here to create</a> </h5>
                </div>
               @endif
            </div>
        </div>
        @endif
       
    </div>
</section>

<x-panel.foot />
@endsection