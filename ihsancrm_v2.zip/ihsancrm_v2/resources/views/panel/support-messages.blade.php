@extends('layouts.panel')
@section('content')
<style>
    . float-right {
        float: right !important;
    }
</style>
<link rel="stylesheet" href="{{url('vendor/richtext/richtext.min.css')}}">
<div class="container mt-2">
    @if ($key!=null)
    @section('title','Message | Ihsan Ai')
    @php
    $support= DB::table('supports')->where('support_token',$key);
    if ($support->count()>0):
    $getSupport=$support->get();

    @endphp

    <div class="card mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col-sm-10">
                    <h4 class="float-left" style="float: left">{{$getSupport[0]->support_title}}</h4>
                </div>
                <div class="col-sm-2">


                    <i class='bx bx-plus-medical' data-bs-toggle="collapse" data-bs-target="#collapseExample"
                        aria-expanded="true" aria-controls="collapseExample"></i>

                </div>
                <hr>
            </div>
            <div class="collapse show" id="collapseExample">
                <div class="card-body">
                    <table class="table">
                        <tr>
                            <th>By</th>
                            <td>{{getUser($getSupport[0]->user_id)[0]->name}}</td>
                            <th>Issue Created at</th>
                            <td>{{getTimeFormat('h:m:s d-m-Y',$getSupport[0]->created_at)}}</td>
                        </tr>
                        <tr>
                            <td colspan="2">{!!$getSupport[0]->support_message!!}</td>
                        </tr>
                        <td>Attachment</td>
                        <td> <a href="{{$getSupport[0]->support_attachment}}" target="_blank"
                                rel="noopener noreferrer">{{$getSupport[0]->support_attachment}}</a> </td>
                        </tr>
                    </table>
                </div>
            </div>

        </div>
    </div>
    @if ($getSupport[0]->support_status==1)

    @php
     $support= DB::table('support_messages')->where('support_id',$getSupport[0]->id);
     DB::table('supports')->where('support_token',$key)->update(['user_readed'=>1]);
    if ($support->count()>0):
    $getMessages=$support->get();
    @endphp
        
 
    <div class="card mb-2   ">
        <div class="card-header bg-dark text-white h5 text-center">
            Recent Messages 
        </div>
        <div class="card-body">
            <ul class="list-group">
                @foreach ($getMessages as $message)
                @if ($message->by_support==1)
                 <a href="#" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                      <h5 class="mb-1 border-bottom">IHSAN AI Support</h5>
                      <small>{{getTimeFormat('h:m:s d-m-Y',$message->created_at)}}</small>
                    </div>
                    <p class="mb-1">{!!$message->support_message!!}</small>
                  </a>
                  @else
                  <a href="#" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                      <h5 class="mb-1 border-bottom">{{Auth::user()->name}}</h5>
                      <small>{{getTimeFormat('h:m:s d-m-Y',$message->created_at)}}</small>
                    </div>
                    <p class="mb-1">{!!$message->support_message!!}</small>
                  </a>

                  @endif
                @endforeach
                
              </ul>
        </div>
    </div>
    @php
        endif;
    @endphp
    @endif
        <div class="card" >
            <div class="card-header h4 text-center bg-dark text-white">
                Reply to Support
            </div>
            <div class="card-body">

                <form action="{{route('customer.reply')}}" method="POST">
                    @csrf
                    <input type="hidden" name="support" value="{{$key}}">
                    <div class="col-sm-10 mx-auto mt-2">
                        <label>Relpy a message</label>
                        <textarea class="content" name="message"></textarea>
                        @error('message')
                        <div class="text-danger my-2">{{$message}} </div>
                        @enderror
                    </div>

                    <div class="col-sm-10 mx-auto mt-2">
                        <button class="btn btn-primary " type="submit">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @php
    endif;
    @endphp
    @endif
</div>
<x-admin.foot />
<script src="{{url('vendor/richtext/jquery.richtext.js')}}"></script>
<script>
    $(document).ready(function() {
        $('.content').richText({

// text formatting
bold: true,
italic: true,
underline: true,

// text alignment
leftAlign: true,
centerAlign: true,
rightAlign: true,
justify: true,

// lists
ol: true,
ul: true,

// title
heading: true,

// fonts
fonts: true,
fontList: ["Arial",
  "Arial Black",
  "Comic Sans MS",
  "Courier New",
  "Geneva",
  "Georgia",
  "Helvetica",
  "Impact",
  "Lucida Console",
  "Tahoma",
  "Times New Roman",
  "Verdana"
],
fontColor: true,
backgroundColor: true,
fontSize: true,

// uploads
imageUpload: false,
fileUpload: false,

// media


// link

// tables
table: true,

// code
removeStyles: true,
code: false,

// colors
colors: [],

// dropdowns
fileHTML: '',
imageHTML: '',

// translations
translations: {
  'title': 'Title',
  'white': 'White',
  'black': 'Black',
  'brown': 'Brown',
  'beige': 'Beige',
  'darkBlue': 'Dark Blue',
  'blue': 'Blue',
  'lightBlue': 'Light Blue',
  'darkRed': 'Dark Red',
  'red': 'Red',
  'darkGreen': 'Dark Green',
  'green': 'Green',
  'purple': 'Purple',
  'darkTurquois': 'Dark Turquois',
  'turquois': 'Turquois',
  'darkOrange': 'Dark Orange',
  'orange': 'Orange',
  'yellow': 'Yellow',
  'imageURL': 'Image URL',
  'fileURL': 'File URL',
  'linkText': 'Link text',
  'url': 'URL',
  'size': 'Size',
  'responsive': '',
  'text': 'Text',
  'openIn': 'Open in',
  'sameTab': 'Same tab',
  'newTab': 'New tab',
  'align': 'Align',
  'left': 'Left',
  'justify': 'Justify',
  'center': 'Center',
  'right': 'Right',
  'rows': 'Rows',
  'columns': 'Columns',
  'add': 'Add',
  'pleaseEnterURL': 'Please enter an URL',
  'videoURLnotSupported': 'Video URL not supported',
  'pleaseSelectImage': 'Please select an image',
  'pleaseSelectFile': 'Please select a file',
  'bold': 'Bold',
  'italic': 'Italic',
  'underline': 'Underline',
  'alignLeft': 'Align left',
  'alignCenter': 'Align centered',
  'alignRight': 'Align right',
  'addOrderedList': 'Ordered list',
  'addUnorderedList': 'Unordered list',
  'addHeading': 'Heading/title',
  'addFont': 'Font',
  'addFontColor': 'Font color',
  'addBackgroundColor': 'Background color',
  'addFontSize': 'Font size',
  'addImage': 'Add image',
  'addVideo': 'Add video',
  'addFile': 'Add file',
  'addURL': 'Add URL',
  'addTable': 'Add table',
  'removeStyles': 'Remove styles',
  'code': 'Show HTML code',
  'undo': 'Undo',
  'redo': 'Redo',
  'save': 'Save',
  'close': 'Close'
},

// privacy
youtubeCookies: false,

// preview
preview: false,

// placeholder
placeholder: 'Descripte your issue here',

// dev settings
useSingleQuotes: false,
height: 0,
heightPercentage: 0,
adaptiveHeight: false,
id: "",
class: "",
useParagraph: false,
maxlength: 0,
maxlengthIncludeHTML: false,
callback: undefined,
useTabForNext: false,
save: false,
saveCallback: undefined,
saveOnBlur: 0,
undoRedo: true

});
    });
</script>
@endsection