
@extends('layouts.panel')
@section('title','Web List | Ihsan AI')
@section('content')
<style type="text/css">
  .list-group-item {
     margin-top: 10px;
   }
   .card-img-top{
    max-height: 100px;
     max-width: 100px;
     margin: 0px auto;
     border-radius:10px;

   }
   .card i{
        font-size:120px;
        text-align:center;
   }
   .bxs-check-circle{
    font-size: 20px !important;
    color: green;
    float: right;
   }.bxs-x-circle{
    font-size: 20px !important;
    color: red;
    float: right;
   }
</style>
      <section class="news">
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-12 d-flex justify-content-between">
                  <h4>Your Bots</h4>
                 
                  <!-- Create new -->
                </div>
                <div class="row">
                  @php
                    $query=DB::table('bots')->where('user_id',Auth::user()->id);
                    $queryGet=$query->get();
                    $queryCount=$query->count();
                    if ($queryCount>0){
                  @endphp
                  @foreach ($queryGet as $value)


                    <div class="col-sm-3 mb-3">
                  <div class="card h-100 pt-2">
                    <img  class="card-img-top"  src="{{$value->bot_logo}}" alt="">

                    <div class="card-body">
                      <h5 class="card-title text-center">{{$value->bot_name}}</h5>
                        <span>Web Ai <i class='bx bxs-check-circle'></i></span> <br>
                    
                    
                      <hr>

                      <a href="{{route('webai.embedding',['uid'=>$value->uid])}}" class="btn btn-primary btn-sm float-right">Check Embedding</a>
                    </div>
                  </div>
                </div>
                @endforeach
               @php
                   }else { @endphp
                    <div class="col-sm-12 ">
                      <h5 class="text-dark text-center">You dont Created any bot Yet <a href='{{route('ihsanbot')}}'>Click here to create</a> </h5>
                      </div>
                    @php
                   }
               @endphp
              </div>
            </div>
          </section>

<x-panel.foot />
@endsection



