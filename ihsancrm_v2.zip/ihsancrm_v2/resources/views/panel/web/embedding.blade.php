
@extends('layouts.panel')
@section('title','Web Ai | Ihsan AI')
@section('content')

      <section class="news">
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-12 d-flex justify-content-between">
                  <h4>Web Ai</h4>
                 
                  <!-- Create new -->
                </div>
                <div class="row">
                 <div class="col-sm-12">
                    <x-embeddings :uid="$uid" />
                 </div>
              </div>
            </div>
          </section>

<x-panel.foot />
@endsection



