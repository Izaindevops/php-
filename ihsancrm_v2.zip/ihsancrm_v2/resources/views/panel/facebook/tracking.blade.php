@extends('layouts.panel')
@section('title','Facebook Tracking | Ihsan AI')
@section('content')
<style>
        .chat-box {
            max-height: 400px;
            overflow-y: auto;
            padding: 10px;
        }

        .message {
            padding: 10px;
            border-radius: 10px;
            margin: 5px 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .chat-from {
            background-color: #21599C;
            color:#fff;
            float: left;
            width: 80%;
        }

        .chat-to {
            background-color: #fff;
            float: right;
             color:#000;
             width: 80%;
        }

        .timestamp {
            font-size: 12px;
            color: #777;
            float: right;
        }
    </style>
<div class="container mt-5">
	@if (!$key)
		{{-- expr --}}
	
	<div class="card">
	<div class="card-header h4 text-dark">
		Facebook Tracking 
		
	</div>
	<div class="card-body">
		@php
		// $facechats= DB::table('facechats')->select('bot_id')->distinct()->where('')->get();
		 $facechats = DB::table('facechats')
		    ->select('bots.id as bot_id','bots.bot_name as bot_name','bots.rid as rid','facechats.account_name','facechats.receiver_name')
		    ->distinct()
		    ->join('bots', 'facechats.bot_id', '=', 'bots.id')->where('bots.rid',$botID)->get();
		@endphp
		<table class="table ">
			<thead>
				<tr>
					<td>Sr</td>
					<td> Name</td>
					<td>Other User</td>
					<td>Last Message</td>
					<td></td>
				</tr>
				</thead>
				
			@foreach ($facechats as $key => $element)
				{{-- expr --}}
				@php
					
					$facechats = DB::table('facechats')->where('bot_id',$element->bot_id)->where('receiver_name',$element->receiver_name)->where('account_name',$element->account_name)->where('status',1)->orderBy('created_at','DESC')->get();
				@endphp
			

			
			<tbody>
				<tr>
					<td>{{++$key}}</td>
					<td>{{$element->account_name}}</td>
					<td>{{$element->receiver_name}}</td>
					<td>{{ implode(' ', array_slice(str_word_count($facechats[0]->message, 1), 0, 10)) }}</td>
					<td>
						<a href="/facebook/tracking/{{$element->rid}}/{{$element->receiver_name}}/{{$element->account_name}}"><i class="bx bx-show"></i></a>
					</td>

				</tr>
				
			</tbody>
			@endforeach
			
		</table>
	</div>
</div>
@else
<div class="card">
	<div class="card-header border-bottom h4 text-dark">
		{{$facechats[0]->bot_name}}
		
	</div>
	@php
	//dd($facechats);
					
				@endphp
	<div class="card-body">

                        
                        <div class="chat-box">
                        	
                        	@foreach ($facechats as $key => $element)
                        	@if ($element->is_bot==0)
                        		<div class="message chat-from">
                                <b>@ {{$element->receiver_name}}</b> <br> {{$element->message}}
                                <br>
                                <span class="timestamp text-white">{{$element->created_at}}</span>
                            </div>
                        	@else
                        		<div class="message chat-to">
                                <b>@ {{$element->account_name}} </b> <br> {{$element->message}}
                                <br>
                                <span class="timestamp ">{{$element->created_at}}</span>
                            </div>
                        	@endif


                            
                            @endforeach
                            
                            <!-- Add more messages here -->
                        </div>
                    
                    
	</div>
</div>

@endif
</div>
@endsection