@extends('layouts.panel')
@section('title','Facebook Ai| Ihsan AI')
@section('content')


@livewire('facescreenshot',['brid'=>$brid])
@endsection