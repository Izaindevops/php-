@extends('layouts.panel')
@section('title','SEND SMS | IHSAN AI')
@section('content')
<style>
    .nav-align-top .nav-tabs ~ .tab-content{
        box-shadow: none;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{url('assets/css/tagsinput.css')}}">
<section class="news">
    <div class="container-xxl flex-grow-1 container-p-y">
        @if(session()->has('error'))
        <div class="card">
            <div class="card-body">
                <ul class="">
                    {!!session()->get('error')!!}
                </ul>
            </div>
        </div>
        @endif
       <div class="row">
           <div class="col-sm-6">
                <div class="card">
            <div class="card-header w-100">
                <span class="float-left h4">SMS AI Settings</span>
               <br>
                <hr>
            </div>
            <form action="{{route('sms.send')}}" method="POST" class="form-bs-inline">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-10 mx-auto">
                            <label>To</label>  <p type="button" class="text-primary float-right" data-bs-toggle="modal" data-bs-target="#smallModal">CSV File</p>
                            @if (session()->get('dataArray'))
                                @php
                                    $file = public_path('temp_files/'.$botID.'.txt');
                                 $datafiles=file_get_contents($file);
                                    $counter=count(json_decode($datafiles,true))
                                    
                                @endphp
                           
                            <input type="text" class="form-control" disabled readonly  name="" value="{{$counter}} Numbers are selected">
                            <input type="text" class="form-control"  name="grabNumbers" value="{{$datafiles}}">
                            @php
                               unlink($file);
                            @endphp
                            @else
                            <input type="text"  name="phoneNumbers" data-role="tagsinput" value="">
                            @endif
                         
                            <span class="text-muted">Enter Valid Phone Numbers , Separated them by commas</span>
                        </div>
                    </div>
                 


                    
                  
                    <div class="row">
                        
                        <div class="col-sm-10 mx-auto">
                           
                            <label>Message</label>
                            <textarea id="" name="message" cols="30" rows="10" class="form-control"></textarea>
                            <input type="hidden" value="{{$botID}}" name="botKey">
                            <span class="text-muted">Max Words Length 155 </span>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-sm-10 mx-auto">
                            <button class="btn btn-primary float-right" type="submit">Send</button>
                        </div>
                    </div>
                </div>
            </form>
            @livewire('sms-sheet-modal',['botKey'=>$botID])
        </div>
           </div>
           {{-- end of col --}}
           <div class="col-sm-6">
               
                <div class="card">
            <div class="card-header w-100">
                <span class="float-left h4">Questions Setting</span>
               <br>
                <hr>
            </div>
            <form action="{{route('sms.survay')}}" method="POST" class="form-bs-inline">
                @csrf
                <div class="card-body " >
                    <div class="row ">
                        <div class="col-sm-10 mx-auto">
                            <label>Write Your Question</label>
                            <input type="hidden" value="{{$botID}}" required name="botKey">
                            <input type="hidden" value="{{$key}}" name="botQuestions">

                            <input type="text" name="question[]"  class="form-control">
                            <span class="text-muted"></span>
                        </div>
                        <div class="col-sm-2">
                            <br>
                            <button type="button" class="btn btn-primary btn-sm question_btn" >
                                <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>
                    @if ($key)
                       
                    @foreach ($key as $element)
                        {{-- expr --}}
                
                    <div class="row mt-2">
                        <div class="col-sm-10">
                      
                            <input type="text" name="question[]"  value="{{$element->question}}" placeholder="Write Your Question" class="form-control">
                            <span class="text-muted"></span>
                        </div>
                    
                    </div>
                    @endforeach
                      @endif
                    <div class="mt-2" id="question_div"></div>
                    <div class="row mt-3">
                        <div class="col-sm-10">
                            <label for="">Type Message for end of conservation</label>
                            <textarea name="end_message" id="end_message" class="form-control"  rows="3" placeholder="Type Message for end of conservation">{{$end_message}}</textarea>
                           
                       
                        </div>
                    
                    </div>
                    <div class="row mt-3">
                        <div class="col-sm-10 mx-auto">
                            <button class="btn btn-primary float-right" type="submit">Save</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
           
           </div>
       </div>
    </div>

</section>
<x-panel.foot />
<script type="text/javascript" src="{{url('assets/js/tagsinput.js')}}"></script>
<script>
$(document).ready(function() {
    $('.question_btn').click(function() {

        $('#question_div').append('<div class="col-sm-10 mt-2"><input type="text" name="question[]"  placeholder="Write Your Question" class="form-control"><span class="text-muted"></span></div>');
    });
});

</script>
@endsection
