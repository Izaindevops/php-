@extends('layouts.panel')
@section('title','SMS Lists | Ihsan AI')
@section('content')
<section class="news">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <div class="card-header row">
                <div class="col-sm-6 h4">  
                        SMS Ai Recent Messages
                </div>  
                <div class="col-sm-6">
                    <h5 class="text-dark text-center d-inline">
                        @php
                             $query=DB::table('bots')->where('user_id',Auth::user()->id)->where('is_sms_linked',1)->get();
                        @endphp
                      Key : <b>{{$query[0]->smsAiToken}}</b>

                    </h5> 
                    <a href="" class="float-right" download="">App Link</a>
                </div>  
            </div>
            <div class="card-body">
              @livewire('smslists')
            </div>
        </div>
    </div>
</section>
@endsection
