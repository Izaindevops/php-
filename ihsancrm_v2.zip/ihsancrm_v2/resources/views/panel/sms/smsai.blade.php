@extends('layouts.panel')
@section('title','SMS | Ihsan AI')
@section('content')
<style type="text/css">
  .list-group-item {
     margin-top: 10px;
   }
   .card-img-top{
    max-height: 100px;
     max-width: 100px;
     margin: 0px auto;
     border-radius:2px;
    
   }
   .card i{
        font-size:12px;
        text-align:center;
   }
   .card .messages{
    padding-bottom: 10px;
   }
   .card .messages a{
    color: #21599C;
    font-size: 14px;
    font-weight: bold
   }
   .list-group-item {
    border: none;
    margin-top: 4px;
    padding: 0px;
   }
   .inRow li{
    list-style-type: square;
   }

  .list-group-item {
     margin-top: 10px;
   }
   .card-img-top{
    max-height: 100px;
     max-width: 100px;
     margin: 0px auto;
     border-radius:2px;
    
   } 
   .card i{
        font-size:12px;
        text-align:center;
   }
   .card .messages{
    padding-bottom: 10px;
   }
   .card .messages a{
    color: #21599C;
    font-size: 14px;
    font-weight: bold
   }
   .list-group-item {
    border: none;
    margin-top: 4px;
    padding: 0px;
   }
   .text-left a{
    margin-bottom:5px;
   }



</style>
      <section class="news">
        @php
          $query=DB::table('bots')->where('user_id',Auth::user()->id)->where('is_sms_linked',1);
                    $queryGet=$query->get();
                    
                    $queryCount=$query->count();
        @endphp
                  <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-6">
                  <h4>SMS Ai </h4>
                </div>
                <div class="col-6">
                  @if ($queryCount==0)
                    {{-- expr --}}
                 
                  <button type="button" class="btn btn-primary float-right" data-bs-toggle="modal" data-bs-target="#smallModal">Link With Bot</button>
                   @endif
                  <a href="{{url('apps/ihsan-ai.apk')}}" class="btn btn-secondary float-right mx-2"  download="">Click to Download App</a>
                </div>
                
                <div class="row">
                  @php
                    
                    if ($queryCount>0){
                  @endphp
                  @foreach ($queryGet as $value)
                <div class="col-sm-3 mb-3">
                  <div class="card p-2 h-100">
                    <img  class="card-img-top"  src="{{$value->bot_logo}}" alt="">

                    <div class="card-body">
                      <h5 class="card-title text-center">{{$value->bot_name}}</h5>
                      <p class="card-text text-center">{{$value->what_number}}</p>
                      <div class="messages">
                      </div>
                     <div class="text-left">
                         <a href="{{route('sms.session.send',['key'=>$value->rid])}}" title="Logout" class="btn btn-sm btn-dark">Send SMS<i class='bx bx-log-out'></i></a> <br>
                       
                         @livewire('notification-sweet-alert',['modFor'=>'smsai_unlink','paraValue'=>$value->uid,])
                         
                         <button onclick="showSMSAiKey(`{{$value->smsAiToken}}`)" type="submit" title="Check Session" class="btn btn-sm btn-secondary my-1">SMS Ai Key<i class='bx bx-show'></i></button>  <br>

                  
                          
                        <a href="{{route('sms.session.chat',['key'=>$value->smsAiToken])}}" title="View Chat" class="btn btn-sm btn-primary">Tracking <i class='bx bx-chat'></i></a>    
                    </div>
                    </div>
                  </div>
                </div>
                @endforeach
               @php
                   }else { @endphp
                    <div class="col-sm-12 bg-white p-4 mt-2 ">
                      <h5 class="text-dark text-center">You dont Linked any bot Yet  </h5>
                      </div>
                    @php  
                   }
               @endphp
              </div>
            </div>
             <div class="card mt-2 w-100">
            <div class="card-body">
             <ul class="inRow">
                <h2>Instructions for configuration of SMS AI</h2>
                <li>First of all,we can config from web</li>
                <li>Then one ID will be generated</li>
                <li>You can copy the generated SMS Ai Key and download app and install it</li>
                <li>After installation, put that key in the input field and save it </li>
                <li>Now your app will attach with web portal and bot that you selected in the configuration for SMS AI,</li>
                <h5>Note:</h5>
                <li>Need internet and local SMS package too</li>
                <li>In the Beta-version, APP only works for android platform, IOS is not allowed third party app but we are working on it.</li>
             </ul>
            </div>
          </div>
        <div class="modal fade" id="smallModal" tabindex="-1" style="display: none;" aria-hidden="true">
           <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
               <form action="{{route('sms.config')}}" class="form-bs-inline" method="POST">
                @csrf
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel2">Select Bot</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                 <div class="row"></div>
                <div class="row">
                  <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Bot</label>
                    <select class="form-control" name="bot">
                         @php
                            $getBots=DB::table('bots')->where('user_id',Auth::user()->id)->where('is_sms_linked',0);
                                 
                            @endphp
                            @if ($getBots->count()>0)
                               
                          
                            @foreach ($getBots->get() as $bot)
                            <option value="{{$bot->uid}}">{{$bot->bot_name}}</option>
                            @endforeach


                            @endif
                    </select>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                @if ($getBots->count()>0)
                <button type="submit" class="btn btn-primary">Link with Bot</button>
                 @endif
              </div>
            
              </form>
            </div>
          </div>
        </div>
       
            </div>
          </section>
  
<x-panel.foot />
@endsection



@push('js')
  <script>
function showSMSAiKey(key){
  swal({
  text: "SMS Key for Ihsancrm App Don't share at public.",
  content: {
    element: "input",
    attributes: {
      value: key,  
    },
  },
  button: {
    text: "Ok",
    closeModal: true,
  },
});
}
  </script>
@endpush