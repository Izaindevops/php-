@extends('layouts.panel')
@section('title','SMS Ai Tracking | Ihsan AI')
@section('content')
<style>
        .chat-box {
            max-height: 400px;
            overflow-y: auto;
            padding: 10px;
        }

        .message {
            padding: 10px;
            border-radius: 10px;
            margin: 5px 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .chat-from {
            background-color: #21599C;
            color:#fff;
            float: left;
            width: 80%;
        }

        .chat-to {
            background-color: #fff;
            float: right;
             color:#000;
             width: 80%;
        }

        .timestamp {
            font-size: 12px;
            color: #777;
            float: right;
        }
    </style>
<div class="container mt-5">
	@if (!$key)
		{{-- expr --}}
	
	<div class="card">
	<div class="card-header h4 text-dark">
		SMS Ai Tracking 
		
	</div>
	<div class="card-body">
		@php

		// $ai_sms= DB::table('ai_sms')->select('bot_id','from_person')->distinct()->where('bot_id',$botID)->get();
		 $ai_smsGet = DB::table('ai_sms')
		    ->select('bots.id as bot_id','bots.bot_name as bot_name','bots.smsAiToken as smsAiToken','bots.rid as rid','ai_sms.bot_id','ai_sms.from_person')
		    ->distinct()	
		    ->join('bots', 'ai_sms.bot_id', '=', 'bots.smsAiToken')->where('ai_sms.bot_id',$botID);
		   if ($ai_smsGet->count()>0) {
		   	$ai_sms=$ai_smsGet->get();
		   
		@endphp
		<table class="table ">
			<thead>
				<tr>
					<td>Sr</td>
				
					<td>Receiver Numbers</td>
					<td>Last Message</td>
					<td></td>
				</tr>
				</thead>
				
			@foreach ($ai_sms as $key => $element)
				{{-- expr --}}
				@php
					$ai_smsG = DB::table('ai_sms')->where('bot_id',$element->bot_id)->where('from_person',$element->from_person)->orderBy('created_at','DESC')->get();
				@endphp
			

			
			<tbody>
				<tr>
					<td>{{++$key}}</td>
					<td>{{$element->from_person}}</td>
					<td>{{ implode(' ', array_slice(str_word_count($ai_smsG[0]->body, 1), 0, 10)) }}</td>
					<td>
						<a href="/SMS/tracking/{{$element->smsAiToken}}/{{$element->from_person}}"><i class="bx bx-show"></i></a>
					</td>

				</tr>
				
			</tbody>
			@endforeach
			
		</table>
		@php
			}
		@endphp
	</div>
</div>
@else
<div class="card">
	<div class="card-header border-bottom h4 text-dark">
		{{$ai_sms[0]->bot_name}}
		
	</div>
	@php
	//dd($ai_sms);
					
				@endphp
	<div class="card-body">

                        
                        <div class="chat-box">
                        	
                        	@foreach ($ai_sms as $key => $element)
                        	@if ($element->is_bot==0)
                        		<div class="message chat-from">
                                <b>{{$element->from_person}}</b> <br> {{$element->body}}
                                <br>
                                <span class="timestamp text-white">{{$element->created_at}}</span>
                            </div>
                        	@else
                        		@if ($element->status=='success')
                        		
                        		<div class="message chat-to" >
                                	<b>{{$element->bot_name}} {{$element->status}} </b> <br> {{$element->body}}
                                	<br>
                                	<span class="timestamp ">{{$element->created_at}}</span>
                            	</div>
                            	@else
                            	<div class="message chat-to bg-warning" >
                                	<b>{{$element->bot_name}} </b> <br> {{$element->body}}
                                	<br>
                                	<span class="timestamp ">{{$element->created_at}}</span>
                            	</div>

                            	@endif
                        	@endif


                            
                            @endforeach
                            
                            <!-- Add more messages here -->
                        </div>
                    
                    
	</div>
</div>

@endif
</div>
@endsection