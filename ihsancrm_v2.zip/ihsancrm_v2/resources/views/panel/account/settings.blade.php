@extends('layouts.panel')
@section('title',"Settings | ISHAN AI")
@section('content')


            <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y"> <livewire:settings /></div>
            <!-- / Content -->

         


<x-panel.foot />
@endsection