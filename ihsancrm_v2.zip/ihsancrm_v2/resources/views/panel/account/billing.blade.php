@extends('layouts.panel')
@section('content')


            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account Settings /</span> Billing & Plans</h4>
              @if(Auth::user()->isPaid==1)
              <div class="row">
                <div class="col-md-12">
                  <ul class="nav nav-pills flex-column flex-md-row mb-3">
                    <li class="nav-item">
                      <a class="nav-link" href="{{route('settings.account')}}"><i class="bx bx-user me-1"></i> Account</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link " href="{{route('settings.security')}}"
                        ><i class="bx bx-lock me-1"></i> Security</a
                      >
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active" href="{{route('settings.billing')}}"
                        ><i class="bx bx-detail-alt me-1"></i> Billing & Plans</a
                      >
                    </li>
                  </ul>
                 <div class="card mb-4">
                   
                 </div>
                </div>
              </div>
              @else
              <h5>Sorry You didn't Buy any Package </h5>

              @endif
            </div>
            <!-- / Content -->

         

            <div class="content-backdrop fade"></div>

<x-panel.foot />
@endsection