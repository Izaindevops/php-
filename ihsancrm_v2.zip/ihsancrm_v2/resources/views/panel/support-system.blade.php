@extends('layouts.panel')
@section('title','Support System')
@section('content')

<link rel="stylesheet" href="{{url('vendor/richtext/richtext.min.css')}}">

<section class="news">
    <div class="container-xxl flex-grow-1 container-p-y">
        @if ($type=="list")


        <div class="card">
            <div class="card-header">
                <a href="{{route('support.create')}}" class="btn btn-primary">Create Ticket </a>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Sr No</th>
                            <th>Title </th>
                            <th>Status</th>
                            <th>Create at</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                      
                        if ($supportData) {
                     
                        $c=0;
                        foreach ($supportData as $key => $value):
                        $c++;
                        @endphp
                        <tr>
                            <td>{{$c}}</td>
                            <td>{{$value->support_title}} </td>
                            <td>@if ($value->support_status==0)
                                <span class="badge text-warning">Pending</span>
                                @elseif ($value->support_status==1)
                                <span class="badge text-success">Accepted</span>
                                @elseif ($value->support_status==2)
                                <span class="badge text-danger">Rejected</span>
                                @endif
                            </td>
                            <td>{{$value->created_at}}</td>
                            <td>
                                <a href="/support-message/{{$value->support_token}}" class="btn btn-dark btn-sm" >Check</a>
                             </td>
                        </tr>
                        @php
                        endforeach;
                        }else {
                        @endphp
                            <tr>
                            <td colspan="5" class="text-center">no result</td>
                                </tr>
                        @php
                        }
                        @endphp
                    </tbody>
                </table>
            </div>
        </div>
        @endif
        @if ($type=="create")
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h3>Create Ticket</h3>
                <a href="{{route('support.list')}}" class="btn btn-primary">New Ticket </a>

            </div>
            <div class="card-body">

                <form action="{{route('support.submit')}}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-sm-10 mx-auto">
                            <Label>Title</Label>
                            <input type="text" name="title" class="form-control " maxlength="24" minlength="5"
                                placeholder="Enter Title here">
                            @error('title')
                            <div class="text-danger">{{$message}} </div>
                            @enderror

                        </div>
                    </div>
                    <div class="col-sm-10 mx-auto mt-2">
                        <label>Description</label>
                        <textarea class="content" name="message"></textarea>
                        @error('message')
                        <div class="text-danger my-2">{{$message}} </div>
                        @enderror
                    </div>
                    <div class="col-sm-10 mx-auto">
                        <label>Attachment</label>
                        <div class="my-2">
                            <label for="formFile" class="form-label">Attach attachment</label>
                            <input class="form-control" type="file" name="attachment">

                            @error('attachment')
                            <div class="text-danger my-2">{{$message}} </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-sm-10 mx-auto">
                        <button class="btn btn-primary float-right " type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endif
    <x-panel.foot />
    <script src="{{url('vendor/richtext/jquery.richtext.js')}}"></script>
    <script src="{{url('assets/js/custom.js')}}"></script>
</section>
{{-- <td><span class="badge bg-danger rounded-pill">3</span> --}}

    <script>
        $(document).ready(function() {
            $('.content').richText({

    // text formatting
    bold: true,
    italic: true,
    underline: true,

    // text alignment
    leftAlign: true,
    centerAlign: true,
    rightAlign: true,
    justify: true,

    // lists
    ol: true,
    ul: true,

    // title
    heading: true,

    // fonts
    fonts: true,
    fontList: ["Arial",
      "Arial Black",
      "Comic Sans MS",
      "Courier New",
      "Geneva",
      "Georgia",
      "Helvetica",
      "Impact",
      "Lucida Console",
      "Tahoma",
      "Times New Roman",
      "Verdana"
    ],
    fontColor: true,
    backgroundColor: true,
    fontSize: true,

    // uploads
    imageUpload: false,
    fileUpload: false,

    // media


    // link

    // tables
    table: true,

    // code
    removeStyles: true,
    code: false,

    // colors
    colors: [],

    // dropdowns
    fileHTML: '',
    imageHTML: '',

    // translations
    translations: {
      'title': 'Title',
      'white': 'White',
      'black': 'Black',
      'brown': 'Brown',
      'beige': 'Beige',
      'darkBlue': 'Dark Blue',
      'blue': 'Blue',
      'lightBlue': 'Light Blue',
      'darkRed': 'Dark Red',
      'red': 'Red',
      'darkGreen': 'Dark Green',
      'green': 'Green',
      'purple': 'Purple',
      'darkTurquois': 'Dark Turquois',
      'turquois': 'Turquois',
      'darkOrange': 'Dark Orange',
      'orange': 'Orange',
      'yellow': 'Yellow',
      'imageURL': 'Image URL',
      'fileURL': 'File URL',
      'linkText': 'Link text',
      'url': 'URL',
      'size': 'Size',
      'responsive': '',
      'text': 'Text',
      'openIn': 'Open in',
      'sameTab': 'Same tab',
      'newTab': 'New tab',
      'align': 'Align',
      'left': 'Left',
      'justify': 'Justify',
      'center': 'Center',
      'right': 'Right',
      'rows': 'Rows',
      'columns': 'Columns',
      'add': 'Add',
      'pleaseEnterURL': 'Please enter an URL',
      'videoURLnotSupported': 'Video URL not supported',
      'pleaseSelectImage': 'Please select an image',
      'pleaseSelectFile': 'Please select a file',
      'bold': 'Bold',
      'italic': 'Italic',
      'underline': 'Underline',
      'alignLeft': 'Align left',
      'alignCenter': 'Align centered',
      'alignRight': 'Align right',
      'addOrderedList': 'Ordered list',
      'addUnorderedList': 'Unordered list',
      'addHeading': 'Heading/title',
      'addFont': 'Font',
      'addFontColor': 'Font color',
      'addBackgroundColor': 'Background color',
      'addFontSize': 'Font size',
      'addImage': 'Add image',
      'addVideo': 'Add video',
      'addFile': 'Add file',
      'addURL': 'Add URL',
      'addTable': 'Add table',
      'removeStyles': 'Remove styles',
      'code': 'Show HTML code',
      'undo': 'Undo',
      'redo': 'Redo',
      'save': 'Save',
      'close': 'Close'
    },

    // privacy
    youtubeCookies: false,

    // preview
    preview: false,

    // placeholder
    placeholder: 'Descripte your issue here',

    // dev settings
    useSingleQuotes: false,
    height: 0,
    heightPercentage: 0,
    adaptiveHeight: false,
    id: "",
    class: "",
    useParagraph: false,
    maxlength: 0,
    maxlengthIncludeHTML: false,
    callback: undefined,
    useTabForNext: false,
    save: false,
    saveCallback: undefined,
    saveOnBlur: 0,
    undoRedo: true

    });
        });
    </script>
    @endsection
