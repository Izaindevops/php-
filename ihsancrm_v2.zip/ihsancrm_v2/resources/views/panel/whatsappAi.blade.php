@extends('layouts.panel')
@section('title','Whatapp Ai| Ihsan AI')
@section('content')
<style type="text/css">
  .list-group-item {
     margin-top: 10px;
   }
   .card-img-top{
    max-height: 100px;
     max-width: 100px;
     margin: 0px auto;
     border-radius:2px;

   }
   .card i{
        font-size:12px;
        text-align:center;
   }
   .card .messages{
    padding-bottom: 10px;
   }
   .card .messages a{
    color: #21599C;
    font-size: 14px;
    font-weight: bold
   }
   .list-group-item {
    border: none;
    margin-top: 4px;
    padding: 0px;
   }

</style>
      <section class="news">
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-12">
                  <h4>Your Whatsapp Ai </h4>
                </div>
                <div class="row">
                  @php
                    $query=DB::table('bots')->where('user_id',Auth::user()->id)->where('is_whats_linked',1);
                    $queryGet=$query->get();

                    $queryCount=$query->count();
                    if ($queryCount>0){
                  @endphp
                  @foreach ($queryGet as $value)
                  @php
                    $cSent=countWhere('whatai_chats','msg_status',1);
                    $cReceived=countWhere('whatai_chats','msg_status',2);
                    $unSent=countWhere('whatai_chats','msg_status',0);
                  @endphp
                <div class="col-sm-3 mb-3">
                  <div class="card p-2 h-100">
                    <img  class="card-img-top"  src="{{$value->bot_logo}}" alt="">

                    <div class="card-body">
                      <h5 class="card-title text-center">{{$value->bot_name}}</h5>
                      <p class="card-text text-center">{{$value->what_number}}</p>
                      <div class="messages">
                        <ul class="list-group" >
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="/WhatsappAi/messages/{{$value->uid}}/sent">Sent</a>
                          <span class="badge bg-primary badge-pill">{{$cSent}}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          <a href="/WhatsappAi/messages/{{$value->uid}}/received">Received</a>
                          <span class="badge bg-primary badge-pill">{{$cReceived}}</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                          <a href="/WhatsappAi/messages/{{$value->uid}}/unsent">Unsent</a>
                          <span class="badge bg-primary badge-pill">{{$unSent}}</span>
                        </li>
                      </ul>
                      </div>
                     <div class="text-right">
                        <a href="{{route('whatsapp.session.close',['key'=>$value->rid])}}" title="Logout" class="btn btn-sm btn-dark"><i class='bx bx-log-out'></i></a>
                        <a href="{{route('whatsapp.session.qrcode',['key'=>$value->rid])}}" title="Check Session" class="btn btn-sm btn-secondary"><i class='bx bx-log-in'></i></a>
                    </div>
                    </div>
                  </div>
                </div>
                @endforeach
               @php
                   }else { @endphp
                    <div class="col-sm-12 ">
                      <h5 class="text-dark text-center">You dont Linked any bot Yet <a href='{{route("whats.create")}}'>Click here to create</a> </h5>
                      </div>
                    @php
                   }
               @endphp
              </div>
            </div>
          </section>

<x-panel.foot />
@endsection



