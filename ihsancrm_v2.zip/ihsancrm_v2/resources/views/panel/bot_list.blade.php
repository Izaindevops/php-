@extends('layouts.panel')
@section('title','Bot List | IHSAN AI')
@section('content')
<style type="text/css">
  .list-group-item {
     margin-top: 10px;
   }
   .card-img-top{
    max-height: 100px;
     max-width: 100px;
     margin: 0px auto;
     border-radius:10px;

   }
   .card i{
        font-size:120px;
        text-align:center;
   }
   .bxs-check-circle{
    font-size: 20px !important;
    color: green;
    float: right;
   }.bxs-x-circle{
    font-size: 20px !important;
    color: red;
    float: right;
   }
</style>
      <section class="news">
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-12 d-flex justify-content-between">
                  <h4>Your Bots</h4>
                  <a href="{{route('ihsanbot')}}" class="btn btn-dark">
                    Create Bot
                  </a>
                  <!-- Create new -->
                </div>
                <div class="row">
                  @php
                    $query=DB::table('bots')->where('user_id',Auth::user()->id);
                    $queryGet=$query->get();
                    $queryCount=$query->count();
                    if ($queryCount>0){
                  @endphp
                  @foreach ($queryGet as $value)


                    <div class="col-sm-3 mb-3">
                  <div class="card h-100 p-2">
                    <img  class="card-img-top"  src="{{$value->bot_logo}}" alt="">

                    <div class="card-body">
                      <h5 class="card-title text-center">{{$value->bot_name}}</h5>
                        <span>Web Ai <i class='bx bxs-check-circle'></i></span> <br>
                      @if ($value->is_whats_linked==1)
                          <span>Whatsapp Ai <i class='bx bxs-check-circle'></i></span> <br>
                      @else
                          <span>Whatsapp Ai <i class='bx bxs-x-circle'></i></span> <br>
                      @endif
                      @if ($value->is_sms_linked==1)
                          <span>SMS Ai <i class='bx bxs-check-circle'></i></span> <br>
                      @else
                          <span>SMS Ai <i class='bx bxs-x-circle'></i></span> <br>
                      @endif
                      @if ($value->is_insta_linked==1)
                          <span>Instagram Ai <i class='bx bxs-check-circle'></i></span> <br>
                      @else
                          <span>Instagram Ai <i class='bx bxs-x-circle'></i></span> <br>
                      @endif
                      @if ($value->is_face_linked==1)
                          <span>Facebook Ai <i class='bx bxs-check-circle'></i></span> <br>
                      @else
                          <span>Facebook Ai <i class='bx bxs-x-circle'></i></span> <br>
                      @endif

                      <hr>

                      <a href="/ihsanbot/customize/{{$value->uid}}" class="btn btn-primary btn-sm float-right">Edit</a>
                    </div>
                  </div>
                </div>
                @endforeach
               @php
                   }else { @endphp
                    <div class="col-sm-12 ">
                      <h5 class="text-dark text-center">You dont Created any bot Yet <a href='{{route('ihsanbot')}}'>Click here to create</a> </h5>
                      </div>
                    @php
                   }
               @endphp
              </div>
            </div>
          </section>

<x-panel.foot />
@endsection



