<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bots', function (Blueprint $table) {
            $table->id();
            $table->string('bot_name', 50)->nullable();
            $table->text('uid')->nullable();
            $table->text('rid')->nullable();
            $table->text('webAiToken')->nullable();
            $table->text('smsAiToken')->nullable();
            $table->integer('user_id')->nullable()->index('bots_ibfk_1');
            $table->string('company_name', 50)->nullable();
            $table->text('company_logo')->nullable();
            $table->text('bot_logo')->nullable();
            $table->string('bot_color', 20)->nullable();
            $table->text('welcome_message')->nullable();
            $table->text('source_file')->nullable();
            $table->text('source_link')->nullable();
            $table->text('statarter_questions')->nullable();
            $table->integer('bot_sts')->default(0);
            $table->integer('disable_by')->default(0);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrentOnUpdate()->useCurrent();
            $table->integer('is_sms_linked')->default(0);
            $table->integer('is_whats_linked')->default(0);
            $table->integer('is_insta_linked')->default(0);
            $table->string('what_status', 40)->nullable();
            $table->string('status_updated_at', 30)->nullable();
            $table->string('what_number', 20)->nullable();
            $table->string('insta_account_name', 100)->nullable();
            $table->integer('is_face_linked')->default(0);
            $table->string('face_account_name', 100)->nullable();
            $table->text('face_page_url')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bots');
    }
};
