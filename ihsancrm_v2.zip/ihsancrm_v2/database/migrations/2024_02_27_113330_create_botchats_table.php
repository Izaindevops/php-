<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('botchats', function (Blueprint $table) {
            $table->id();
            $table->longText('message');
            $table->integer('send_id');
            $table->integer('receive_id');
            $table->integer('is_bot')->default(0);
            $table->string('sender_email', 50)->nullable();
            $table->string('sender_name', 20)->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrentOnUpdate()->useCurrent();
            $table->text('bot_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('botchats');
    }
};
