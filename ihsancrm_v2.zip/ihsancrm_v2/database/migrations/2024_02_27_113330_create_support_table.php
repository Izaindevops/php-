<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('supports', function (Blueprint $table) {
            $table->id();
            $table->text('support_title');
            $table->text('support_message')->nullable();
            $table->integer('user_id');
            $table->text('support_attachment')->nullable();
            $table->text('support_token')->nullable();
            $table->integer('support_status');
            $table->integer('user_readed')->default(0);
            $table->integer('support_readed')->default(0);
     
      
            $table->integer('by_support')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('supports');
    }
};
