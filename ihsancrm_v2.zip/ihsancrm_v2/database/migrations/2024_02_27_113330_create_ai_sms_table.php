<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ai_sms', function (Blueprint $table) {
            $table->id();
            $table->text('body')->nullable();
            $table->text('bot_id');
            $table->integer('is_bot')->default(0);
            $table->integer('user_id');
            $table->string('to_person', 40)->nullable();
            $table->string('from_person', 40)->nullable();
            $table->string('country', 75)->nullable();
            $table->string('carrier', 75)->nullable();
            $table->string('status', 50)->nullable();
            $table->text('message_id')->nullable();
            $table->string('sms_status', 10)->nullable();
            $table->timestamps();
          
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ai_sms');
    }
};
