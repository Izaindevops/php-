<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('phone', 23)->nullable();
            $table->string('organization', 50)->nullable();
            $table->text('address')->nullable();
            $table->string('state', 40)->nullable();
            $table->string('zipCode', 20)->nullable();
            $table->string('country', 25)->nullable();
            $table->string('timezone', 20)->nullable();
            $table->string('payment_method', 10)->nullable();
            $table->string('planId', 10)->nullable();
            $table->string('google_id')->nullable();
            $table->string('gauth_type', 20)->nullable();
            $table->string('role')->nullable();
            $table->rememberToken();
            $table->text('profile_img')->nullable();
            $table->timestamps();
            $table->integer('status')->default(0);
            $table->integer('isPaid')->default(0);
            $table->string('planActiveTime', 20)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
};
