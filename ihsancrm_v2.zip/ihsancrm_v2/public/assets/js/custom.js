
$(document).ready(function(){
$('.news .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    padding:0,
    responsive:{
        0:{
            items:2
        },
        576:{
            items:2
        },
        768:{
            items:2
        },
        992:{
            items:3
        },
        1200:{
            items:3
        }
    }
})

});
// file-upload
$(document).ready(function () {
    $("#deni").FancyFileUpload({
    url:"panel/file/upload",
      params: {
        action: "fileuploader",
         "_token": "{{ csrf_token() }}",
      },
      'maxfilesize' : -1,
       'retries' : 1,


    });
  });

          function displayMessage(message,ava) {
                $(".chat-history").append(`<li class="chat-message chat-message-right ">
                                    <div class="d-flex overflow-hidden">
                                        <div class="chat-message-wrapper flex-grow-1">
                                            <div class="chat-message-text">
                                                <p class="mb-0">${message}</p>
                                            </div>
                                            <div class="text-end text-muted mt-1">
                                                <i class="text-success"></i>
                                                <small></small>
                                            </div>
                                        </div>
                                        <div class="user-avatar flex-shrink-0 ms-3">
                                            <div class="avatar avatar-sm">
                                                <img src="${ava}" alt="Avatar" class="rounded-circle">
                                            </div>
                                        </div>
                                    </div>
                                </li>`);
                $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
            }
            function displayPromt(message,ava) {
                $(".chat-history").append(`<li class="chat-message">
                                    <div class="d-flex overflow-hidden">
                                        <div class="user-avatar flex-shrink-0 me-3">
                                            <div class="avatar avatar-sm">
                                                <img src="${ava}" alt="Avatar" class="rounded-circle">
                                            </div>
                                        </div>
                                        <div class="chat-message-wrapper flex-grow-1">
                                            <div class="chat-message-text">
                                                <p class="mb-0">${message}</p>
                                            </div>
                                            <div class="text-muted mt-1">
                                                <small></small>
                                            </div>
                                        </div>
                                    </div>
                                </li>`);
                $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
            }