
  // Dispose toast when open another
  function toastDispose(toast) {
    if (toast && toast._element !== null) {
      if (toastPlacementExample) {
        toastPlacementExample.classList.remove(selectedType);
        DOMTokenList.prototype.remove.apply(toastPlacementExample.classList, selectedPlacement);
      }
      toast.dispose();
    }
  }
  // Placement Button click
   function SendMessage (selectedType,title,message){
      let  selectedPlacement, toastPlacement;
      const toastPlacementExample = document.querySelector('.toast-placement-ex');
      if (toastPlacement) {
        toastDispose(toastPlacement);
      }
    document.querySelector('.toast-placement-ex .toast-header .me-auto').innerHTML=title;
     document.querySelector('.toast-placement-ex .toast-body').innerHTML=message;

      selectedPlacement ="top-0 end-0".split(' ');
      toastPlacementExample.classList.add("bg-"+selectedType);
      DOMTokenList.prototype.add.apply(toastPlacementExample.classList, selectedPlacement);
      toastPlacement = new bootstrap.Toast(toastPlacementExample);
      toastPlacement.show();
   }